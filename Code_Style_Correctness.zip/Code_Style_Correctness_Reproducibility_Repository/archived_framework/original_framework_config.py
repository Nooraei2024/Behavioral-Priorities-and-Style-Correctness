from pathlib import Path

# =============================================================================
# CENTRAL CONFIGURATION FOR RESEARCH FRAMEWORK
# =============================================================================
ROOT_DIR = Path(__file__).resolve().parent

# =============================================================================
# GLOBAL RUNTIME / FEATURE-EXTRACTION PARAMETERS
# =============================================================================
MIN_DUP_BLOCK_LINES = 3
TOO_MANY_LOCALS_THRESHOLD = 4

PYLINT_TIMEOUT = 25
PYLINT_ENABLED = True


# =============================================================================
# 1) DATA SOURCE
# =============================================================================

DATA_SOURCE_DIR = ROOT_DIR / "1. Data Source"

# -----------------------------------------------------------------------------
# 1.1 Human Code Dataset
# -----------------------------------------------------------------------------
HUMAN_CODE_DATASET_DIR = DATA_SOURCE_DIR / "1. Human Code Dataset"
HUMAN_DATASET_DIR = HUMAN_CODE_DATASET_DIR / "Human dataset" / "final_dataset"
HUMAN_METADATA_DIR = HUMAN_CODE_DATASET_DIR / "metadata"
HUMAN_NOTEBOOKS_DIR = HUMAN_CODE_DATASET_DIR / "notebooks"
HUMAN_SCRIPTS_DIR = HUMAN_CODE_DATASET_DIR / "scripts"

HUMAN_FINAL_DATASET_METADATA_CSV = HUMAN_METADATA_DIR / "final_dataset_metadata.csv"
HUMAN_PYTHON_CODES_METADATA_CSV = HUMAN_METADATA_DIR / "python_codes_metadata.csv"
HUMAN_PYTHON_CODES_METADATA_FINAL_CSV = HUMAN_METADATA_DIR / "python_codes_metadata_final.csv"

HUMAN_DOWNLOAD_PYTHON_STRICT_PY = HUMAN_SCRIPTS_DIR / "download_python_strict.py"
HUMAN_EXTRACT_ALL_FEATURES_PY = HUMAN_SCRIPTS_DIR / "extract_all_features.py"
HUMAN_FINAL_DATASET_METADATA_PY = HUMAN_SCRIPTS_DIR / "final_dataset_metadata.py"
HUMAN_SELECT_AND_COPY_FINAL_PY = HUMAN_SCRIPTS_DIR / "select_and_copy_final.py"

HUMAN_DOWNLOAD_PYTHON_STRICT_IPYNB = HUMAN_NOTEBOOKS_DIR / "download_python_strict.ipynb"
HUMAN_EXTRACT_ALL_FEATURES_IPYNB = HUMAN_NOTEBOOKS_DIR / "extract_all_features.ipynb"
HUMAN_FINAL_DATASET_METADATA_IPYNB = HUMAN_NOTEBOOKS_DIR / "final_dataset_metadata.ipynb"
HUMAN_SELECT_AND_COPY_FINAL_IPYNB = HUMAN_NOTEBOOKS_DIR / "select_and_copy_final.ipynb"

# -----------------------------------------------------------------------------
# 1.2 AI Generated Code
# -----------------------------------------------------------------------------
AI_CODE_DATASET_DIR = DATA_SOURCE_DIR / "2. AI Generated Code"
AI_DATASET_DIR = AI_CODE_DATASET_DIR / "AI dataset" / "final_dataset_ai_filtered"
AI_METADATA_DIR = AI_CODE_DATASET_DIR / "metadata"
AI_NOTEBOOKS_DIR = AI_CODE_DATASET_DIR / "notebooks"
AI_SCRIPTS_DIR = AI_CODE_DATASET_DIR / "scripts"

AI_CODE_METADATA_CSV = AI_METADATA_DIR / "ai_code_metadata.csv"
AI_FINAL_AI_CODE_LIST_TXT = AI_METADATA_DIR / "final_ai_code_list.txt"

AI_GENERATION2_PY = AI_SCRIPTS_DIR / "ai_generation2.py"
AI_FINAL_DATASET_AI_FILTERED_PY = AI_SCRIPTS_DIR / "final_dataset_ai_filtered.py"

AI_GENERATION2_IPYNB = AI_NOTEBOOKS_DIR / "ai_generation2.ipynb"
AI_FINAL_DATASET_AI_FILTERED_IPYNB = AI_NOTEBOOKS_DIR / "final_dataset_ai_filtered.ipynb"

# -----------------------------------------------------------------------------
# 1.3 Structural Feature Extraction
# -----------------------------------------------------------------------------
STRUCT_FEATURE_DIR = DATA_SOURCE_DIR / "3. Structural Feature Extraction"

# Human Codes
HUMAN_STRUCT_FEATURE_DIR = STRUCT_FEATURE_DIR / "Human Codes"
HUMAN_STRUCT_FEATURE_NOTEBOOKS_DIR = HUMAN_STRUCT_FEATURE_DIR / "notebooks"
HUMAN_STRUCT_FEATURE_OUTPUTS_DIR = HUMAN_STRUCT_FEATURE_DIR / "outputs"
HUMAN_STRUCT_FEATURE_SCRIPTS_DIR = HUMAN_STRUCT_FEATURE_DIR / "scripts"

HUMAN_FEATURES_EXTENDED_CSV = HUMAN_STRUCT_FEATURE_OUTPUTS_DIR / "final_features_extended.csv"
HUMAN_PYLINT_REPORT_JSON = HUMAN_STRUCT_FEATURE_OUTPUTS_DIR / "pylint_report.json"
HUMAN_FEATURES_EXTENDED_PY = HUMAN_STRUCT_FEATURE_SCRIPTS_DIR / "final_features_extended.py"
HUMAN_FEATURES_EXTENDED_IPYNB = HUMAN_STRUCT_FEATURE_NOTEBOOKS_DIR / "final_features_extended.ipynb"

# AI Codes
AI_STRUCT_FEATURE_DIR = STRUCT_FEATURE_DIR / "AI Codes"
AI_STRUCT_FEATURE_NOTEBOOKS_DIR = AI_STRUCT_FEATURE_DIR / "notebooks"
AI_STRUCT_FEATURE_OUTPUTS_DIR = AI_STRUCT_FEATURE_DIR / "outputs"
AI_STRUCT_FEATURE_SCRIPTS_DIR = AI_STRUCT_FEATURE_DIR / "scripts"

AI_FEATURES_EXTENDED_CSV = AI_STRUCT_FEATURE_OUTPUTS_DIR / "final_ai_features_extended.csv"
AI_PYLINT_REPORT_JSON = AI_STRUCT_FEATURE_OUTPUTS_DIR / "pylint_report.json"
AI_FEATURES_EXTENDED_PY = AI_STRUCT_FEATURE_SCRIPTS_DIR / "final_ai_features_extended.py"
AI_FEATURES_EXTENDED_IPYNB = AI_STRUCT_FEATURE_NOTEBOOKS_DIR / "final_ai_features_extended.ipynb"

# -----------------------------------------------------------------------------
# 1.4 Features Selection
# -----------------------------------------------------------------------------
FEATURE_SELECTION_DIR = DATA_SOURCE_DIR / "4. Features Selection"

# Human Codes
HUMAN_SELECTION_DIR = FEATURE_SELECTION_DIR / "Human Codes"
HUMAN_SELECTION_NOTEBOOKS_DIR = HUMAN_SELECTION_DIR / "notebooks"
HUMAN_SELECTION_OUTPUTS_DIR = HUMAN_SELECTION_DIR / "outputs"
HUMAN_SELECTION_SCRIPTS_DIR = HUMAN_SELECTION_DIR / "scripts"

HUMAN_SELECTED_FEATURES_CSV = HUMAN_SELECTION_OUTPUTS_DIR / "final_selected_features.csv"
HUMAN_LASSO_COEFFICIENTS_CSV = HUMAN_SELECTION_OUTPUTS_DIR / "LASSO_coefficients.csv"
HUMAN_MI_SCORES_CSV = HUMAN_SELECTION_OUTPUTS_DIR / "MI_scores.csv"
HUMAN_SELECTED_FEATURES_PY = HUMAN_SELECTION_SCRIPTS_DIR / "final_selected_features.py"
HUMAN_SELECTED_FEATURES_IPYNB = HUMAN_SELECTION_NOTEBOOKS_DIR / "final_selected_features.ipynb"

# AI Codes
AI_SELECTION_DIR = FEATURE_SELECTION_DIR / "AI Codes"
AI_SELECTION_NOTEBOOKS_DIR = AI_SELECTION_DIR / "notebooks"
AI_SELECTION_OUTPUTS_DIR = AI_SELECTION_DIR / "outputs"
AI_SELECTION_SCRIPTS_DIR = AI_SELECTION_DIR / "scripts"

AI_SELECTED_FEATURES_CSV = AI_SELECTION_OUTPUTS_DIR / "final_ai_selected_features.csv"
AI_SELECTED_FEATURES_PY = AI_SELECTION_SCRIPTS_DIR / "final_ai_selected_features.py"
AI_SELECTED_FEATURES_IPYNB = AI_SELECTION_NOTEBOOKS_DIR / "final_ai_selected_features.ipynb"

# -----------------------------------------------------------------------------
# 1.5 Features Scaling
# -----------------------------------------------------------------------------
FEATURE_SCALING_DIR = DATA_SOURCE_DIR / "5. Features Scaling"

# Human Codes
HUMAN_SCALING_DIR = FEATURE_SCALING_DIR / "Human Codes"
HUMAN_SCALING_NOTEBOOKS_DIR = HUMAN_SCALING_DIR / "notebooks"
HUMAN_SCALING_OUTPUTS_DIR = HUMAN_SCALING_DIR / "outputs"
HUMAN_SCALING_SCRIPTS_DIR = HUMAN_SCALING_DIR / "scripts"

HUMAN_SELECTED_FEATURES_SCALED_CSV = HUMAN_SCALING_OUTPUTS_DIR / "final_selected_features_scaled.csv"
HUMAN_SELECTED_FEATURES_SCALED_PY = HUMAN_SCALING_SCRIPTS_DIR / "final_selected_features_scaled.py"
HUMAN_SELECTED_FEATURES_SCALED_IPYNB = HUMAN_SCALING_NOTEBOOKS_DIR / "final_selected_features_scaled.ipynb"

# AI Codes
AI_SCALING_DIR = FEATURE_SCALING_DIR / "AI Codes"
AI_SCALING_NOTEBOOKS_DIR = AI_SCALING_DIR / "notebooks"
AI_SCALING_OUTPUTS_DIR = AI_SCALING_DIR / "outputs"
AI_SCALING_SCRIPTS_DIR = AI_SCALING_DIR / "scripts"

AI_SELECTED_FEATURES_SCALED_CSV = AI_SCALING_OUTPUTS_DIR / "final_ai_selected_features_scaled.csv"
AI_SELECTED_FEATURES_SCALED_PY = AI_SCALING_SCRIPTS_DIR / "final_ai_selected_features_scaled.py"
AI_SELECTED_FEATURES_SCALED_IPYNB = AI_SCALING_NOTEBOOKS_DIR / "final_ai_selected_features_scaled.ipynb"

# =============================================================================
# 2) STRUCTURAL GROUND TRUTH CONSTRUCTION
# =============================================================================

GROUND_TRUTH_DIR = ROOT_DIR / "2. Structural Ground Truth Construction"

# -----------------------------------------------------------------------------
# 2.1 Latent Skill Inference
# -----------------------------------------------------------------------------
LATENT_SKILL_DIR = GROUND_TRUTH_DIR / "1- Latent Skill Inference"

# Latent Skill Generation
FINAL_FEATURES_WITH_SKILL_DIR = LATENT_SKILL_DIR / "final_features_with_skill"
LATENT_SKILL_NOTEBOOKS_DIR = FINAL_FEATURES_WITH_SKILL_DIR / "notebooks"
LATENT_SKILL_OUTPUTS_DIR = FINAL_FEATURES_WITH_SKILL_DIR / "outputs"
LATENT_SKILL_SCRIPTS_DIR = FINAL_FEATURES_WITH_SKILL_DIR / "scripts"

HUMAN_FEATURES_WITH_SKILL_CSV = LATENT_SKILL_OUTPUTS_DIR / "final_features_with_skill.csv"
FINAL_FEATURES_WITH_SKILL_PY = LATENT_SKILL_SCRIPTS_DIR / "final_features_with_skill.py"
FINAL_FEATURES_WITH_SKILL_IPYNB = LATENT_SKILL_NOTEBOOKS_DIR / "final_features_with_skill.ipynb"

# Latent Skill Statistics
SKILL_STATS_DIR = LATENT_SKILL_DIR / "Statistics"
SKILL_STATS_NOTEBOOKS_DIR = SKILL_STATS_DIR / "notebooks"
SKILL_STATS_SCRIPTS_DIR = SKILL_STATS_DIR / "scripts"

SKILL_DESCRIPTIVE_STATS_PY = SKILL_STATS_SCRIPTS_DIR / "skill_descriptive_stats.py"
SKILL_DESCRIPTIVE_STATS_IPYNB = SKILL_STATS_NOTEBOOKS_DIR / "skill_descriptive_stats.ipynb"

# -----------------------------------------------------------------------------
# 2.2 Smell Candidate Detection
# -----------------------------------------------------------------------------
SMELL_CANDIDATE_DIR = GROUND_TRUTH_DIR / "2-Smell Candidate Detection"

# Human Codes
HUMAN_SMELL_CANDIDATE_DIR = SMELL_CANDIDATE_DIR / "Human Codes"
HUMAN_SMELL_CANDIDATE_NOTEBOOKS_DIR = HUMAN_SMELL_CANDIDATE_DIR / "notebooks"
HUMAN_SMELL_CANDIDATE_OUTPUTS_DIR = HUMAN_SMELL_CANDIDATE_DIR / "outputs"
HUMAN_SMELL_CANDIDATE_SCRIPTS_DIR = HUMAN_SMELL_CANDIDATE_DIR / "scripts"

HUMAN_SMELL_LABELS_CSV = HUMAN_SMELL_CANDIDATE_OUTPUTS_DIR / "code_smell_labels.csv"
HUMAN_SMELL_LABELS_PY = HUMAN_SMELL_CANDIDATE_SCRIPTS_DIR / "code_smell_labels.py"
HUMAN_SMELL_LABELS_IPYNB = HUMAN_SMELL_CANDIDATE_NOTEBOOKS_DIR / "code_smell_labels.ipynb"

HUMAN_JSCPD_REPORT_DIR = HUMAN_SMELL_CANDIDATE_OUTPUTS_DIR / "jscpd_report"
HUMAN_JSCPD_REPORT_JSON = HUMAN_JSCPD_REPORT_DIR / "jscpd-report.json"

# AI Codes
AI_SMELL_CANDIDATE_DIR = SMELL_CANDIDATE_DIR / "AI Codes"
AI_SMELL_CANDIDATE_NOTEBOOKS_DIR = AI_SMELL_CANDIDATE_DIR / "notebooks"
AI_SMELL_CANDIDATE_OUTPUTS_DIR = AI_SMELL_CANDIDATE_DIR / "outputs"
AI_SMELL_CANDIDATE_SCRIPTS_DIR = AI_SMELL_CANDIDATE_DIR / "scripts"

AI_SMELL_LABELS_CSV = AI_SMELL_CANDIDATE_OUTPUTS_DIR / "code_smell_labels_ai.csv"
AI_SMELL_LABELS_PY = AI_SMELL_CANDIDATE_SCRIPTS_DIR / "code_smell_labels_ai.py"
AI_SMELL_LABELS_IPYNB = AI_SMELL_CANDIDATE_NOTEBOOKS_DIR / "code_smell_labels_ai.ipynb"

AI_JSCPD_REPORT_DIR = AI_SMELL_CANDIDATE_OUTPUTS_DIR / "jscpd_report"
AI_JSCPD_REPORT_JSON = AI_JSCPD_REPORT_DIR / "jscpd-report.json"

# -----------------------------------------------------------------------------
# 2.3 Consensus Ground Truth
# -----------------------------------------------------------------------------
CONSENSUS_DIR = GROUND_TRUTH_DIR / "3- Consensus Ground Truth"

# Human Codes
HUMAN_CONSENSUS_DIR = CONSENSUS_DIR / "Human Codes"
HUMAN_CONSENSUS_NOTEBOOKS_DIR = HUMAN_CONSENSUS_DIR / "notebooks"
HUMAN_CONSENSUS_OUTPUTS_DIR = HUMAN_CONSENSUS_DIR / "outputs"
HUMAN_CONSENSUS_SCRIPTS_DIR = HUMAN_CONSENSUS_DIR / "scripts"

HUMAN_CONSENSUS_LABELS_CSV = HUMAN_CONSENSUS_OUTPUTS_DIR / "code_smell_consensus_labels.csv"
HUMAN_CONSENSUS_LABELS_PY = HUMAN_CONSENSUS_SCRIPTS_DIR / "code_smell_consensus_labels.py"
HUMAN_CONSENSUS_LABELS_IPYNB = HUMAN_CONSENSUS_NOTEBOOKS_DIR / "code_smell_consensus_labels.ipynb"

# AI Codes
AI_CONSENSUS_DIR = CONSENSUS_DIR / "AI Codes"
AI_CONSENSUS_NOTEBOOKS_DIR = AI_CONSENSUS_DIR / "notebooks"
AI_CONSENSUS_OUTPUTS_DIR = AI_CONSENSUS_DIR / "outputs"
AI_CONSENSUS_SCRIPTS_DIR = AI_CONSENSUS_DIR / "scripts"

AI_CONSENSUS_LABELS_CSV = AI_CONSENSUS_OUTPUTS_DIR / "code_smell_consensus_labels_ai.csv"
AI_CONSENSUS_LABELS_PY = AI_CONSENSUS_SCRIPTS_DIR / "code_smell_consensus_labels_ai.py"
AI_CONSENSUS_LABELS_IPYNB = AI_CONSENSUS_NOTEBOOKS_DIR / "code_smell_consensus_labels_ai.ipynb"

# -----------------------------------------------------------------------------
# 2.4 Final Features With Skill and Correctness
# -----------------------------------------------------------------------------
FINAL_SKILL_CORRECTNESS_DIR = GROUND_TRUTH_DIR / "4- Final Features With Skill and Correctness"
FINAL_SKILL_CORRECTNESS_NOTEBOOKS_DIR = FINAL_SKILL_CORRECTNESS_DIR / "notebooks"
FINAL_SKILL_CORRECTNESS_OUTPUTS_DIR = FINAL_SKILL_CORRECTNESS_DIR / "outputs"
FINAL_SKILL_CORRECTNESS_SCRIPTS_DIR = FINAL_SKILL_CORRECTNESS_DIR / "scripts"

FINAL_FEATURES_WITH_SKILL_AND_CORRECTNESS_CSV = FINAL_SKILL_CORRECTNESS_OUTPUTS_DIR / "final_features_with_skill_and_correctness.csv"
FINAL_FEATURES_WITH_SKILL_AND_CORRECTNESS_PY = FINAL_SKILL_CORRECTNESS_SCRIPTS_DIR / "final_features_with_skill_and_correctness.py"
FINAL_FEATURES_WITH_SKILL_AND_CORRECTNESS_IPYNB = FINAL_SKILL_CORRECTNESS_NOTEBOOKS_DIR / "final_features_with_skill_and_correctness.ipynb"

# -----------------------------------------------------------------------------
# 2.5 Human Surrogate Modeling
# -----------------------------------------------------------------------------
SURROGATE_DIR = GROUND_TRUTH_DIR / "5- Human Surrogate Modeling"

# 2.5.1 Feature Label Matrix
FEATURE_LABEL_MATRIX_DIR = SURROGATE_DIR / "1- Feature Label Matrix"

# AI Codes
AI_FEATURE_LABEL_MATRIX_DIR = FEATURE_LABEL_MATRIX_DIR / "AI Codes"
AI_FEATURE_LABEL_MATRIX_NOTEBOOKS_DIR = AI_FEATURE_LABEL_MATRIX_DIR / "notebooks"
AI_FEATURE_LABEL_MATRIX_OUTPUTS_DIR = AI_FEATURE_LABEL_MATRIX_DIR / "outputs"
AI_FEATURE_LABEL_MATRIX_SCRIPTS_DIR = AI_FEATURE_LABEL_MATRIX_DIR / "scripts"

AI_FEATURE_LABEL_MATRIX_CSV = AI_FEATURE_LABEL_MATRIX_OUTPUTS_DIR / "ai_feature_label_matrix.csv"
AI_FEATURE_LABEL_MATRIX_PY = AI_FEATURE_LABEL_MATRIX_SCRIPTS_DIR / "ai_feature_label_matrix.py"
AI_FEATURE_LABEL_MATRIX_IPYNB = AI_FEATURE_LABEL_MATRIX_NOTEBOOKS_DIR / "ai_feature_label_matrix.ipynb"

# Human Codes
HUMAN_FEATURE_LABEL_MATRIX_DIR = FEATURE_LABEL_MATRIX_DIR / "Human Codes"
HUMAN_FEATURE_LABEL_MATRIX_NOTEBOOKS_DIR = HUMAN_FEATURE_LABEL_MATRIX_DIR / "notebooks"
HUMAN_FEATURE_LABEL_MATRIX_OUTPUTS_DIR = HUMAN_FEATURE_LABEL_MATRIX_DIR / "outputs"
HUMAN_FEATURE_LABEL_MATRIX_SCRIPTS_DIR = HUMAN_FEATURE_LABEL_MATRIX_DIR / "scripts"

HUMAN_FEATURE_LABEL_MATRIX_CSV = HUMAN_FEATURE_LABEL_MATRIX_OUTPUTS_DIR / "human_feature_label_matrix.csv"
HUMAN_FEATURE_LABEL_MATRIX_PY = HUMAN_FEATURE_LABEL_MATRIX_SCRIPTS_DIR / "human_feature_label_matrix.py"
HUMAN_FEATURE_LABEL_MATRIX_IPYNB = HUMAN_FEATURE_LABEL_MATRIX_NOTEBOOKS_DIR / "human_feature_label_matrix.ipynb"

# 2.5.2 Smell Model Metrics Human Tuned
SMELL_MODEL_METRICS_DIR = SURROGATE_DIR / "2- Smell Model Metrics Human Tuned"
SMELL_MODEL_METRICS_NOTEBOOKS_DIR = SMELL_MODEL_METRICS_DIR / "notebooks"
SMELL_MODEL_METRICS_OUTPUTS_DIR = SMELL_MODEL_METRICS_DIR / "outputs"
SMELL_MODEL_METRICS_SCRIPTS_DIR = SMELL_MODEL_METRICS_DIR / "scripts"

SMELL_MODEL_METRICS_HUMAN_TUNED_CSV = SMELL_MODEL_METRICS_OUTPUTS_DIR / "smell_model_metrics_human_tuned.csv"
SMELL_MODEL_METRICS_HUMAN_TUNED_PY = SMELL_MODEL_METRICS_SCRIPTS_DIR / "smell_model_metrics_human_tuned.py"
SMELL_MODEL_METRICS_HUMAN_TUNED_IPYNB = SMELL_MODEL_METRICS_NOTEBOOKS_DIR / "smell_model_metrics_human_tuned.ipynb"

SMELL_MODELS_HUMAN_TUNED_DIR = SMELL_MODEL_METRICS_OUTPUTS_DIR / "smell_models_human_tuned"

LOGREG_LONGMETHOD_MODEL = SMELL_MODELS_HUMAN_TUNED_DIR / "logreg_LongMethod.joblib"
RF_LONGMETHOD_MODEL = SMELL_MODELS_HUMAN_TUNED_DIR / "rf_LongMethod.joblib"

LOGREG_COMPLEXMETHOD_MODEL = SMELL_MODELS_HUMAN_TUNED_DIR / "logreg_ComplexMethod.joblib"
RF_COMPLEXMETHOD_MODEL = SMELL_MODELS_HUMAN_TUNED_DIR / "rf_ComplexMethod.joblib"

LOGREG_DEEPNESTING_MODEL = SMELL_MODELS_HUMAN_TUNED_DIR / "logreg_DeepNesting.joblib"
RF_DEEPNESTING_MODEL = SMELL_MODELS_HUMAN_TUNED_DIR / "rf_DeepNesting.joblib"

LOGREG_DUPLICATECODE_MODEL = SMELL_MODELS_HUMAN_TUNED_DIR / "logreg_DuplicateCode.joblib"
RF_DUPLICATECODE_MODEL = SMELL_MODELS_HUMAN_TUNED_DIR / "rf_DuplicateCode.joblib"

# 2.5.3 Prediction Matrices
PREDICTION_MATRICES_DIR = SURROGATE_DIR / "3- Prediction Matrices"

# AI Codes
AI_PREDICTION_MATRIX_DIR = PREDICTION_MATRICES_DIR / "AI Codes"
AI_PREDICTION_MATRIX_NOTEBOOKS_DIR = AI_PREDICTION_MATRIX_DIR / "notebooks"
AI_PREDICTION_MATRIX_OUTPUTS_DIR = AI_PREDICTION_MATRIX_DIR / "outputs"
AI_PREDICTION_MATRIX_SCRIPTS_DIR = AI_PREDICTION_MATRIX_DIR / "scripts"

AI_FEATURE_PRED_MATRIX_CSV = AI_PREDICTION_MATRIX_OUTPUTS_DIR / "ai_feature_pred_matrix.csv"
AI_FEATURE_PRED_MATRIX_PY = AI_PREDICTION_MATRIX_SCRIPTS_DIR / "ai_feature_pred_matrix.py"
AI_FEATURE_PRED_MATRIX_IPYNB = AI_PREDICTION_MATRIX_NOTEBOOKS_DIR / "ai_feature_pred_matrix.ipynb"

# Human Codes
HUMAN_PREDICTION_MATRIX_DIR = PREDICTION_MATRICES_DIR / "Human Codes"
HUMAN_PREDICTION_MATRIX_NOTEBOOKS_DIR = HUMAN_PREDICTION_MATRIX_DIR / "notebooks"
HUMAN_PREDICTION_MATRIX_OUTPUTS_DIR = HUMAN_PREDICTION_MATRIX_DIR / "outputs"
HUMAN_PREDICTION_MATRIX_SCRIPTS_DIR = HUMAN_PREDICTION_MATRIX_DIR / "scripts"

HUMAN_WITH_PREDS_CSV = HUMAN_PREDICTION_MATRIX_OUTPUTS_DIR / "human_with_preds.csv"
HUMAN_WITH_PREDS_PY = HUMAN_PREDICTION_MATRIX_SCRIPTS_DIR / "human_with_preds.py"
HUMAN_WITH_PREDS_IPYNB = HUMAN_PREDICTION_MATRIX_NOTEBOOKS_DIR / "human_with_preds.ipynb"

# 2.5.4 Integration AI and Human
INTEGRATION_DIR = SURROGATE_DIR / "4- Integration AI and Human"
INTEGRATION_NOTEBOOKS_DIR = INTEGRATION_DIR / "notebooks"
INTEGRATION_OUTPUTS_DIR = INTEGRATION_DIR / "outputs"
INTEGRATION_SCRIPTS_DIR = INTEGRATION_DIR / "scripts"

HUMAN_AI_WITH_PREDS_CSV = INTEGRATION_OUTPUTS_DIR / "human_ai_with_preds.csv"
HUMAN_AI_WITH_PREDS_PY = INTEGRATION_SCRIPTS_DIR / "human_ai_with_preds.py"
HUMAN_AI_WITH_PREDS_IPYNB = INTEGRATION_NOTEBOOKS_DIR / "human_ai_with_preds.ipynb"


# =============================================================================
# 3) HUMAN-AI EVALUATION FRAMEWORK
# =============================================================================

EVALUATION_DIR = ROOT_DIR / "3. Human-AI Evaluation Framework"

# -----------------------------------------------------------------------------
# 3.1 Step 1: Human-AI Structural Pairing
# -----------------------------------------------------------------------------
PAIRING_STAGE_DIR = EVALUATION_DIR / "1- Human_AI_Structural_Pairing"
PAIRING_NOTEBOOKS_DIR = PAIRING_STAGE_DIR / "notebooks"
PAIRING_OUTPUTS_DIR = PAIRING_STAGE_DIR / "outputs"
PAIRING_SCRIPTS_DIR = PAIRING_STAGE_DIR / "scripts"

BEST_HUMAN_AI_PAIRS_CSV = PAIRING_OUTPUTS_DIR / "best_human_ai_pairs.csv"
BEST_HUMAN_AI_PAIRS_PY = PAIRING_SCRIPTS_DIR / "best_human_ai_pairs.py"
BEST_HUMAN_AI_PAIRS_IPYNB = PAIRING_NOTEBOOKS_DIR / "best_human_ai_pairs.ipynb"

# -----------------------------------------------------------------------------
# 3.2 Step 2: Rule-Based Evaluation Engine
# -----------------------------------------------------------------------------
RULE_ENGINE_DIR = EVALUATION_DIR / "2- Rule_Based_Evaluation_Engine"

# 3.2.1 Decision Rules Implementation
RULE_RULES_IMPL_DIR = RULE_ENGINE_DIR / "1-Decision_Rules_Implementation"
RULE_ENGINE_PY = RULE_RULES_IMPL_DIR / "rule_engine.py"

# 3.2.2 Decision Categorization
DECISION_CATEGORIZATION_DIR = RULE_ENGINE_DIR / "2- Decision_Categorization"
DECISION_NOTEBOOKS_DIR = DECISION_CATEGORIZATION_DIR / "notebooks"
DECISION_OUTPUTS_DIR = DECISION_CATEGORIZATION_DIR / "outputs"
DECISION_SCRIPTS_DIR = DECISION_CATEGORIZATION_DIR / "scripts"

SIMULATED_PAIR_SELECTION_CSV = DECISION_OUTPUTS_DIR / "simulated_pair_selection.csv"
SIMULATED_PAIR_SELECTION_PY = DECISION_SCRIPTS_DIR / "simulated_pair_selection.py"
SIMULATED_PAIR_SELECTION_IPYNB = DECISION_NOTEBOOKS_DIR / "simulated_pair_selection.ipynb"
# -----------------------------------------------------------------------------
# 3.3 Step 3: Structural Delta Computation
# -----------------------------------------------------------------------------
DELTA_DIR = EVALUATION_DIR / "3- Structural_Delta_Computation"
DELTA_NOTEBOOKS_DIR = DELTA_DIR / "notebooks"
DELTA_OUTPUTS_DIR = DELTA_DIR / "outputs"
DELTA_SCRIPTS_DIR = DELTA_DIR / "scripts"

SIMULATED_PAIR_FEATURES_CSV = DELTA_OUTPUTS_DIR / "simulated_pair_features.csv"
SIMULATED_PAIR_FEATURES_PY = DELTA_SCRIPTS_DIR / "simulated_pair_features.py"
SIMULATED_PAIR_FEATURES_IPYNB = DELTA_NOTEBOOKS_DIR / "simulated_pair_features.ipynb"

# -----------------------------------------------------------------------------
# 3.4 Step 4: Explainable Decision Output
# -----------------------------------------------------------------------------
EXPLAINABLE_DIR = EVALUATION_DIR / "4- Explainable_Decision_Output"

# 3.4.1 Semantic Mapping Layer
SEMANTIC_MAPPING_DIR = EXPLAINABLE_DIR / "1- Semantic_Mapping_Layer"
SEMANTIC_MAPPING_NOTEBOOKS_DIR = SEMANTIC_MAPPING_DIR / "notebooks"
SEMANTIC_MAPPING_OUTPUTS_DIR = SEMANTIC_MAPPING_DIR / "outputs"
SEMANTIC_MAPPING_SCRIPTS_DIR = SEMANTIC_MAPPING_DIR / "scripts"

MAPPING_TABLE_CSV = SEMANTIC_MAPPING_OUTPUTS_DIR / "mapping_table.csv"
MAPPING_TABLE_PY = SEMANTIC_MAPPING_SCRIPTS_DIR / "mapping_table.py"
MAPPING_TABLE_IPYNB = SEMANTIC_MAPPING_NOTEBOOKS_DIR / "mapping_table.ipynb"

# 3.4.2 Explanation Artifact Generation
EXPLANATION_ARTIFACT_DIR = EXPLAINABLE_DIR / "2- Explanation_Artifact_Generation"
EXPLANATION_NOTEBOOKS_DIR = EXPLANATION_ARTIFACT_DIR / "notebooks"
EXPLANATION_OUTPUTS_DIR = EXPLANATION_ARTIFACT_DIR / "outputs"
EXPLANATION_SCRIPTS_DIR = EXPLANATION_ARTIFACT_DIR / "scripts"

EXPLANATION_ARTIFACTS_CSV = EXPLANATION_OUTPUTS_DIR / "explanation_artifacts.csv"
EXPLANATION_ARTIFACTS_PY = EXPLANATION_SCRIPTS_DIR / "explanation_artifacts.py"
EXPLANATION_ARTIFACTS_IPYNB = EXPLANATION_NOTEBOOKS_DIR / "explanation_artifacts.ipynb"

# 3.4.3 Skill Aware Template Engine
TEMPLATE_ENGINE_DIR = EXPLAINABLE_DIR / "3- Skill_Aware_Template_Engine"
TEMPLATE_ENGINE_NOTEBOOKS_DIR = TEMPLATE_ENGINE_DIR / "notebooks"
TEMPLATE_ENGINE_OUTPUTS_DIR = TEMPLATE_ENGINE_DIR / "outputs"
TEMPLATE_ENGINE_SCRIPTS_DIR = TEMPLATE_ENGINE_DIR / "scripts"

EXPLANATION_TEMPLATES_JSON = TEMPLATE_ENGINE_OUTPUTS_DIR / "explanation_templates.json"
EXPLANATION_TEMPLATES_PY = TEMPLATE_ENGINE_SCRIPTS_DIR / "explanation_templates.py"
EXPLANATION_TEMPLATES_IPYNB = TEMPLATE_ENGINE_NOTEBOOKS_DIR / "explanation_templates.ipynb"

# -----------------------------------------------------------------------------
# 3.5 Step 5: Post Simulation Explainable Analysis
# -----------------------------------------------------------------------------
POST_ANALYSIS_DIR = EVALUATION_DIR / "5- Post_Simulation_Explainable_Analysis"

# 3.5.1 Smell Transition Extraction
SMELL_TRANSITION_DIR = POST_ANALYSIS_DIR / "1- Smell_Transition_Extraction"
SMELL_TRANSITION_NOTEBOOKS_DIR = SMELL_TRANSITION_DIR / "notebooks"
SMELL_TRANSITION_OUTPUTS_DIR = SMELL_TRANSITION_DIR / "outputs"
SMELL_TRANSITION_SCRIPTS_DIR = SMELL_TRANSITION_DIR / "scripts"

SIMULATED_PAIR_SMELLS_CSV = SMELL_TRANSITION_OUTPUTS_DIR / "simulated_pair_smells.csv"
SIMULATED_PAIR_SMELLS_PY = SMELL_TRANSITION_SCRIPTS_DIR / "simulated_pair_smells.py"
SIMULATED_PAIR_SMELLS_IPYNB = SMELL_TRANSITION_NOTEBOOKS_DIR / "simulated_pair_smells.ipynb"

# 3.5.2 Analyze Smell Decision Table
SMELL_DECISION_DIR = POST_ANALYSIS_DIR / "2- Analyze_Smell_Decision_Table"
SMELL_DECISION_NOTEBOOKS_DIR = SMELL_DECISION_DIR / "notebooks"
SMELL_DECISION_OUTPUTS_DIR = SMELL_DECISION_DIR / "outputs"
SMELL_DECISION_SCRIPTS_DIR = SMELL_DECISION_DIR / "scripts"

DECISION_SMELL_CROSSTAB_CSV = SMELL_DECISION_OUTPUTS_DIR / "decision_smell_crosstab.csv"
ANALYZE_SMELL_DECISION_TABLE_PY = SMELL_DECISION_SCRIPTS_DIR / "analyze_smell_decision_table.py"
ANALYZE_SMELL_DECISION_TABLE_IPYNB = SMELL_DECISION_NOTEBOOKS_DIR / "analyze_smell_decision_table.ipynb"

# 3.5.3 Rejection Analysis
REJECTION_ANALYSIS_DIR = POST_ANALYSIS_DIR / "3- Rejection_Analysis"
REJECTION_NOTEBOOKS_DIR = REJECTION_ANALYSIS_DIR / "notebooks"
REJECTION_OUTPUTS_DIR = REJECTION_ANALYSIS_DIR / "outputs"
REJECTION_SCRIPTS_DIR = REJECTION_ANALYSIS_DIR / "scripts"

REJECTED_SMELL_CONTRIBUTIONS_CSV = REJECTION_OUTPUTS_DIR / "rejected_smell_contributions.csv"
ANALYZE_REJECTED_SMELLS_PY = REJECTION_SCRIPTS_DIR / "analyze_rejected_smells.py"
ANALYZE_REJECTED_SMELLS_IPYNB = REJECTION_NOTEBOOKS_DIR / "analyze_rejected_smells.ipynb"

# 3.5.4 Analyze Absent Smells
ABSENT_SMELLS_DIR = POST_ANALYSIS_DIR / "4- Analyze_Absent_Smells"
ABSENT_SMELLS_NOTEBOOKS_DIR = ABSENT_SMELLS_DIR / "notebooks"
ABSENT_SMELLS_OUTPUTS_DIR = ABSENT_SMELLS_DIR / "outputs"
ABSENT_SMELLS_SCRIPTS_DIR = ABSENT_SMELLS_DIR / "scripts"

ABSENT_SMELL_MATRIX_CSV = ABSENT_SMELLS_OUTPUTS_DIR / "absent_smell_matrix.csv"
ABSENT_SMELL_MATRIX_PY = ABSENT_SMELLS_SCRIPTS_DIR / "absent_smell_matrix.py"
ABSENT_SMELL_MATRIX_IPYNB = ABSENT_SMELLS_NOTEBOOKS_DIR / "absent_smell_matrix.ipynb"

# 3.5.5 Skill Severity Robustness Analysis
SEVERITY_ROBUSTNESS_DIR = POST_ANALYSIS_DIR / "5- Skill_Severity_Robustness_Analysis"
SEVERITY_ROBUSTNESS_NOTEBOOKS_DIR = SEVERITY_ROBUSTNESS_DIR / "notebooks"
SEVERITY_ROBUSTNESS_OUTPUTS_DIR = SEVERITY_ROBUSTNESS_DIR / "outputs"
SEVERITY_ROBUSTNESS_SCRIPTS_DIR = SEVERITY_ROBUSTNESS_DIR / "scripts"

CHI_SQUARE_RESULTS_TXT = SEVERITY_ROBUSTNESS_OUTPUTS_DIR / "chi_square_results.txt"
SKILL_SEVERITY_MATRIX_COUNTS_CSV = SEVERITY_ROBUSTNESS_OUTPUTS_DIR / "skill_severity_matrix_counts.csv"
SKILL_SEVERITY_MATRIX_PERCENTAGES_CSV = SEVERITY_ROBUSTNESS_OUTPUTS_DIR / "skill_severity_matrix_percentages.csv"
SKILL_SEVERITY_ROBUSTNESS_PY = SEVERITY_ROBUSTNESS_SCRIPTS_DIR / "skill_severity_robustness.py"
SKILL_SEVERITY_ROBUSTNESS_IPYNB = SEVERITY_ROBUSTNESS_NOTEBOOKS_DIR / "skill_severity_robustness.ipynb"

# 3.5.6 Comparative Analysis Human vs AI
COMPARATIVE_ANALYSIS_DIR = POST_ANALYSIS_DIR / "6- Comparative_Analysis_Human_vs_AI"
COMPARATIVE_NOTEBOOKS_DIR = COMPARATIVE_ANALYSIS_DIR / "notebooks"
COMPARATIVE_OUTPUTS_DIR = COMPARATIVE_ANALYSIS_DIR / "outputs"
COMPARATIVE_SCRIPTS_DIR = COMPARATIVE_ANALYSIS_DIR / "scripts"

HUMAN_VS_AI_SMELL_BINARY_RF_CSV = COMPARATIVE_OUTPUTS_DIR / "human_vs_ai_smell_binary_rf.csv"
HUMAN_VS_AI_SMELL_PROBS_RF_CSV = COMPARATIVE_OUTPUTS_DIR / "human_vs_ai_smell_probs_rf.csv"
HUMAN_VS_AI_SMELL_BINARY_PY = COMPARATIVE_SCRIPTS_DIR / "human_vs_ai_smell_binary.py"
HUMAN_VS_AI_SMELL_BINARY_IPYNB = COMPARATIVE_NOTEBOOKS_DIR / "human_vs_ai_smell_binary.ipynb"
HUMAN_VS_AI_SMELL_PROBS_RF_PY = COMPARATIVE_SCRIPTS_DIR / "human_vs_ai_smell_probs_rf.py"
HUMAN_VS_AI_SMELL_PROBS_RF_IPYNB = COMPARATIVE_NOTEBOOKS_DIR / "human_vs_ai_smell_probs_rf.ipynb"

# 3.5.7 Skill Aware Explainability Analysis
SKILL_AWARE_EXPLAINABILITY_DIR = POST_ANALYSIS_DIR / "7- Skill_Aware_Explainability_Analysis"
SKILL_AWARE_NOTEBOOKS_DIR = SKILL_AWARE_EXPLAINABILITY_DIR / "notebooks"
SKILL_AWARE_OUTPUTS_DIR = SKILL_AWARE_EXPLAINABILITY_DIR / "outputs"
SKILL_AWARE_SCRIPTS_DIR = SKILL_AWARE_EXPLAINABILITY_DIR / "scripts"

HUMAN_SMELL_BY_SKILL_RF_CSV = SKILL_AWARE_OUTPUTS_DIR / "human_smell_by_skill_rf.csv"
HUMAN_SMELL_SKILL_TESTS_RF_CSV = SKILL_AWARE_OUTPUTS_DIR / "human_smell_skill_tests_rf.csv"
HUMAN_SMELL_BY_SKILL_RF_PY = SKILL_AWARE_SCRIPTS_DIR / "human_smell_by_skill_rf.py"
HUMAN_SMELL_BY_SKILL_RF_IPYNB = SKILL_AWARE_NOTEBOOKS_DIR / "human_smell_by_skill_rf.ipynb"
HUMAN_SMELL_SKILL_TESTS_RF_PY = SKILL_AWARE_SCRIPTS_DIR / "human_smell_skill_tests_rf.py"
HUMAN_SMELL_SKILL_TESTS_RF_IPYNB = SKILL_AWARE_NOTEBOOKS_DIR / "human_smell_skill_tests_rf.ipynb"
