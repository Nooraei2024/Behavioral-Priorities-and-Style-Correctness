#!/usr/bin/env python
# coding: utf-8

# In[1]:


import os
import subprocess
import shutil
import hashlib
from collections import defaultdict

# =========================
# CONFIGURATION
# =========================
INPUT_DIR = "final_dataset_ai"
OUTPUT_DIR = "final_dataset_ai_filtered"
MIN_NON_EMPTY_LINES = 10

os.makedirs(OUTPUT_DIR, exist_ok=True)

print("=== STEP: Filtering AI-generated code ===")

# =========================
# STEP 1 — Basic validity checks
# =========================
valid_files = []

for fname in os.listdir(INPUT_DIR):
    if not fname.endswith(".py"):
        continue

    path = os.path.join(INPUT_DIR, fname)

    try:
        with open(path, "r", encoding="utf-8") as f:
            code = f.read()
    except Exception:
        continue

    # Must contain some structure
    if not ("def " in code or "import " in code):
        continue

    # Minimum size
    non_empty_lines = [l for l in code.split("\n") if l.strip()]
    if len(non_empty_lines) < MIN_NON_EMPTY_LINES:
        continue

    # Syntax check
    try:
        subprocess.run(
            ["python", "-m", "py_compile", path],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=5,
            check=True
        )
    except Exception:
        continue

    valid_files.append(fname)

print(f"Valid AI code files: {len(valid_files)}")

# =========================
# STEP 2 — Remove exact duplicates
# =========================
unique_files = []
seen_hashes = set()

for fname in valid_files:
    path = os.path.join(INPUT_DIR, fname)
    with open(path, "r", encoding="utf-8") as f:
        code = f.read()

    code_hash = hashlib.md5(code.encode("utf-8")).hexdigest()
    if code_hash in seen_hashes:
        continue

    seen_hashes.add(code_hash)
    unique_files.append(fname)

print(f"Unique AI code files: {len(unique_files)}")

# =========================
# STEP 3 — Copy to final folder
# =========================
for fname in unique_files:
    shutil.copy(
        os.path.join(INPUT_DIR, fname),
        os.path.join(OUTPUT_DIR, fname)
    )

# =========================
# STEP 4 — Save file list
# =========================
with open("final_ai_code_list.txt", "w", encoding="utf-8") as f:
    for fname in unique_files:
        f.write(fname + "\n")

print(f"Copied {len(unique_files)} AI code files to '{OUTPUT_DIR}'")
print("Saved list to final_ai_code_list.txt")
print("=== DONE: AI code filtering ===")


# In[ ]:




