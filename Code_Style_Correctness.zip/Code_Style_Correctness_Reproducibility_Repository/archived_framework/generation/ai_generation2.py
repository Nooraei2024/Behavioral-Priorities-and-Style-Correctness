#!/usr/bin/env python
# coding: utf-8

# In[10]:


import os
import random
from datetime import datetime

import pandas as pd
import requests

# === توابع کمکی ===

def build_prompt(title: str, description: str) -> str:
    return f"""You are an expert competitive programmer.
Solve the following problem in Python.

Title: {title}

Problem:
{description.strip()}

Requirements:
- Read input from standard input (stdin).
- Write output to standard output (stdout).
- Output only valid Python code.
- Do not include any explanation, comments, markdown, tags, or text outside the code. Only the code.

Now provide the complete Python solution:"""

OLLAMA_URL = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "codellama"

def call_codellama(prompt: str, temperature: float, max_tokens: int, seed: int) -> str:
    payload = {
        "model": OLLAMA_MODEL,
        "prompt": prompt,
        "stream": False,
        "options": {
            "temperature": temperature,
            "num_predict": max_tokens,
            "seed": seed,
        },
    }
    resp = requests.post(OLLAMA_URL, json=payload)
    resp.raise_for_status()
    data = resp.json()
    return data.get("response", "")

def extract_code_only(raw_text: str) -> str:
    lines = raw_text.splitlines()
    code_lines = []
    in_block = False

    for line in lines:
        stripped = line.strip()

        # اگر خط ``````python بود، فقط حالت in_block را عوض کن
        if stripped.startswith("```"):
            in_block = not in_block
            continue

        # اگر مدل بعد از کد توضیح گذاشت، قطع کن
        if stripped.startswith("[EXPLANATION]"):
            break

        # فقط وقتی داخل بلاک کد هستیم، خطوط را جمع کن
        if in_block:
            code_lines.append(line)

    # اگر هیچ بلاک ``` نبود، کل متن را به‌عنوان کد در نظر بگیر
    if not code_lines:
        return raw_text.strip()

    return "\n".join(code_lines).strip()
# === تنظیمات دیتاست ===

META_PATH = "final_dataset_metadata.csv"
AI_OUT_DIR = "final_dataset_ai"
AI_META_OUT = "ai_code_metadata.csv"

os.makedirs(AI_OUT_DIR, exist_ok=True)

meta = pd.read_csv(META_PATH)
problems = meta.groupby("problem_id").first().reset_index()

records = []

# برای تست اول فقط چند مسئله:
problems_sample = problems

# پیکربندی‌ها: دماهای مختلف
GEN_MAX_TOKENS = 350  # افزایش نسبت به 256

configs = [
    {"temp": 0.2, "sample_id": 1},
    {"temp": 0.4, "sample_id": 2},
    {"temp": 0.6, "sample_id": 3},
]

for _, row in problems_sample.iterrows():
    pid = row["problem_id"]
    title = row["title"]
    description = row["description"]

    prompt = build_prompt(title, description)

    for cfg in configs:
        seed = random.randint(0, 10**9)
        start = datetime.now()

        raw = call_codellama(
            prompt=prompt,
            temperature=cfg["temp"],
            max_tokens=GEN_MAX_TOKENS,
            seed=seed,
        )
        code = extract_code_only(raw)
        duration = (datetime.now() - start).total_seconds() * 1000

        ai_filename = f"{pid}_ai_t{int(cfg['temp']*10)}_{cfg['sample_id']}.py"
        filepath = os.path.join(AI_OUT_DIR, ai_filename)

        with open(filepath, "w", encoding="utf-8") as f:
            f.write(code)

        records.append({
            "problem_id": pid,
            "ai_filename": ai_filename,
            "temperature": cfg["temp"],
            "max_tokens": GEN_MAX_TOKENS,
            "seed": seed,
            "model_name": OLLAMA_MODEL,
            "prompt_version": 2,  # چون prompt را عوض کردی
            "generation_time_ms": duration,
        })

ai_meta = pd.DataFrame(records)
ai_meta.to_csv(AI_META_OUT, index=False)
print("Saved:", AI_META_OUT)
print("Number of AI files:", len(records))


# In[ ]:




