#!/usr/bin/env python
# coding: utf-8

import sys
from pathlib import Path
import pandas as pd
import numpy as np

from sklearn.feature_selection import mutual_info_regression
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LassoCV
from sklearn.impute import SimpleImputer

import warnings
warnings.filterwarnings("ignore")

# ============================================================
# Import project config
# ============================================================

# Find the project root by going up 4 levels from this script
project_root = Path(__file__).resolve().parents[4]
sys.path.append(str(project_root))

import config

# Mapping config paths to local variables
INPUT_FEATURES_CSV = config.HUMAN_FEATURES_EXTENDED_CSV
OUTPUT_SELECTED_FEATURES = config.HUMAN_SELECTED_FEATURES_CSV
OUTPUT_MI_SCORES = config.HUMAN_MI_SCORES_CSV
OUTPUT_LASSO_COEF = config.HUMAN_LASSO_COEFFICIENTS_CSV

# Ensure output directory exists to prevent FileNotFoundError
Path(OUTPUT_SELECTED_FEATURES).parent.mkdir(parents=True, exist_ok=True)

# ============================================================
# 1) LOAD DATA
# ============================================================

print("\nLoading human extended features:")
print(INPUT_FEATURES_CSV)

try:
    df = pd.read_csv(INPUT_FEATURES_CSV)
except FileNotFoundError:
    print(f"ERROR: Could not find input file at {INPUT_FEATURES_CSV}")
    sys.exit(1)

# Make a copy for processing
data = df.copy()

# Remove non-feature environmental columns
ENV_COLUMNS = ["file", "RADON_AVAILABLE"]
data = data.drop(columns=[c for c in ENV_COLUMNS if c in data.columns])

# ============================================================
# 2) REMOVE ZERO-VARIANCE FEATURES
# ============================================================

zero_var_features = [c for c in data.columns if data[c].nunique() <= 1]
data = data.drop(columns=zero_var_features)

print("\nRemoved zero-variance features:", zero_var_features)

# ============================================================
# 3) REMOVE FEATURES WITH ≥95% MISSING OR ZERO
# ============================================================

def sparse(col):
    # Consider a feature sparse if 95% or more of its values are 0 or NaN
    return (col == 0).sum() / len(col) >= 0.95

sparse_features = [c for c in data.columns if sparse(data[c])]
data = data.drop(columns=sparse_features)

print("Removed sparse features (≥95% zero/missing):", sparse_features)

# ============================================================
# 4) Mutual Information Ranking
# ============================================================

# For MI we need a target: we use maintainability_index (proxy for code quality)
TARGET = "maintainability_index"
if TARGET not in data.columns:
    raise ValueError(f"'{TARGET}' must exist in the dataset as the MI target.")

X = data.drop(columns=[TARGET])
y = data[TARGET]

# Impute missing values using median to handle NaNs before MI calculation
imputer = SimpleImputer(strategy="median")
X_filled = imputer.fit_transform(X)

# Compute MI scores
mi_scores = mutual_info_regression(X_filled, y, random_state=0)

mi_results = pd.DataFrame({
    "feature": X.columns, 
    "MI_score": mi_scores
}).sort_values("MI_score", ascending=False)

print("\n=== Mutual Information Ranking ===")
print(mi_results)

# ============================================================
# 5) LASSO Feature Selection
# ============================================================

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_filled)

# LassoCV automatically performs cross-validation to find optimal alpha
lasso = LassoCV(cv=5, random_state=0, max_iter=5000)
lasso.fit(X_scaled, y)

lasso_coef = pd.DataFrame({
    "feature": X.columns,
    "coef": lasso.coef_
}).sort_values("coef", key=abs, ascending=False)

print("\n=== LASSO Feature Coefficients ===")
print(lasso_coef)

# Identify features that Lasso kept (coefficient != 0)
selected_by_lasso = lasso_coef[lasso_coef["coef"] != 0]["feature"].tolist()

# ============================================================
# 6) Combine MI + LASSO logic
# ============================================================

# Select top 12 MI features
top_mi_features = mi_results.head(12)["feature"].tolist()

# Final feature union: combine top MI and Lasso selected features
final_features = sorted(list(set(top_mi_features) | set(selected_by_lasso)))

print("\n=== Final selected features ===")
for feat in final_features:
    print(f"- {feat}")

# ============================================================
# 7) Save outputs
# ============================================================

# Create the final dataframe using original columns + selected features
final_df = df[["file"] + final_features]

final_df.to_csv(OUTPUT_SELECTED_FEATURES, index=False)
mi_results.to_csv(OUTPUT_MI_SCORES, index=False)
lasso_coef.to_csv(OUTPUT_LASSO_COEF, index=False)

print("\nFiles successfully saved:")
print(f" - Selected features: {OUTPUT_SELECTED_FEATURES}")
print(f" - MI scores:          {OUTPUT_MI_SCORES}")
print(f" - LASSO coefficients: {OUTPUT_LASSO_COEF}")

print(f"\nOutput Shape: {final_df.shape[0]} rows, {final_df.shape[1]} columns")
print("Done.")
