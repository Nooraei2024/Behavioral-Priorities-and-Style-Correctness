#!/usr/bin/env python
# coding: utf-8

# ============================================================
# AI Feature Selection
# Align AI feature space with selected human features
# ============================================================

import sys
from pathlib import Path
import pandas as pd

# ============================================================
# 1) Load central config
# ============================================================

try:
    project_root = Path(__file__).resolve().parents[4]
    sys.path.append(str(project_root))
    import config

except Exception as e:
    print("Failed to load config.py:", e)
    sys.exit(1)

# ============================================================
# 2) Config paths
# ============================================================

HUMAN_SELECTED_FEATURES_CSV = config.HUMAN_SELECTED_FEATURES_CSV

AI_FEATURES_EXTENDED_CSV = config.AI_FEATURES_EXTENDED_CSV

AI_SELECTED_FEATURES_CSV = config.AI_SELECTED_FEATURES_CSV

# create output directory automatically
AI_SELECTED_FEATURES_CSV.parent.mkdir(parents=True, exist_ok=True)

# ============================================================
# 3) Load datasets
# ============================================================

print("Loading human selected features:")
print(HUMAN_SELECTED_FEATURES_CSV)

human_sel = pd.read_csv(HUMAN_SELECTED_FEATURES_CSV)

print("\nLoading AI extended features:")
print(AI_FEATURES_EXTENDED_CSV)

ai_feat = pd.read_csv(AI_FEATURES_EXTENDED_CSV)

# ============================================================
# 4) Extract selected feature names
# ============================================================

feature_cols = [c for c in human_sel.columns if c != "file"]

print("\nNumber of selected features:", len(feature_cols))

print("\nSelected features:")
for f in feature_cols:
    print("-", f)

# ============================================================
# 5) Check feature consistency
# ============================================================

missing_in_ai = [
    c for c in feature_cols
    if c not in ai_feat.columns
]

if missing_in_ai:

    print("\nWARNING:")
    print("These features are missing in AI dataset:")
    
    for c in missing_in_ai:
        print("-", c)

    print("Missing features will be filled with NaN.")

# common features only
common_feats = [
    c for c in feature_cols
    if c in ai_feat.columns
]

# ============================================================
# 6) Build aligned AI feature table
# ============================================================

ai_sel = ai_feat[
    ["file"] + common_feats
].copy()

# add missing columns as NaN
for c in feature_cols:

    if c not in ai_sel.columns:
        ai_sel[c] = float("nan")

# reorder columns exactly like human dataset
ai_sel = ai_sel[
    ["file"] + feature_cols
]

# ============================================================
# 7) Save output
# ============================================================

ai_sel.to_csv(
    AI_SELECTED_FEATURES_CSV,
    index=False,
    encoding="utf-8-sig"
)

print("\nSaved AI selected features to:")
print(AI_SELECTED_FEATURES_CSV)

print("\nRows:", len(ai_sel))
print("Columns:", len(ai_sel.columns))

print("\nDone.")
