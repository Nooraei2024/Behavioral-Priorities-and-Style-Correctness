#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
from sklearn.preprocessing import StandardScaler
import joblib

# ============================================
# 1. Load AI selected features + human scaler
# ============================================
ai_df_path   = r"C:\Users\HORI\final_ai_selected_features.csv"
scaler_path  = r"C:\Users\HORI\standardization_pipeline.pkl"
ai_out_path  = r"C:\Users\HORI\final_ai_selected_features_scaled.csv"

print("Loading AI selected features from:", ai_df_path)
ai_df = pd.read_csv(ai_df_path)

print("Loading human-fitted scaler from:", scaler_path)
scaler: StandardScaler = joblib.load(scaler_path)

# ستون‌های شناسه (غیرعددی) را جدا می‌کنیم
id_cols = ["file"] if "file" in ai_df.columns else []
X_ai = ai_df.drop(columns=id_cols)

# ============================================
# 2. Apply existing scaler (transform only)
# ============================================
X_ai_scaled = scaler.transform(X_ai)

scaled_ai_df = pd.DataFrame(X_ai_scaled, columns=X_ai.columns)
if id_cols:
    scaled_ai_df[id_cols] = ai_df[id_cols]

# ============================================
# 3. Save outputs
# ============================================
scaled_ai_df.to_csv(ai_out_path, index=False, encoding="utf-8-sig")

print("AI standardization completed.")
print("Saved:", ai_out_path)
print("Rows (AI files):", len(scaled_ai_df))
print("Columns:", len(scaled_ai_df.columns))


# In[ ]:




