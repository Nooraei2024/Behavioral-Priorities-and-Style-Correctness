#!/usr/bin/env python
# coding: utf-8

import sys
from pathlib import Path

# ========== Portable project root detection ==========
def _find_project_root(marker_file="config.py"):
    current = Path(__file__).resolve().parent
    for _ in range(15):
        if (current / marker_file).exists():
            return current
        current = current.parent
    raise FileNotFoundError(f"'{marker_file}' not found in any parent folder")

PROJECT_ROOT = _find_project_root()
sys.path.insert(0, str(PROJECT_ROOT))
# ====================================================

import pandas as pd
from sklearn.preprocessing import StandardScaler
import joblib
import numpy as np
import config

# ============================================
# 1. Load final selected features
# ============================================

INPUT_FEATURES = config.HUMAN_SELECTED_FEATURES_CSV
OUTPUT_SCALED = config.HUMAN_SELECTED_FEATURES_SCALED_CSV

# scaler will be stored in the same scaling output directory
SCALER_PATH = config.HUMAN_SCALING_OUTPUTS_DIR / "standardization_pipeline.pkl"

print("\nLoading selected features:")
print(INPUT_FEATURES)

df = pd.read_csv(INPUT_FEATURES)

# Remove non-numeric or unwanted columns
id_cols = ["file"] if "file" in df.columns else []
X = df.drop(columns=id_cols)

# ============================================
# 2. Apply StandardScaler
# ============================================

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

scaled_df = pd.DataFrame(X_scaled, columns=X.columns)

if id_cols:
    scaled_df[id_cols] = df[id_cols]

# ============================================
# 3. Save outputs
# ============================================

# ensure output directory exists
Path(config.HUMAN_SCALING_OUTPUTS_DIR).mkdir(parents=True, exist_ok=True)

scaled_df.to_csv(OUTPUT_SCALED, index=False)

joblib.dump(scaler, SCALER_PATH)

print("\nStandardization completed.")
print(f"Saved scaled dataset: {OUTPUT_SCALED}")
print(f"Saved scaler: {SCALER_PATH}")

print(f"\nOutput Shape: {scaled_df.shape[0]} rows, {scaled_df.shape[1]} columns")
print("Done.")
