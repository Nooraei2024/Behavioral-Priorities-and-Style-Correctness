# =============================================================================
# STRUCTURAL FEATURE EXTRACTION FOR HUMAN WRITTEN CODE (EXTENDED)
# =============================================================================
# Fully Reproducible Version (Uses Central config.py)
# =============================================================================

import os
import sys
import csv
import math
import json
import re
import ast
import time
import hashlib
import subprocess
from collections import defaultdict
from typing import Dict, Any, List, Tuple
from pathlib import Path

# =============================================================================
# 1. LOAD CENTRAL CONFIG
# =============================================================================

try:
    project_root = Path(__file__).resolve().parents[4]
    sys.path.append(str(project_root))
    import config
except Exception as e:
    print("Failed to load config.py:", e)
    sys.exit(1)

ROOT_DIR = config.HUMAN_DATASET_DIR
OUTPUT_CSV = config.HUMAN_FEATURES_EXTENDED_CSV

MIN_DUP_BLOCK_LINES = config.MIN_DUP_BLOCK_LINES
TOO_MANY_LOCALS_THRESHOLD = config.TOO_MANY_LOCALS_THRESHOLD

PYLINT_TIMEOUT = config.PYLINT_TIMEOUT
PYLINT_ENABLED = config.PYLINT_ENABLED

OUTPUT_CSV.parent.mkdir(parents=True, exist_ok=True)

# =============================================================================
# 2. RADON CHECK
# =============================================================================

RADON_AVAILABLE = False

try:
    from radon.complexity import cc_visit
    from radon.metrics import mi_visit, h_visit
    RADON_AVAILABLE = True
except Exception as e:
    print("Radon not available:", e)

# =============================================================================
# 3. BASIC UTILITIES
# =============================================================================

def read_file_utf8(path: str) -> str:
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    except:
        return ""

def count_nonblank_noncomment_lines(code: str) -> int:
    count = 0
    for line in code.splitlines():
        s = line.strip()
        if s and not s.startswith("#"):
            count += 1
    return count

# =============================================================================
# 4. AST ANALYZER
# =============================================================================

class CodeASTAnalyzer(ast.NodeVisitor):

    def __init__(self):

        self.num_functions = 0
        self.function_spans = []
        self.identifiers = []

        self.list_comprehensions = 0
        self.dict_comprehensions = 0
        self.set_comprehensions = 0
        self.for_loops = 0
        self.generator_expr = 0
        self.yield_count = 0
        self.joinedstr_count = 0
        self.try_count = 0

        self.import_count = 0
        self.third_party_import_count = 0

        self.typehinted_functions = 0
        self.max_ast_depth = 0
        self._depth = 0

        self.local_vars_by_function = []
        self._current_locals = set()
        self._in_function = False

    def visit_FunctionDef(self, node):

        self.num_functions += 1

        start = getattr(node, "lineno", None)
        end = getattr(node, "end_lineno", None)

        if start and end:
            self.function_spans.append((start, end))

        has_hint = False

        if node.returns is not None:
            has_hint = True

        for a in node.args.args:
            if a.annotation is not None:
                has_hint = True

        if has_hint:
            self.typehinted_functions += 1

        prev_state = self._in_function
        prev_locals = self._current_locals

        self._in_function = True
        self._current_locals = set()

        self.generic_visit(node)

        self.local_vars_by_function.append(len(self._current_locals))

        self._current_locals = prev_locals
        self._in_function = prev_state

    def visit_Assign(self, node):

        for t in node.targets:

            if isinstance(t, ast.Name):

                name = t.id
                self.identifiers.append(name)

                if self._in_function:
                    self._current_locals.add(name)

        self.generic_visit(node)

    def visit_Name(self, node):

        if isinstance(node.id, str):
            self.identifiers.append(node.id)

        self.generic_visit(node)

    def visit_ListComp(self,node):
        self.list_comprehensions+=1
        self.generic_visit(node)

    def visit_DictComp(self,node):
        self.dict_comprehensions+=1
        self.generic_visit(node)

    def visit_SetComp(self,node):
        self.set_comprehensions+=1
        self.generic_visit(node)

    def visit_For(self,node):
        self.for_loops+=1
        self.generic_visit(node)

    def visit_GeneratorExp(self,node):
        self.generator_expr+=1
        self.generic_visit(node)

    def visit_Yield(self,node):
        self.yield_count+=1
        self.generic_visit(node)

    def visit_JoinedStr(self,node):
        self.joinedstr_count+=1
        self.generic_visit(node)

    def visit_Try(self,node):
        self.try_count+=1
        self.generic_visit(node)

    def visit_Import(self,node):

        self.import_count+=1

        for n in node.names:

            base=n.name.split(".")[0]

            if base not in sys.builtin_module_names:
                self.third_party_import_count+=1

        self.generic_visit(node)

    def visit_ImportFrom(self,node):

        self.import_count+=1

        module=node.module

        if module:

            base=module.split(".")[0]

            if base not in sys.builtin_module_names:
                self.third_party_import_count+=1

        self.generic_visit(node)

    def generic_visit(self,node):

        control = isinstance(node,(ast.If,ast.For,ast.While,ast.Try,ast.With))

        if control:

            self._depth+=1

            if self._depth>self.max_ast_depth:
                self.max_ast_depth=self._depth

            super().generic_visit(node)

            self._depth-=1

        else:
            super().generic_visit(node)

# =============================================================================
# 5. DUPLICATE CODE DETECTOR
# =============================================================================

def duplicate_lines_ratio(code: str, block_size=3):

    lines=[l.rstrip() for l in code.splitlines()]
    n=len(lines)

    if n<block_size:
        return 0.0

    seen=defaultdict(list)
    dup=set()

    for i in range(n-block_size+1):

        block="\n".join(lines[i:i+block_size]).strip()

        if not block:
            continue

        h=hashlib.sha1(block.encode()).hexdigest()

        if h in seen:
            dup.update(range(i,i+block_size))

        seen[h].append(i)

    non_empty=sum(1 for l in lines if l.strip())

    if non_empty==0:
        return 0.0

    return len(dup)/non_empty

# =============================================================================
# 6. RADON WRAPPERS
# =============================================================================

def safe_cc_visit(code):

    if not RADON_AVAILABLE:
        return []

    try:
        return cc_visit(code)
    except:
        return []

def safe_mi(code):

    if not RADON_AVAILABLE:
        return None

    try:
        return mi_visit(code,True)
    except:
        return None

def safe_halstead(code):

    if not RADON_AVAILABLE:
        return None

    try:
        h=h_visit(code)

        if isinstance(h,dict):
            return h.get("effort")

        return getattr(h,"effort",None)

    except:
        return None

# =============================================================================
# 7. PYLINT
# =============================================================================

def run_pylint(path):

    if not PYLINT_ENABLED:
        return [],None

    msgs=[]
    score=None

    try:

        cmd_json=[sys.executable,"-m","pylint","--output-format=json",path]
        cmd_score=[sys.executable,"-m","pylint",path]

        try:

            p=subprocess.run(cmd_json,capture_output=True,text=True,timeout=PYLINT_TIMEOUT)

            if p.stdout.strip():
                msgs=json.loads(p.stdout)

        except:
            pass

        try:

            p2=subprocess.run(cmd_score,capture_output=True,text=True,timeout=PYLINT_TIMEOUT)

            txt=(p2.stdout or "")+(p2.stderr or "")

            m=re.search(r"rated at\s+([-+]?\d*\.?\d+)\s*/10",txt,re.I)

            if m:
                score=float(m.group(1))

        except:
            pass

    except Exception as e:
        print("pylint failed:",e)

    return msgs,score

# =============================================================================
# 8. FEATURE EXTRACTION
# =============================================================================

def extract_features_from_file(path):

    code=read_file_utf8(path)

    if not code.strip():
        return None

    raw_loc=len(code.splitlines())
    effective_loc=count_nonblank_noncomment_lines(code)

    LOC_log=math.log1p(raw_loc)

    analyzer=CodeASTAnalyzer()

    try:
        tree=ast.parse(code)
        analyzer.visit(tree)
    except:
        pass

    func_cc=[b.complexity for b in safe_cc_visit(code)]

    total_cc=sum(func_cc) if func_cc else 0
    max_cc=max(func_cc) if func_cc else 0

    mi=safe_mi(code)

    hal=safe_halstead(code)
    hal_log=math.log1p(hal) if hal else 0

    dup_ratio=duplicate_lines_ratio(code)

    pylint_msgs,pylint_score=run_pylint(path)

    return {

    "file":os.path.basename(path),

    "raw_loc":raw_loc,
    "effective_loc":effective_loc,
    "LOC_log":LOC_log,

    "num_functions":analyzer.num_functions,

    "identifier_avg_length":(
        sum(len(x) for x in analyzer.identifiers)/len(analyzer.identifiers)
        if analyzer.identifiers else 0
    ),

    "comprehension_count":(
        analyzer.list_comprehensions+
        analyzer.dict_comprehensions+
        analyzer.set_comprehensions
    ),

    "for_loop_count":analyzer.for_loops,

    "generator_usage":1 if (analyzer.generator_expr+analyzer.yield_count)>0 else 0,

    "try_except_count":analyzer.try_count,

    "import_count":analyzer.import_count,

    "third_party_imports":analyzer.third_party_import_count,

    "type_hint_ratio":(
        analyzer.typehinted_functions/analyzer.num_functions
        if analyzer.num_functions else 0
    ),

    "max_nesting_depth":analyzer.max_ast_depth,

    "too_many_locals_count":sum(
        1 for c in analyzer.local_vars_by_function
        if c>TOO_MANY_LOCALS_THRESHOLD
    ),

    "total_cc":total_cc,
    "max_cc":max_cc,

    "maintainability_index":mi,
    "halstead_effort_log":hal_log,

    "duplicate_lines_ratio":dup_ratio,

    "pylint_warning_count":len(pylint_msgs),

    "pylint_score":pylint_score,

    "RADON_AVAILABLE":RADON_AVAILABLE
    }

# =============================================================================
# 9. DATASET WALKER
# =============================================================================

def extract_all(root_dir,out_csv):

    rows=[]

    for root,dirs,files in os.walk(root_dir):

        for f in files:

            if not f.endswith(".py"):
                continue

            path=os.path.join(root,f)

            row=extract_features_from_file(path)

            if row:
                rows.append(row)

    if not rows:
        print("No features extracted")
        return

    keys=list(rows[0].keys())

    with open(out_csv,"w",newline="",encoding="utf-8-sig") as f:

        w=csv.DictWriter(f,fieldnames=keys)

        w.writeheader()
        w.writerows(rows)

    print("Saved:",out_csv)

# =============================================================================
# 10. RUN
# =============================================================================

if __name__=="__main__":

    print("Human code feature extraction started")

    print("INPUT:",ROOT_DIR)
    print("OUTPUT:",OUTPUT_CSV)

    start=time.time()

    extract_all(ROOT_DIR,OUTPUT_CSV)

    print("Finished in",round(time.time()-start,2),"seconds")
