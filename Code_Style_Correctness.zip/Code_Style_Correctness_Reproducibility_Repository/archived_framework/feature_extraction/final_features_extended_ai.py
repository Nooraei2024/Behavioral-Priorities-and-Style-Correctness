# =============================================================================
# STRUCTURAL FEATURE EXTRACTION FOR AI GENERATED CODE (EXTENDED)
# =============================================================================
# Part of the Centralized Research Pipeline
# =============================================================================

import os
import sys
import csv
import math
import json
import re
import ast
import time
import hashlib
import subprocess
from collections import defaultdict
from typing import Dict, Any, List, Tuple
from pathlib import Path

# -----------------------------------------------------------------------------
# 1. DYNAMIC PATH RESOLUTION & CONFIG IMPORT
# -----------------------------------------------------------------------------
# پیدا کردن ریشه اصلی پروژه به صورت داینامیک
# این اسکریپت در مسیر زیر قرار دارد:
# ROOT/1. DATA SOURCE/3. Structural Feature Extraction/AI Codes/scripts/final_ai_features_extended.py
# با رفتن به 5 پوشه قبل (parents[4]) به ریشه اصلی پروژه می‌رسیم.
try:
    project_root = Path(__file__).resolve().parents[4]
    sys.path.append(str(project_root))
    import config
except Exception as e:
    print(f"[Error] Failed to import central config.py. Ensure your directory structure is correct. Details: {e}")
    sys.exit(1)

# -----------------------------------------------------------------------------
# 2. CONFIGURATION PARAMETERS (MAPPED FROM config.py)
# -----------------------------------------------------------------------------
ROOT_DIR = config.AI_DATASET_DIR               # پوشه ورودی کدهای هوش مصنوعی
OUTPUT_CSV = config.AI_FEATURES_EXTENDED_CSV     # فایل خروجی ویژگی‌ها

MIN_DUP_BLOCK_LINES = config.MIN_DUP_BLOCK_LINES
TOO_MANY_LOCALS_THRESHOLD = config.TOO_MANY_LOCALS_THRESHOLD

PYLINT_TIMEOUT = config.PYLINT_TIMEOUT
PYLINT_ENABLED = config.PYLINT_ENABLED

# اطمینان از وجود پوشه خروجی (پوشه outputs مربوط به AI Codes)
OUTPUT_CSV.parent.mkdir(parents=True, exist_ok=True)

# -----------------------------------------------------------------------------
# 3. RADON ACCESSIBILITY CHECK
# -----------------------------------------------------------------------------
RADON_AVAILABLE = False
try:
    from radon.complexity import cc_visit
    from radon.metrics import mi_visit, h_visit
    RADON_AVAILABLE = True
except Exception as e:
    print("Radon not available or import failed:", e)
    RADON_AVAILABLE = False


# -----------------------------------------------------------------------------
# 4. UTILITY FUNCTIONS
# -----------------------------------------------------------------------------
def read_file_utf8(path: str) -> str:
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    except Exception as e:
        print(f"[read_file] Error reading {path}: {e}")
        return ""


def count_nonblank_noncomment_lines(code: str) -> int:
    cnt = 0
    for ln in code.splitlines():
        s = ln.strip()
        if not s:
            continue
        if s.startswith("#"):
            continue
        cnt += 1
    return cnt


# -----------------------------------------------------------------------------
# 5. AST ANALYZER CLASS
# -----------------------------------------------------------------------------
class CodeASTAnalyzer(ast.NodeVisitor):
    def __init__(self):
        self.num_functions = 0
        self.function_spans = []  # list of (start,end)
        self.identifiers = []

        self.list_comprehensions = 0
        self.dict_comprehensions = 0
        self.set_comprehensions = 0
        self.for_loops = 0
        self.generator_expr = 0
        self.yield_count = 0
        self.joinedstr_count = 0
        self.try_count = 0
        self.import_count = 0
        self.third_party_import_count = 0
        self.typehinted_functions = 0
        self.max_ast_depth = 0
        self._current_depth = 0

        self.local_vars_by_function = []
        self._current_func_locals = set()
        self._in_function = False

    def visit_FunctionDef(self, node: ast.FunctionDef):
        self.num_functions += 1
        start = getattr(node, "lineno", None)
        end = getattr(node, "end_lineno", None)
        if start and end:
            self.function_spans.append((start, end))

        # type hints detection
        has_hint = False
        args = getattr(node, "args", None)
        if args:
            for a in getattr(args, "args", []):
                if getattr(a, "annotation", None) is not None:
                    has_hint = True
                    break
        if getattr(node, "returns", None) is not None:
            has_hint = True
        if has_hint:
            self.typehinted_functions += 1

        # local var tracking inside function
        prev_in_function = self._in_function
        prev_locals = self._current_func_locals
        self._in_function = True
        self._current_func_locals = set()

        self.generic_visit(node)

        self.local_vars_by_function.append(len(self._current_func_locals))
        self._current_func_locals = prev_locals
        self._in_function = prev_in_function

    def visit_Assign(self, node: ast.Assign):
        targets = node.targets
        for t in targets:
            names = self._collect_names(t)
            for n in names:
                if isinstance(n, str):
                    self.identifiers.append(n)
                    if self._in_function:
                        self._current_func_locals.add(n)
        self.generic_visit(node)

    def _collect_names(self, node):
        names = []
        if isinstance(node, ast.Name):
            names.append(node.id)
        elif isinstance(node, (ast.Tuple, ast.List)):
            for elt in node.elts:
                names += self._collect_names(elt)
        elif isinstance(node, ast.Attribute):
            names.append(node.attr)
        return names

    def visit_Name(self, node: ast.Name):
        if isinstance(node.id, str):
            self.identifiers.append(node.id)
        self.generic_visit(node)

    def visit_ListComp(self, node: ast.ListComp):
        self.list_comprehensions += 1
        self.generic_visit(node)

    def visit_DictComp(self, node: ast.DictComp):
        self.dict_comprehensions += 1
        self.generic_visit(node)

    def visit_SetComp(self, node: ast.SetComp):
        self.set_comprehensions += 1
        self.generic_visit(node)

    def visit_For(self, node: ast.For):
        self.for_loops += 1
        self.generic_visit(node)

    def visit_GeneratorExp(self, node: ast.GeneratorExp):
        self.generator_expr += 1
        self.generic_visit(node)

    def visit_Yield(self, node: ast.Yield):
        self.yield_count += 1
        self.generic_visit(node)

    def visit_JoinedStr(self, node: ast.JoinedStr):
        self.joinedstr_count += 1
        self.generic_visit(node)

    def visit_Try(self, node: ast.Try):
        self.try_count += 1
        self.generic_visit(node)

    def visit_Import(self, node: ast.Import):
        self.import_count += 1
        for n in node.names:
            base = n.name.split(".")[0]
            if base not in sys.builtin_module_names and base != "__future__":
                self.third_party_import_count += 1
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom):
        self.import_count += 1
        module = getattr(node, "module", None)
        if module:
            base = module.split(".")[0]
            if base not in sys.builtin_module_names and base != "__future__":
                self.third_party_import_count += 1
        self.generic_visit(node)

    def generic_visit(self, node):
        is_cf = isinstance(node, (ast.If, ast.For, ast.While, ast.Try, ast.With))
        if is_cf:
            self._current_depth += 1
            if self._current_depth > self.max_ast_depth:
                self.max_ast_depth = self._current_depth
            super().generic_visit(node)
            self._current_depth -= 1
        else:
            super().generic_visit(node)


# -----------------------------------------------------------------------------
# 6. DUPLICATE DETECTOR
# -----------------------------------------------------------------------------
def duplicate_lines_ratio(code: str, block_size: int = MIN_DUP_BLOCK_LINES) -> float:
    lines = [ln.rstrip() for ln in code.splitlines()]
    n = len(lines)
    if n < block_size:
        return 0.0
    seen = defaultdict(list)
    duplicates = set()
    for i in range(0, n - block_size + 1):
        block = "\n".join(lines[i:i + block_size]).strip()
        if not block:
            continue
        h = hashlib.sha1(block.encode("utf-8")).hexdigest()
        if h in seen:
            duplicates.update(range(i, i + block_size))
        seen[h].append(i)
    total_nonempty = sum(1 for ln in lines if ln.strip())
    return len(duplicates) / total_nonempty if total_nonempty else 0.0


# -----------------------------------------------------------------------------
# 7. RADON METRICS WRAPPERS
# -----------------------------------------------------------------------------
def safe_cc_visit(code: str) -> List:
    if not RADON_AVAILABLE:
        return []
    try:
        return cc_visit(code)
    except Exception:
        return []


def safe_mi_visit(code: str):
    if not RADON_AVAILABLE:
        return None
    try:
        return mi_visit(code, True)
    except Exception:
        return None


def safe_halstead_effort(code: str):
    if not RADON_AVAILABLE:
        return None
    try:
        hv = h_visit(code)
        if isinstance(hv, dict):
            return hv.get("effort", None)
        return getattr(hv, "effort", None)
    except Exception:
        return None


# -----------------------------------------------------------------------------
# 8. PYLINT RUNNER ENGINE
# -----------------------------------------------------------------------------
def run_pylint(path: str, timeout_sec: int = PYLINT_TIMEOUT):
    if not PYLINT_ENABLED:
        return [], None

    msgs = []
    score = None

    try:
        cmd_json = [sys.executable, "-m", "pylint", "--output-format=json", path]
        cmd_score = [sys.executable, "-m", "pylint", path]

        # --- JSON Execution ---
        try:
            proc = subprocess.run(
                cmd_json,
                capture_output=True,
                text=True,
                timeout=timeout_sec,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
            )
            if proc.stdout.strip():
                try:
                    msgs = json.loads(proc.stdout)
                except Exception:
                    text = proc.stdout
                    start = text.find("[")
                    end = text.rfind("]") + 1
                    if start != -1 and end > start:
                        try:
                            msgs = json.loads(text[start:end])
                        except Exception:
                            msgs = []
        except Exception:
            pass

        # --- Score Execution ---
        try:
            proc2 = subprocess.run(
                cmd_score,
                capture_output=True,
                text=True,
                timeout=timeout_sec,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
            )
            full_text = (proc2.stdout or "") + (proc2.stderr or "")

            patterns = [
                r"rated at\s+([-+]?\d*\.?\d+)\s*/10",
                r"Your code has been rated at\s+([-+]?\d*\.?\d+)\s*/10",
                r"global note:\s+([-+]?\d*\.?\d+)"
            ]
            for pat in patterns:
                m = re.search(pat, full_text, re.IGNORECASE)
                if m:
                    try:
                        score = float(m.group(1))
                        break
                    except Exception:
                        pass
        except Exception:
            pass

    except Exception as e:
        print(f"[pylint] failed: {e}")

    return msgs, score


# -----------------------------------------------------------------------------
# 9. HELPER: PER-FUNCTION AST COMPLEXITY
# -----------------------------------------------------------------------------
def function_ccs_by_ast(code: str, function_spans: List[Tuple[int, int]]) -> List[float]:
    results = []
    for span in function_spans:
        try:
            start, end = span
            lines = code.splitlines()
            if not start or not end or start < 1 or end > len(lines):
                results.append(0.0)
                continue
            snippet = "\n".join(lines[start - 1:end])
            if RADON_AVAILABLE:
                try:
                    blocks = cc_visit(snippet)
                    cvals = [
                        getattr(b, "complexity", 0)
                        for b in blocks
                        if getattr(b, "complexity", None) is not None
                    ]
                    results.append(max(cvals) if cvals else 0.0)
                    continue
                except Exception:
                    pass
            results.append(0.0)
        except Exception:
            results.append(0.0)
    return results


# -----------------------------------------------------------------------------
# 10. MAIN FEATURE EXTRACTION PIPELINE
# -----------------------------------------------------------------------------
def extract_features_from_file(path: str) -> Dict[str, Any]:
    code = read_file_utf8(path)
    if code is None or code.strip() == "":
        return None

    raw_loc_total = len(code.splitlines())
    raw_effective_loc = count_nonblank_noncomment_lines(code)
    effective_loc_ratio = raw_effective_loc / raw_loc_total if raw_loc_total else 0.0
    LOC_log = math.log1p(raw_loc_total)

    # AST analysis
    analyzer = CodeASTAnalyzer()
    try:
        tree = ast.parse(code)
        analyzer.visit(tree)
    except Exception:
        pass

    num_functions = analyzer.num_functions
    avg_function_loc = 0.0
    if analyzer.function_spans:
        sizes = []
        for s, e in analyzer.function_spans:
            if s and e and e >= s:
                sizes.append(e - s + 1)
        if sizes:
            avg_function_loc = float(sum(sizes)) / len(sizes)

    # CC metrics
    func_ccs = function_ccs_by_ast(code, analyzer.function_spans)
    avg_cc_per_function = float(sum(func_ccs)) / len(func_ccs) if func_ccs else 0.0

    raw_cc_blocks = safe_cc_visit(code)
    cc_list = [
        getattr(b, "complexity", 0)
        for b in raw_cc_blocks
        if getattr(b, "complexity", None) is not None
    ]
    total_cc = float(sum(cc_list)) if cc_list else 0.0
    max_cc = float(max(cc_list)) if cc_list else 0.0
    CC_total_norm = total_cc / raw_loc_total if raw_loc_total else 0.0

    # MI
    mi_val = safe_mi_visit(code)
    mi_val = float(mi_val) if (mi_val is not None) else None

    # Halstead effort
    hal_eff = safe_halstead_effort(code)
    halstead_effort_log = math.log1p(hal_eff) if (hal_eff is not None) else 0.0

    # duplication
    dup_ratio = duplicate_lines_ratio(code, block_size=MIN_DUP_BLOCK_LINES)

    # identifiers & naming
    idents = [s for s in analyzer.identifiers if isinstance(s, str) and s]
    identifier_avg_length = float(sum(len(x) for x in idents) / len(idents)) if idents else 0.0
    descriptive_id_ratio = float(sum(1 for x in idents if len(x) > 2) / len(idents)) if idents else 0.0

    # comprehensions / loops
    comp_count = (
        analyzer.list_comprehensions
        + analyzer.dict_comprehensions
        + analyzer.set_comprehensions
    )
    loop_count = analyzer.for_loops
    comprehension_ratio = float(comp_count / (comp_count + loop_count)) if (comp_count + loop_count) else 0.0

    # generator usage
    generator_usage = 1 if (analyzer.generator_expr + analyzer.yield_count) > 0 else 0

    # string formatting
    fstring_count = analyzer.joinedstr_count
    format_count = len(re.findall(r"\.format\s*\(", code))
    plus_concat_count = len(re.findall(r"['\"].+?['\"]\s*\+\s*[^#\n]+", code))
    denom = fstring_count + format_count + plus_concat_count
    fstring_ratio = float(fstring_count / denom) if denom else 0.0

    # exceptions
    try_except_count = analyzer.try_count
    try_except_per_LOC = float(try_except_count / raw_loc_total) if raw_loc_total else 0.0

    # imports / modularity
    import_count = analyzer.import_count
    third_party_imports = analyzer.third_party_import_count
    type_hint_ratio = float(analyzer.typehinted_functions / analyzer.num_functions) if analyzer.num_functions else 0.0
    modularity_ratio = float(num_functions / raw_loc_total) if raw_loc_total else 0.0
    too_many_locals_count = int(sum(1 for c in analyzer.local_vars_by_function if c > TOO_MANY_LOCALS_THRESHOLD))

    # Pylint
    pylint_msgs, pylint_score = run_pylint(path)
    pylint_refactor_count = int(
        sum(1 for m in pylint_msgs if (m.get("type", "") or "").lower() in ("convention", "refactor"))
    )
    pylint_warning_count = int(
        sum(1 for m in pylint_msgs if (m.get("type", "") or "").lower() in ("warning", "error", "fatal"))
    )
    pylint_refactor_per_loc = float(pylint_refactor_count / raw_loc_total) if raw_loc_total else 0.0
    pylint_warnings_per_loc = float(pylint_warning_count / raw_loc_total) if raw_loc_total else 0.0

    features = {
        "file": os.path.basename(path),
        "raw_loc": int(raw_loc_total),
        "effective_loc": int(raw_effective_loc),
        "LOC_log": float(LOC_log),
        "effective_loc_ratio": float(effective_loc_ratio),

        "num_functions": int(num_functions),
        "avg_function_loc": float(avg_function_loc),
        "identifier_avg_length": float(identifier_avg_length),
        "descriptive_id_ratio": float(descriptive_id_ratio),

        "comprehension_count": int(comp_count),
        "for_loop_count": int(loop_count),
        "comprehension_ratio": float(comprehension_ratio),
        "generator_usage": int(generator_usage),

        "fstring_ratio": float(fstring_ratio),

        "try_except_count": int(try_except_count),
        "try_except_per_LOC": float(try_except_per_LOC),

        "import_count": int(import_count),
        "third_party_imports": int(third_party_imports),
        "type_hint_ratio": float(type_hint_ratio),
        "modularity_ratio": float(modularity_ratio),
        "too_many_locals_count": int(too_many_locals_count),

        "avg_cc_per_function": float(avg_cc_per_function),
        "total_cc": float(total_cc),
        "CC_total_norm": float(CC_total_norm),
        "max_cc": float(max_cc),
        "maintainability_index": float(mi_val) if (mi_val is not None) else None,
        "halstead_effort_log": float(halstead_effort_log),

        "duplicate_lines_ratio": float(dup_ratio),
        "max_nesting_depth": int(analyzer.max_ast_depth),

        "pylint_refactor_count": int(pylint_refactor_count),
        "pylint_refactor_warnings_per_LOC": float(pylint_refactor_per_loc),
        "pylint_warning_count": int(pylint_warning_count),
        "pylint_warnings_per_LOC": float(pylint_warnings_per_loc),
        "pylint_score": float(pylint_score) if pylint_score is not None else None,

        "RADON_AVAILABLE": bool(RADON_AVAILABLE),
    }
    return features


# -----------------------------------------------------------------------------
# 11. WALK FOLDER AND EXTRACT
# -----------------------------------------------------------------------------
def extract_all(root_dir: Path, out_csv: Path):
    rows = []
    files_processed = 0

    # تبدیل شیء Path به رشته برای سازگاری با os.walk
    for root, dirs, files in os.walk(str(root_dir)):
        for fname in sorted(files):
            if not fname.endswith(".py"):
                continue
            full_path = Path(root) / fname
            files_processed += 1
            if files_processed % 50 == 0:
                print(f"Processed: {files_processed} files...")

            try:
                row = extract_features_from_file(str(full_path))
                if row:
                    rows.append(row)
            except Exception as e:
                print(f"[extract_all] Error on {full_path}: {e}")

    if not rows:
        print("No features extracted.")
        return

    keys = [
        "file", "raw_loc", "effective_loc", "LOC_log", "effective_loc_ratio",
        "num_functions", "avg_function_loc", "identifier_avg_length", "descriptive_id_ratio",
        "comprehension_count", "for_loop_count", "comprehension_ratio", "generator_usage",
        "fstring_ratio", "try_except_count", "try_except_per_LOC",
        "import_count", "third_party_imports", "type_hint_ratio", "modularity_ratio", "too_many_locals_count",
        "avg_cc_per_function", "total_cc", "CC_total_norm", "max_cc", "maintainability_index", "halstead_effort_log",
        "duplicate_lines_ratio", "max_nesting_depth",
        "pylint_refactor_count", "pylint_refactor_warnings_per_LOC",
        "pylint_warning_count", "pylint_warnings_per_LOC", "pylint_score",
        "RADON_AVAILABLE",
    ]

    for r in rows:
        for k in keys:
            if k not in r:
                r[k] = None

    # نوشتن مستقیم در مسیر فایل مشخص‌شده در کانفیگ
    with open(out_csv, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)

    print(f"Done. Wrote {len(rows)} rows to {out_csv}")


# -----------------------------------------------------------------------------
# 12. RUN EXECUTOR
# -----------------------------------------------------------------------------
if __name__ == "__main__":
    print("Starting feature extraction (AI Generated Code).")
    print("ROOT_DIR (Input Folder):", ROOT_DIR)
    print("OUTPUT_CSV (Output File):", OUTPUT_CSV)
    print("RADON_AVAILABLE:", RADON_AVAILABLE)
    print("PYLINT_ENABLED:", PYLINT_ENABLED)
    
    start = time.time()
    extract_all(ROOT_DIR, OUTPUT_CSV)
    print("Elapsed Time (seconds):", round(time.time() - start, 2))
