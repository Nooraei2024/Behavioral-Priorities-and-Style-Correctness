import sys

def longest_non_decreasing_subsequence(s):
    n = len(s)
    dp = [[0] * (n + 1) for _ in range(n + 1)]
    
    for i in range(1, n + 1):
        for j in range(i, n + 1):
            if s[i - 1] <= s[j - 1]:
                dp[i][j] = max(dp[i][j], dp[i - 1][j - 1] + 1)
            else:
                dp[i][j] = max(dp[i][j], dp[i - 1][j])
    
    return dp[n][n]

if __name__ == "__main__":
    s = sys.stdin.readline().strip()
    print(longest_non_decreasing_subsequence(s))