import sys

def find_mex(n, m):
    seen = set()
    for i in range(n, n + m + 1):
        if i not in seen:
            seen.add(i)
    return min(seen)

t = int(input())
for _ in range(t):
    n, m = map(int, input().split())
    print(find_mex(n, m))