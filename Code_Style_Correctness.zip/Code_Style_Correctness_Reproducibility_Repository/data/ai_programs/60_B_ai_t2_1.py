import sys

# Read input from stdin
input_string = sys.stdin.readline().strip()

# Split the input string into a list of strings, separated by spaces
input_list = input_string.split(" ")

# Get the values of k, n, and m from the input list
k = int(input_list[0])
n = int(input_list[1])
m = int(input_list[2])

# Initialize a 2D array to represent the plate
plate = [["." for _ in range(m)] for _ in range(n)]

# Fill the plate with obstacles based on the input string
for i in range(k):
    for j in range(n):
        for k in range(m):
            if input_string[i * n * m + j * m + k] == "#":
                plate[j][k] = "#"

# Initialize a variable to keep track of the number of empty squares
empty_squares = 0

# Iterate over the plate and count the number of empty squares
for i in range(n):
    for j in range(m):
        if plate[i][j] == ".":
            empty_squares += 1

# Print the number of empty squares
print(empty_squares)