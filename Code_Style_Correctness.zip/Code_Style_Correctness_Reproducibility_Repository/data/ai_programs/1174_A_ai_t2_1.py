import sys

def solve(a):
    n = len(a) // 2
    if sum(a[:n]) == sum(a[n:]):
        return -1
    else:
        return 0

if __name__ == '__main__':
    input = sys.stdin.readline().strip()
    n = int(input)
    a = list(map(int, input.split()))
    print(solve(a))