import sys

n = int(input())
r1, c1 = map(int, input().split())
r2, c2 = map(int, input().split())

# Check if the destination cell is land
if (r2, c2) in [(i, j) for i in range(1, n + 1) for j in range(1, n + 1)]:
    # Calculate the distance between the two cells
    dr = r2 - r1
    dc = c2 - c1
    # Check if the destination cell is reachable
    if abs(dr) + abs(dc) <= 1:
        print("YES")
    else:
        print("NO")
else:
    print("NO")