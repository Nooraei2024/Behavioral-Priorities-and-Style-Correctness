import sys

def is_multihedgehog(G):
    # Check if G is a hedgehog
    if len(G) == 1 and G.degree(0) >= 3:
        return True
    
    # Check if G is a (k-1)-multihedgehog for some k > 1
    for v in G:
        if G.degree(v) == 1:
            continue
        
        subgraph = G.subgraph([v])
        if is_multihedgehog(subgraph):
            return True
    
    return False

# Read input from standard input
input_str = sys.stdin.readline()

# Parse the input string into a graph
G = eval(input_str)

# Check if G is a multihedgehog
if is_multihedgehog(G):
    print("Yes")
else:
    print("No")