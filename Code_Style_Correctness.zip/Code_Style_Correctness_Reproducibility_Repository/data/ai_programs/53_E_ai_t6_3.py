import sys

n, m = map(int, input().split())
junctions = []
two_way_roads = []
for _ in range(m):
    a, b = map(int, input().split())
    junctions.append((a, b))
    two_way_roads.append((a, b))
    two_way_roads.append((b, a))

dead_ends = []
for i in range(n):
    if len(set(junctions[i])) == 1:
        dead_ends.append(i)

print(*dead_ends, sep='\n')