import sys

# Read input from stdin
n = int(sys.stdin.readline().strip())
seats = []
for i in range(1, n + 1):
    row = sys.stdin.readline().strip()
    seats.append([])
    for j in range(0, len(row)):
        if row[j] == 'a' or row[j] == 'f':
            seats[-1].append('w')
        elif row[j] == 'b' or row[j] == 'e':
            seats[-1].append('n')
        else:
            seats[-1].append('s')

# Output to stdout
for i in range(0, len(seats)):
    for j in range(0, len(seats[i])):
        print(seats[i][j], end='')
    print()