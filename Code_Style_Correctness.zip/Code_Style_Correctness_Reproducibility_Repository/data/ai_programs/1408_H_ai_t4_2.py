import sys

def rainbow_triples(a):
    n = len(a)
    m = 0
    for i in range(n-2):
        for j in range(i+1, n-1):
            for k in range(j+1, n):
                if a[i] == 0 and a[k] == 0 and a[j] != 0:
                    m += 1
    return m

for case in range(int(sys.stdin.readline())):
    n = int(sys.stdin.readline())
    a = [int(x) for x in sys.stdin.readline().split()]
    print(rainbow_triples(a))