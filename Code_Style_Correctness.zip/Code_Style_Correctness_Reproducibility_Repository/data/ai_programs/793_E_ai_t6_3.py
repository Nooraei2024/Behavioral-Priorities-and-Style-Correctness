import sys

def solve(input_str):
    # Read the input string from stdin
    input_str = sys.stdin.readline().strip()
    
    # Split the input string into a list of collectors and their routes
    collectors, routes = input_str.split(';')
    
    # Initialize an empty dictionary to store the collected cash
    collected_cash = {}
    
    # Loop through each collector's route and update the collected cash
    for collector, route in zip(collectors, routes):
        for office in route.split(','):
            collected_cash[office] = collected_cash.get(office, 0) + int(collector)
    
    # Output the maximum amount of cash collected by any collector
    return max(collected_cash.values())

# Test the solution with the example input
example_input = "1234;12,34"
print(solve(example_input))