import sys

def array_k_coloring(a, k):
    # create a dictionary to store the number of elements in each color
    colors = {i: 0 for i in range(1, k+1)}
    
    # loop through the array and update the dictionary with the number of elements in each color
    for element in a:
        colors[element] += 1
    
    # check if all conditions are met
    for i in range(1, k+1):
        if colors[i] == 0:
            return "NO"
        for j in range(1, k+1):
            if i != j and colors[j] == 0:
                return "NO"
    
    # if all conditions are met, print "YES" and any coloring (i.e. numbers from 1 to k)
    print("YES")
    for i in range(1, k+1):
        print(i, end=" ")