import sys

# Read input from stdin
n, m = map(int, sys.stdin.readline().split())
boxes = list(map(int, sys.stdin.readline().split()))

# Initialize variables
doll_position = 0
correct_guesses = 0

# Loop through each guess
for i in range(m):
    # Get the current guess from stdin
    guess = int(sys.stdin.readline()) - 1

    # Check if the guess is correct
    if guess == doll_position:
        # If the guess is correct, increment the number of correct guesses
        correct_guesses += 1

        # Update the position of the doll to a new random box
        doll_position = random.choice(boxes)

    # Otherwise, print an error message
    else:
        print("Error: incorrect guess")

# Check if Alice won the game
if correct_guesses == m:
    print("Alice wins!")
else:
    print("Marisa wins!")