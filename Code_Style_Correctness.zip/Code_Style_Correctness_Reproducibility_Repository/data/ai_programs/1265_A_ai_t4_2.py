import sys

def is_beautiful(s):
    for i in range(len(s) - 1):
        if s[i] == s[i + 1]:
            return False
    return True

if __name__ == '__main__':
    s = sys.stdin.readline().strip()
    if is_beautiful(s):
        print(s)
    else:
        for i in range(len(s)):
            if s[i] == '?':
                for c in ['a', 'b', 'c']:
                    new_s = s[:i] + c + s[i + 1:]
                    if is_beautiful(new_s):
                        print(new_s)
                        break