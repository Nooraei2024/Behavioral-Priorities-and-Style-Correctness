import sys

# Read input from stdin
n = int(sys.stdin.readline())
x = []
for i in range(n):
    x.append(int(sys.stdin.readline()))
y = int(sys.stdin.readline())
z = int(sys.stdin.readline())

# Initialize the dictionary to store the number of swords of each type
sword_count = {}
for i in range(n):
    sword_count[i] = x[i]

# Update the dictionary with the number of swords taken by each person
for i in range(y):
    type, count = sys.stdin.readline().split()
    type = int(type) - 1
    count = int(count)
    sword_count[type] -= count

# Print the number of swords of each type that are left in the basement
for i in range(n):
    print(sword_count[i])