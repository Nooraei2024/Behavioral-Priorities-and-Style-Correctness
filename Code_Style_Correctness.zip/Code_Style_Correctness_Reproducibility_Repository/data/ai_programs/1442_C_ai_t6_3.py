import sys

# Read input from standard input (stdin)
n, m = map(int, input().split())
graph = {}
for _ in range(m):
    u, v = map(int, input().split())
    if u not in graph:
        graph[u] = []
    graph[u].append(v)

# Perform graph transpositions
transpositions = 0
while True:
    # Check if there are any edges to transpose
    has_edges = False
    for u in graph:
        for v in graph[u]:
            if v not in graph or u not in graph[v]:
                has_edges = True
                break
        if has_edges:
            break
    # If there are no more edges to transpose, stop
    if not has_edges:
        break
    # Perform the next transposition
    transpositions += 1
    for u in graph:
        for v in graph[u]:
            if v in graph and u in graph[v]:
                graph[v].remove(u)
                graph[u].append(v)

# Output the number of transpositions needed
print(transpositions)