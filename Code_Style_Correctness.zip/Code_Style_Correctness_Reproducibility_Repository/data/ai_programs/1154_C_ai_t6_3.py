import datetime

# Get the current day of the week as a string
day = datetime.datetime.today().strftime("%A")

# Determine the type of food to eat based on the day of the week
if day == "Monday" or day == "Thursday" or day == "Sunday":
    food = "fish food"
elif day == "Tuesday" or day == "Saturday":
    food = "rabbit stew"
else:
    food = "chicken stakes"

# Print the food to eat
print(food)