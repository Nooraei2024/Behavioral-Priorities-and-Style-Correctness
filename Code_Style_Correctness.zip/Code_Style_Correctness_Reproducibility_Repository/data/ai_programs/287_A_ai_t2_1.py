import sys

def solve(paper):
    # Check if there is already a 2x2 square in the picture
    for i in range(4):
        for j in range(4):
            if paper[i][j] == paper[i+1][j] and paper[i][j] == paper[i][j+1]:
                return "YES"
    
    # Check if there is a black cell that can be repainted to white
    for i in range(4):
        for j in range(4):
            if paper[i][j] == "B":
                paper[i][j] = "W"
                return "YES"
    
    # Check if there is a white cell that can be repainted to black
    for i in range(4):
        for j in range(4):
            if paper[i][j] == "W":
                paper[i][j] = "B"
                return "YES"
    
    # If no valid move is found, return NO
    return "NO"

# Read input from standard input (stdin)
paper = []
for _ in range(4):
    paper.append([])
    for _ in range(4):
        paper[-1].append(input())

# Call the solve function and print output to standard output (stdout)
print(solve(paper))