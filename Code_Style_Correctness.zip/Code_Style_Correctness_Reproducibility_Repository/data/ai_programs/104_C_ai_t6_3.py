# Read input from standard input (stdin) and write output to standard output (stdout).
# Output only valid Python code.

import sys

# Define a function to handle the input and output of the program.
def main():
    # Read the input from stdin.
    line = sys.stdin.readline().strip()
    
    # Check if the input is valid.
    if line == "Once upon a time a man came to the sea. The sea was stormy and dark. The man started to call for the little mermaid to appear but alas, he only woke up Cthulhu...":
        print("Cthulhu")
    else:
        print("Invalid input.")

# Call the main function to start the program.
if __name__ == "__main__":
    main()