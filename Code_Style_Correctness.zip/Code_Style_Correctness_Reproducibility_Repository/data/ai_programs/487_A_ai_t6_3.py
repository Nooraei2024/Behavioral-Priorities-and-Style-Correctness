import sys

# Read input from stdin
n = int(sys.stdin.readline())
monster_info = []
for _ in range(n):
    monster_info.append(list(map(int, sys.stdin.readline().split())))
yang_info = list(map(int, sys.stdin.readline().split()))

# Initialize variables
monster_hp = 0
yang_hp = 0
turns = 0

# Loop through the battle
while monster_hp > 0 and yang_hp > 0:
    turns += 1
    # Update HP for both Yang and the monster
    monster_hp -= max(0, yang_info[1] - monster_info[turns][2])
    yang_hp -= max(0, monster_info[turns][1] - yang_info[2])

# Check who wins the battle
if monster_hp <= 0 and yang_hp > 0:
    print("Yang")
else:
    print("Monster")