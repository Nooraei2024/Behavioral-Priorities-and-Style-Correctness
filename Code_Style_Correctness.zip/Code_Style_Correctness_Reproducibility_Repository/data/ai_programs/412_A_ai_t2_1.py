import sys

# Read input from stdin
slogan = sys.stdin.readline().strip()

# Calculate the number of squares needed to display the slogan
n = len(slogan)

# Print the banner with the slogan
print("+" + "-" * n + "+")
for i in range(n):
    print("| " + slogan[i] + " |")
print("+" + "-" * n + "+")