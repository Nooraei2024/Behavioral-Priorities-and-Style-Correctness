import sys

def f(l, r):
    return r - l + 1

n = int(input())
k = int(input())

intervals = []
for i in range(n):
    li, ri = map(int, input().split())
    intervals.append((li, ri))

result = 0
for i in range(len(intervals) - k + 1):
    current_intervals = intervals[i:i+k]
    current_sum = 0
    for j in range(k):
        current_sum += f(current_intervals[j][0], current_intervals[j][1])
    result += current_sum

print(result)