import sys

def f1_champions(drivers):
    points = {}
    for driver in drivers:
        if len(points) < 10:
            points[driver] = 25 - len(points) * 3
        else:
            points[driver] = 1
    
    winners = sorted(points, key=points.get, reverse=True)
    for i in range(len(winners)):
        if points[winners[i]] > points[winners[0]]:
            return winners[i]
        elif points[winners[i]] == points[winners[0]]:
            if len(drivers) - i < len(drivers) - drivers.index(winners[0]):
                return winners[i]
    
    return winners[0]