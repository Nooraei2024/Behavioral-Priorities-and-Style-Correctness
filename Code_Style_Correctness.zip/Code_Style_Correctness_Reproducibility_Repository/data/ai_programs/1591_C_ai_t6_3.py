import sys

def solve(n, k):
    # Calculate the minimum distance required to cover all the depots
    min_dist = 0
    for i in range(1, n+1):
        dist = abs(x_i - x_j)
        if dist > k:
            min_dist += (dist - k) * 2
        else:
            min_dist += dist
    return min_dist

# Read input from standard input (stdin)
n, k = map(int, sys.stdin.readline().split())
x_i = list(map(int, sys.stdin.readline().split()))

# Print the minimum distance required to cover all the depots
print(solve(n, k))