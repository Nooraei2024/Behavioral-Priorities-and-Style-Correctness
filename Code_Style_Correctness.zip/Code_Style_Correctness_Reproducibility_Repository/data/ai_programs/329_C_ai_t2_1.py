import sys

# Read input from stdin
n = int(input())
edges = []
for _ in range(n):
    edges.append([int(x) for x in input().split()])

# Create a new graph with the same number of nodes and edges as the old graph
new_graph = {}
for i in range(1, n+1):
    new_graph[i] = set()

# Add edges to the new graph
for edge in edges:
    u, v = edge
    if u not in new_graph[v]:
        new_graph[u].add(v)
        new_graph[v].add(u)

# Print the new graph
print("{")
for node in new_graph:
    print(f"{node}: {new_graph[node]}")
print("}")