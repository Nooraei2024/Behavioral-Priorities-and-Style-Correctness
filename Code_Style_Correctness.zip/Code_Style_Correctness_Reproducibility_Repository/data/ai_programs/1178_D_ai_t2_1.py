import sys

n = int(input())
graph = {}
for i in range(1, n+1):
    graph[i] = []

for _ in range(n-1):
    a, b = map(int, input().split())
    if a not in graph or b not in graph:
        continue
    graph[a].append(b)
    graph[b].append(a)

print(" ".join(map(str, sorted(graph.keys()))))