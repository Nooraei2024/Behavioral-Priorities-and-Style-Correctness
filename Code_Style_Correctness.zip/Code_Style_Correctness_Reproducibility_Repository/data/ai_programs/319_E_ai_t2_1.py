import sys

# Read input from stdin
for line in sys.stdin:
    # Split the line into two parts: the query type and the arguments
    query_type, args = line.split(' ', 1)
    
    # Handle the different types of queries
    if query_type == '1':
        # Add a new interval to the set of intervals
        x, y = map(int, args.split())
        intervals.add((x, y))
    elif query_type == '2':
        # Check if there is a path from one interval to another
        I1, I2 = map(int, args.split())
        if can_reach(I1, I2):
            print('YES')
        else:
            print('NO')