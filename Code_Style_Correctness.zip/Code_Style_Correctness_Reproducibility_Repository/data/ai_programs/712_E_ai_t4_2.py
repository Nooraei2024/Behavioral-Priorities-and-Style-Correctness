import sys

# Read input from stdin
n = int(input())
casinos = []
for _ in range(n):
    casinos.append(float(input()))

# Initialize variables
memory_domination = 0
for i in range(1, n+1):
    for j in range(i, n+1):
        # Check if Memory dominates on the interval i...j
        if all(casinos[k] >= casinos[k-1] for k in range(i, j)):
            memory_domination += 1

# Print output
print(memory_domination)