import sys

# Read input from stdin
day = sys.stdin.readline().strip()

# Check which type of food Polycarp should eat based on the day of the week
if day == "Monday" or day == "Thursday" or day == "Sunday":
    print("Fish food")
elif day == "Tuesday" or day == "Saturday":
    print("Rabbit stew")
else:
    print("Chicken stake")