import sys

def add_one(n):
    result = 0
    for digit in str(n):
        result += int(digit) + 1
    return result % (10 ** 9 + 7)

if __name__ == '__main__':
    t = int(input())
    for _ in range(t):
        n = int(input())
        print(add_one(n))