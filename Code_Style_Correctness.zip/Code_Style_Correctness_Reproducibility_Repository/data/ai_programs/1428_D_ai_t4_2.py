import sys

n = int(input())
grid = []
for i in range(n):
    grid.append([])
    for j in range(n):
        grid[i].append(0)

targets = set()
for i in range(n):
    for j in range(n):
        targets.add((i, j))

bounces = 0
while len(targets) > 0:
    bounces += 1
    new_targets = set()
    for target in targets:
        i, j = target
        if grid[i][j] == 0:
            grid[i][j] = 1
            new_targets.add((i-1, j))
            new_targets.add((i+1, j))
            new_targets.add((i, j-1))
            new_targets.add((i, j+1))
    targets = new_targets

print(bounces)