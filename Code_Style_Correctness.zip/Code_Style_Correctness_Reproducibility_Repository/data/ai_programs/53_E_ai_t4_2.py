import sys

n, m = map(int, input().split())
junctions = set()
for _ in range(m):
    junctions.add(tuple(map(int, input().split())))

dead_ends = 0
for junction in junctions:
    if len(junction) == 1:
        dead_ends += 1

print(n - m + dead_ends)