import sys

def solve(a, b):
    # Replace b with b - ak
    k = int(input())
    if k > 0 and b - ak >= 0:
        return (b - ak) % a
    
    # Replace b with b mod a
    return b % a

if __name__ == "__main__":
    t = int(input())
    for _ in range(t):
        a, b = map(int, input().split())
        print(solve(a, b))