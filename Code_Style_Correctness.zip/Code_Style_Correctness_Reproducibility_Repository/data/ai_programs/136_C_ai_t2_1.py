import sys

n = int(input())
arr = list(map(int, input().split()))

# Find the index of the element to replace
replace_index = -1
for i in range(n):
    if arr[i] != arr[i-1]:
        replace_index = i
        break

# Replace the element with a new value
new_value = 0
if replace_index != -1:
    new_value = int(input())
    arr[replace_index] = new_value

# Sort the array
arr.sort()

# Print the sorted array
print(*arr, sep=' ')