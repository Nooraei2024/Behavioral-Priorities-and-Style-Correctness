import sys

# Read input from stdin
n = int(input())
a = list(map(int, input().split()))
m = int(input())
b = [0] * m

# Assign value of a1 to some variable bx (1 ≤ x ≤ m)
b[0] = a[0]

# Each of the following n - 1 operations is assigning to some variable by the value that is equal to the sum of values that are stored in the variable
for i in range(1, n):
    b[i % m] = (a[i] + b[(i - 1) % m]) % 2000000007

# Output only valid Python code
print(*b, sep='\n')