import sys

n = int(input())
m = int(input())
s_1 = list(map(int, input().split()))

def monsters_and_potions(n, m, s_1):
    # Initialize the number of monsters and potions to 0
    num_monsters = 0
    num_potions = 0
    
    # Loop through each cell in the board
    for i in range(1, n+1):
        # If the current cell contains a monster, increment the number of monsters
        if s_1[i-1] == 1:
            num_monsters += 1
        # If the current cell contains a potion, increment the number of potions
        elif s_1[i-1] == 2:
            num_potions += 1
    
    # Return the maximum number of monsters and potions that can be placed on the board
    return max(num_monsters, num_potions)

print(monsters_and_potions(n, m, s_1))