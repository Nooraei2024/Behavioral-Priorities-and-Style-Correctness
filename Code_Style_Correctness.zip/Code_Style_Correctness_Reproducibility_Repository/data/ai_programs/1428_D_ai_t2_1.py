import sys

n = int(input())
grid = []
for i in range(n):
    grid.append([])
    for j in range(n):
        grid[i].append(0)

targets = 0
for i in range(n):
    for j in range(n):
        if grid[i][j] == 1:
            targets += 1

if targets % 2 == 0:
    print("YES")
else:
    print("NO")