import sys

n = int(input())
heights = list(map(int, input().split()))
seated_order = []

for i in range(n):
    seated_order.append((i, heights[i]))

# Sort the people by their height and then by their original position in the queue
seated_order.sort(key=lambda x: (x[1], x[0]))

# Output the seated order of the people
for i in range(n):
    print(seated_order[i][0] + 1)