import sys

n = int(input())
a = list(map(int, input().split()))

# Initialize a dictionary to store the number of chocolate pieces in each box
boxes = {}
for i in range(1, n+1):
    boxes[i] = a[i-1]

# Sort the boxes by the number of chocolate pieces they contain
sorted_boxes = sorted(boxes.items(), key=lambda x: x[1], reverse=True)

# Send the boxes to Alice in order of their number of chocolate pieces
for i, box in enumerate(sorted_boxes):
    print(f"Send box {i+1} to Alice")