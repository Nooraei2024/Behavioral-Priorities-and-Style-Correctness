import sys

# Read input from standard input
input = sys.stdin.read()

# Split input into individual vectors
vectors = input.split('\n')

# Initialize sum to zero vector
sum = [0] * len(vectors[0])

# Iterate over each vector and add it to the sum
for vector in vectors:
    for i, coord in enumerate(vector):
        sum[i] += int(coord)

# Output sum as Python code
print('[' + ', '.join(str(s) for s in sum) + ']')