import sys

# Read input from stdin
input_string = sys.stdin.readline().strip()

# Split input string into a list of characters
input_list = list(input_string)

# Initialize variables to keep track of black and white cells
black_cells = 0
white_cells = 0

# Iterate through the list of characters
for cell in input_list:
    # If the current cell is black, increment the number of black cells
    if cell == 'B':
        black_cells += 1
    # If the current cell is white, increment the number of white cells
    elif cell == 'W':
        white_cells += 1

# Check if there are at most one black and one white cell
if black_cells <= 1 and white_cells <= 1:
    # Output "YES" if the initial picture already has a 2x2 square
    print("YES")
else:
    # Output "NO" if the initial picture does not have a 2x2 square
    print("NO")