import sys

def find_complete_game(n):
    # Initialize a dictionary to store the parts and their dependencies
    parts = {}
    for i in range(1, n+1):
        parts[i] = []

    # Read input from standard input (stdin)
    for line in sys.stdin:
        parts[int(line.split()[0])].append(int(line.split()[1]))

    # Find the parts that can be completed without any dependencies
    complete_parts = []
    for part in range(1, n+1):
        if not parts[part]:
            complete_parts.append(part)

    # Find the parts that are dependent on other parts
    dependent_parts = []
    for part in range(1, n+1):
        if parts[part]:
            dependent_parts.append(part)

    # Find the parts that can be completed by completing the dependent parts
    complete_dependent_parts = []
    for part in dependent_parts:
        for dep in parts[part]:
            if dep not in complete_parts:
                break
        else:
            complete_dependent_parts.append(part)

    # Find the parts that cannot be completed by completing the dependent parts
    incomplete_parts = []
    for part in range(1, n+1):
        if part not in complete_dependent_parts and part not in complete_parts:
            incomplete_parts.append(part)

    # Output the complete