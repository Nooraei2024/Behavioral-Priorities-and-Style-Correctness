import sys

# Read input from stdin
s = sys.stdin.readline().strip()

# Initialize a dictionary to keep track of the colors used for each letter
colors = {}
for i in range(len(s)):
    # If the letter is already in the dictionary, increment its count
    if s[i] in colors:
        colors[s[i]] += 1
    # Otherwise, add it to the dictionary with a count of 1
    else:
        colors[s[i]] = 1

# Check if the string is wonderful
if all(v == 1 or v == 0 for v in colors.values()):
    print("YES")
else:
    print("NO")