import sys

n = int(input())
nums = set()
for _ in range(n):
    nums.add(int(input()))

while len(nums) > 0:
    x, y = map(int, input().split())
    if abs(x - y) not in nums:
        print("NO")
        break
    else:
        nums.remove(abs(x - y))
        print("YES")