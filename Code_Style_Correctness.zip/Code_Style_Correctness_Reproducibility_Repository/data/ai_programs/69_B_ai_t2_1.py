import sys

def solve(n, m):
    # Create a dictionary to store the number of bets for each participant
    bets = {}
    
    # Read the input from stdin
    for _ in range(m):
        line = sys.stdin.readline().strip()
        participant_id, section_id = line.split()
        participant_id = int(participant_id)
        section_id = int(section_id) - 1
        
        # Increment the number of bets for the participant in the current section
        if participant_id not in bets:
            bets[participant_id] = {}
        if section_id not in bets[participant_id]:
            bets[participant_id][section_id] = 0
        bets[participant_id][section_id] += 1
    
    # Find the participant with the most bets in each section
    max_bets = {}
    for participant_id, sections in bets.items():
        for section_id, num_bets in sections.items():
            if section_id not in max_bets or num_bets > max_bets[section_id]:
                max_bets[section_id] = num_bets
    
    # Output the participant with the most bets in each section
    for section_id, num_bets in max_bets.items():
        print