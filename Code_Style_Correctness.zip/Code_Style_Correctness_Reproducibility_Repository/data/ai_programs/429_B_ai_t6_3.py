import sys

# Read input from stdin
n, m = map(int, sys.stdin.readline().split())
a = []
for _ in range(n):
    a.append(list(map(int, sys.stdin.readline().split())))

# Initialize variables for Iahub and Iahubina
i = 1
j = 1

# Calculate the total number of calories burned
total_calories = 0
while i <= n and j <= m:
    # Add the calories burned by the current workout to the total
    total_calories += a[i][j]
    
    # Move to the next workout
    if i < n:
        i += 1
    else:
        j += 1

# Print the total number of calories burned
print(total_calories)