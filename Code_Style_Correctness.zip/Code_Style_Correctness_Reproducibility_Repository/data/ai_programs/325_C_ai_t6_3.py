import sys

n = int(sys.stdin.readline())
monsters = []
diamonds = []

# Initialize the first monster
monsters.append([1])

# Feed the pie to the first monster
diamonds.append(0)

# Read the input for the number of pies and the colors of the diamonds
for _ in range(n):
    line = sys.stdin.readline().strip()
    if line == '':
        break
    p, c = map(int, line.split())
    monsters[-1].append(p)
    diamonds.append(c)

# Calculate the number of colors of diamonds that Piegirl will have after feeding all the pies
colors = []
for i in range(n):
    color = 0
    for j in range(i + 1):
        if monsters[j][-1] != 0:
            color += diamonds[j]
    colors.append(color)

# Print the number of colors of diamonds that Piegirl will have after feeding all the pies
print(sum(colors))