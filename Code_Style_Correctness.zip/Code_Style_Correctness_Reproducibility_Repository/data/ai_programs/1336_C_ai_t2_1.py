import sys

# Read input from stdin
T = sys.stdin.readline().strip()
S = sys.stdin.readline().strip()
A = ""

# Check if T is a magic spell
if T in S:
    # If T is a magic spell, append it to A
    A += T

# Print the result
print(A)