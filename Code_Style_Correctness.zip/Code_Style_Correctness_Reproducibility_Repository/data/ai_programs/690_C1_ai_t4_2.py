import sys

# Read input from stdin
n = int(sys.stdin.readline())
m = int(sys.stdin.readline())

# Initialize a list to store the brains
brains = []

# Loop through each brain and add it to the list
for i in range(n):
    brains.append(list(map(int, sys.stdin.readline().split())))

# Calculate the number of interconnected brains
num_interconnected = 0
for brain in brains:
    for other_brain in brains:
        if brain != other_brain and set(brain).issubset(other_brain):
            num_interconnected += 1

# Print the number of interconnected brains
print(num_interconnected)