import sys

def determine_exitable(grid):
    m = len(grid)
    n = len(grid[0])
    exitable = set()
    for i in range(m):
        for j in range(n):
            if grid[i][j] == "X":
                continue
            else:
                stack = [(i, j)]
                while stack:
                    x, y = stack.pop()
                    if x < 0 or y < 0 or x >= m or y >= n or grid[x][y] == "X":
                        continue
                    else:
                        exitable.add((x, y))
                        stack.append((x-1, y))
                        stack.append((x, y-1))
    return list(exitable)

if __name__ == "__main__":
    grid = []
    for _ in range(int(input())):
        row = input().split()
        grid.append([c for c in row])
    exitable = determine_exitable(grid)
    print(" ".join(map(str, exitable)))