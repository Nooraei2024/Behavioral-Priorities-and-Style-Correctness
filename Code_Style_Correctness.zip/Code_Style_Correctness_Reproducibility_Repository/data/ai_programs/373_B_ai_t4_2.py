import sys

def solve(w, m):
    max_length = 0
    current_cost = 0
    for i in range(m, w+1):
        cost = S(i) * (i - m + 1)
        if cost > w:
            break
        else:
            current_cost += cost
            max_length = max(max_length, i - m + 1)
    return max_length

S = lambda n: len(str(n))

if __name__ == '__main__':
    w, m = map(int, sys.stdin.readline().split())
    print(solve(w, m))