import sys

def get_input():
    return list(map(int, input().split()))

def find_probability(a, k):
    # Calculate the number of swaps
    num_swaps = 0
    for i in range(len(a)):
        if a[i] == 1:
            num_swaps += 1
    
    # Calculate the probability of each swap
    probabilities = [0] * len(a)
    for i in range(len(a)):
        if a[i] == 1:
            probabilities[i] = (num_swaps - 1) / (k - 1)
    
    # Calculate the probability of all swaps happening
    total_probability = 1
    for i in range(len(a)):
        if a[i] == 1:
            total_probability *= probabilities[i]
    
    return total_probability

if __name__ == "__main__":
    n, k = get_input()
    a = [0] * n
    for i in range(n):
        a[i] = int(input())
    print(find_probability(a, k))