import sys

# Read input from stdin
m = int(input())
n = int(input())
a = list(map(int, input().split()))

# Initialize variables
coffee_breaks = 0
total_time = 0

# Loop through each coffee break and check if it falls within the work day
for i in range(n):
    if a[i] <= m:
        coffee_breaks += 1
        total_time += a[i] + 1

# Check if there are enough minutes left for another coffee break
if total_time < m:
    print("YES")
else:
    print("NO")