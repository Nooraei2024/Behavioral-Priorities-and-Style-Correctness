import sys

# Read input from stdin
m = int(sys.stdin.readline())
n = int(sys.stdin.readline())

# Initialize variables
variables = []
for i in range(n):
    variables.append(int(sys.stdin.readline()))

# Compute values of n variables
values = []
for variable in variables:
    if variable < 2**m:
        values.append(variable)
    else:
        values.append(variable % (2**m))

# Print output to stdout
print(*values, sep='\n')