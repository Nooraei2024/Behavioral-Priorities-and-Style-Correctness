import sys

pl, pr = map(int, input().split())
vl, vr = map(int, input().split())

lucky_numbers = [4, 7]

p_count = 0
v_count = 0

for i in range(pl, pr+1):
    if str(i).count("4") + str(i).count("7") == 2:
        p_count += 1

for j in range(vl, vr+1):
    if str(j).count("4") + str(j).count("7") == 2:
        v_count += 1

print(p_count/v_count)