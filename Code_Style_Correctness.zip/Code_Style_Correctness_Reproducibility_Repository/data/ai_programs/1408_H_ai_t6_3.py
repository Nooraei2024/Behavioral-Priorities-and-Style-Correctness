import sys

t = int(input())
for case in range(t):
    n = int(input())
    a = list(map(int, input().split()))
    m = 0
    for i in range(n-2):
        for j in range(i+1, n-1):
            if a[j] != 0:
                k = j + 1
                while k < n and a[k] == 0:
                    k += 1
                if k < n:
                    m += 1
    print(m)