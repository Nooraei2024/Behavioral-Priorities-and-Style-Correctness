import sys

# Read input from stdin
input_string = sys.stdin.read()

# Split the input string into a list of states
states = input_string.splitlines()

# Initialize a dictionary to store the transitions between states
transitions = {}

# Loop through each state in the list and add it to the transitions dictionary
for i, state in enumerate(states):
    if i == 0:
        # If this is the first state, set its value as the starting state
        start_state = state
    else:
        # Otherwise, add a transition from the previous state to this state
        transitions[states[i - 1]] = state

# Initialize a list to store the paths
paths = []

# Loop through each state in the dictionary and find all possible paths
for state in transitions:
    # If this is the starting state, add it to the list of paths
    if state == start_state:
        paths.append([state])
    else:
        # Otherwise, find all possible paths from this state
        for path in paths:
            # Add a transition from this state to the end of each path
            new_path = path + [transitions[state]]
            paths.append(new_path)

# Print the list of paths
print(paths)