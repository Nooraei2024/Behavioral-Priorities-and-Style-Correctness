import sys

# Read input from stdin
input_string = sys.stdin.readline().strip()

# Split the input string into a list of vectors
vectors = input_string.split(' ')

# Initialize the result vector as all zeros
result = [0] * len(vectors)

# Iterate over each vector in the list
for i, vector in enumerate(vectors):
    # Convert the vector to a list of integers
    vector_list = [int(x) for x in vector]
    
    # Sum the vector with the previous result
    result[i] = sum(vector_list) % 2

# Join the result list into a string and print it to stdout
print(' '.join(str(x) for x in result))