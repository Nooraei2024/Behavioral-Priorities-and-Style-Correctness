import sys

def is_p_interesting(edges):
    n = len(edges) // 2
    if len(edges) != 2 * n + p:
        return False
    for edge in edges:
        if edge[0] == edge[1]:
            return False
    for k in range(1, n + 1):
        subgraph = set()
        for i in range(k):
            subgraph.add((edges[i * 2], edges[i * 2 + 1]))
        if len(subgraph) > 2 * k + p:
            return False
    return True

if __name__ == '__main__':
    input = sys.stdin.read()
    edges = [line.split() for line in input.splitlines()]
    print(is_p_interesting(edges))