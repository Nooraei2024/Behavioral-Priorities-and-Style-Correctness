import sys

n = int(input())
hi = list(map(int, input().split()))

for i in range(n):
    if hi[i] == 0:
        print("Error")
        break
    elif hi[i] % 2 == 0:
        print("Even")
    else:
        print("Odd")