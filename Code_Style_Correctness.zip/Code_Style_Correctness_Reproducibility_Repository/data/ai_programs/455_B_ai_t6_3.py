import sys

n = int(input())
strings = []
for i in range(n):
    strings.append(input().strip())

k = int(input())

# Initialize the word as empty
word = ""

# Play k games
for _ in range(k):
    # Get the next two letters of the word
    letter1, letter2 = word[-1], word[-2] if len(word) > 1 else None

    # Determine who goes first based on the last two letters of the word
    if letter1 == letter2:
        # If the last two letters are the same, both players go together
        player = "Andrew" if letter1 == "A" else "Alex"
    elif letter1 is None or letter2 is None:
        # If there are not enough letters in the word for both players to move,
        # the first player goes alone
        player = "Andrew"
    else:
        # Otherwise, the first player goes based on the last two letters
        player = "Andrew" if letter1 == "A" and letter2 == "B" or letter1 == "B" and letter2 == "A" else "Alex"

    # Get the next move from the player
    move = input()

    # Add the move to the word
    word += move

# Check who is the winner
if len(word) == 0:
    print("Andrew")
else:
    print("Alex")