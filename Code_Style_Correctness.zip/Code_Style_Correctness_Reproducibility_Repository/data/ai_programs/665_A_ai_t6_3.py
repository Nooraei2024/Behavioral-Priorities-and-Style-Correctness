import sys

# Read input from stdin
a, b, t = map(int, input().split())
ta, tb = map(int, input().split())
start, end = map(int, input().split())

# Calculate the number of buses going towards Simion
num_bus = 0
for i in range(start, end):
    if i % a == 0 and i % b != 0:
        num_bus += 1
    elif i % b == 0 and i % a != 0:
        num_bus -= 1

# Print the result
print(num_bus)