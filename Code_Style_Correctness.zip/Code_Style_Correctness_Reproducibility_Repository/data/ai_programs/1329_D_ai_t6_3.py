import sys

def solve(a):
    steps = 0
    while len(a) > 1:
        i = 0
        while i < len(a) - 1:
            if a[i] == a[i+1]:
                a = a[:i] + a[i+2:]
                steps += 1
            else:
                i += 1
    return steps

if __name__ == '__main__':
    input_string = sys.stdin.readline().strip()
    print(solve(input_string))