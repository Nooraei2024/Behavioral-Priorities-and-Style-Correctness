import sys

# Read input from stdin
n, k = map(int, sys.stdin.readline().split())
prizes = list(map(int, sys.stdin.readline().split()))

# Sort the prizes in descending order
prizes.sort(reverse=True)

# Initialize variables to keep track of the number of wizards and the total prize value
num_wizards = 0
total_prize = 0

# Loop through the prizes and assign them to the wizards
for i in range(len(prizes)):
    # If the current prize is greater than or equal to the maximum prize that can be carried by a single wizard,
    # then assign it to a new wizard
    if prizes[i] >= k:
        num_wizards += 1
        total_prize += prizes[i]
    else:
        # If the current prize is less than the maximum prize that can be carried by a single wizard,
        # then assign it to an existing wizard
        for j in range(num_wizards):
            if total_prize + prizes[i] <= k:
                num_wizards = j + 1
                total_prize += prizes[i]
                break

# Output the number of wizards and the total prize value
print(num_wizards)
print(total_prize)