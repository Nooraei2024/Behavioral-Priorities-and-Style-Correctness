import sys

# Read input from stdin
n = int(input())
li = list(map(int, input().split()))
ri = list(map(int, input().split()))
di = list(map(int, input().split()))

# Initialize the heights of the towers
heights = [0] * n

# Update the heights of the towers based on the segments added by Alyona
for i in range(len(li)):
    for j in range(li[i], ri[i] + 1):
        heights[j - 1] += di[i]

# Print the maximum height of any tower
print(max(heights))