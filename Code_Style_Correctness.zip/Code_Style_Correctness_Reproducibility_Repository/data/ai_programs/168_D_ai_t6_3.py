import sys

# Read input from stdin
n, k = map(int, sys.stdin.readline().split())
prizes = []
for _ in range(n):
    prizes.append(int(sys.stdin.readline()))

# Sort the prizes in descending order
prizes.sort(reverse=True)

# Initialize variables to keep track of the number of winners and the total value of the prizes
num_winners = 0
total_value = 0

# Loop through the prizes and assign them to the winners
for prize in prizes:
    if num_winners < k:
        # If there are still empty bags, assign this prize to a winner
        total_value += prize
        num_winners += 1
    else:
        # If all bags are full, the next prize goes to the winner with the highest value
        if prize > total_value / k:
            total_value -= total_value % k
            total_value += prize
            num_winners = k

# Print the output
print(num_winners)
print(total_value)