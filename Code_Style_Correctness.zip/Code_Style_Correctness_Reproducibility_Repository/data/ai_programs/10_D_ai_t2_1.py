# Read input from stdin
a = list(map(int, input().split()))
b = list(map(int, input().split()))

# Find the longest common increasing subsequence of a and b
def lcis(a, b):
    # Initialize the dp table with 0s
    dp = [[0] * len(b) for _ in range(len(a))]
    
    # Loop through each element of a and b
    for i in range(len(a)):
        for j in range(len(b)):
            # If the current elements are equal, set the dp value to 1
            if a[i] == b[j]:
                dp[i][j] = 1
            # Otherwise, check if the previous element is greater than the current element
            elif i > 0 and a[i-1] < a[i] and b[j-1] < b[j]:
                # If it is, set the dp value to the maximum of the previous values plus 1
                dp[i][j] = max(dp[i-1][j-1], dp[i-1][j]) + 1
    
    # Return the maximum value in the dp table
    return max(max(row) for row in dp)

# Print the result
print(lcis(a, b))