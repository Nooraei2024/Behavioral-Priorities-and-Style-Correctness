import sys

# Read input from stdin
input_str = sys.stdin.readline()

# Split input string into a list of integers
input_list = [int(x) for x in input_str.split()]

# Calculate the volume of each block
blocks = []
for i in range(len(input_list)):
    blocks.append((input_list[i], input_list[i+1]))

# Calculate the total volume of all blocks
total_volume = 0
for block in blocks:
    total_volume += block[0] * block[1]

# Output the result to stdout
print(total_volume)