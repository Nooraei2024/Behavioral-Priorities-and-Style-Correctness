import math

def is_tprime(n):
    if n == 1:
        return False
    divisors = []
    for i in range(2, int(math.sqrt(n)) + 1):
        if n % i == 0:
            divisors.append(i)
            if len(divisors) == 3:
                break
    else:
        return False
    return len(divisors) == 3

def solve(n, arr):
    for num in arr:
        print("True" if is_tprime(num) else "False")

if __name__ == "__main__":
    n = int(input())
    arr = [int(x) for x in input().split()]
    solve(n, arr)