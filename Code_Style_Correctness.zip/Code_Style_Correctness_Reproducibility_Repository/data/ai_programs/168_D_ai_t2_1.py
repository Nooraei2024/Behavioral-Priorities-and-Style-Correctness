import sys

# Read input from stdin
n, k = map(int, sys.stdin.readline().split())
prizes = []
for _ in range(n):
    prizes.append(int(sys.stdin.readline()))

# Sort the prizes in descending order
prizes.sort(reverse=True)

# Calculate the total value of all the prizes
total_value = sum(prizes)

# Initialize a list to store the winners
winners = []

# Loop through the prizes and add them to the winners list until the total value exceeds k
while total_value <= k:
    winners.append(prizes.pop())
    total_value += winners[-1]

# Print the winners in descending order
print(*winners, sep='\n')