import sys

n, m = map(int, input().split())

# Find a and b such that s(a) >= n and s(b) >= n
a = 1
while s(a) < n:
    a *= 10

b = 1
while s(b) < n:
    b *= 10

# Find the greatest common divisor of a and b
gcd = 1
while gcd > 0:
    if a % gcd == 0 and b % gcd == 0:
        break
    gcd -= 1

# Calculate a' and b' such that s(a') = n and s(b') = n
a_prime = a // gcd
b_prime = b // gcd

# Print the decimal representations of a' and b'
print(str(a_prime)[-2230:])
print(str(b_prime)[-2230:])