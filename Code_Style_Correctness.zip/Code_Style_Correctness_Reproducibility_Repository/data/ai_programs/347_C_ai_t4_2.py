import sys

n = int(input())
nums = set()
while len(nums) < n:
    nums.add(int(input()))

player = 1
while len(nums):
    x, y = map(int, input().split())
    if abs(x - y) in nums:
        nums.remove(abs(x - y))
        player = 2 if player == 1 else 1
    else:
        print("Invalid move")
        sys.exit()

print("Player", player, "wins!")