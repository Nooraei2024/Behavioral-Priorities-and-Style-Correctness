import sys

n, m = map(int, input().split())
days = 0
while n >= m:
    if n % m == 0:
        days += m - 1
    else:
        days += n % m
    n -= m
print(days)