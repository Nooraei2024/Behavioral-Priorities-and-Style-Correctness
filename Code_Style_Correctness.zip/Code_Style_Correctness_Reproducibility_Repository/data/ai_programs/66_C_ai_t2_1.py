import os

# Get the current working directory
cwd = os.getcwd()

# Initialize variables to keep track of the most subfolders and files
most_subfolders = 0
most_files = 0

# Iterate over all folders in the current working directory
for folder in os.listdir(cwd):
    # Get the full path of the folder
    folder_path = os.path.join(cwd, folder)
    
    # Check if the folder is a directory
    if os.path.isdir(folder_path):
        # Increment the number of subfolders
        most_subfolders += 1
        
        # Recursively count the number of files in the folder and its subfolders
        for file in os.listdir(folder_path):
            file_path = os.path.join(folder_path, file)
            
            if os.path.isfile(file_path):
                most_files += 1