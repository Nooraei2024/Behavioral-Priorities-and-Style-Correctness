import sys

# Read input from stdin
n = int(input())
a = list(map(int, input().split()))
m = int(input())
b = list(map(int, input().split()))

# Calculate the total memory usage of all applications
total_memory = sum(a)

# Find the number of important applications
num_important = len([i for i in b if i == 2])

# Check if it is possible to free at least m units of memory
if total_memory - num_important >= m:
    # Print the list of important applications that can be removed
    print(*[i for i in range(n) if b[i] == 2 and a[i] <= m], sep=' ')
else:
    # Print "No" if it is not possible to free at least m units of memory
    print("No")