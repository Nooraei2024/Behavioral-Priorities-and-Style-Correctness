import sys

# Read input from stdin
n = int(input())
chains = []
for _ in range(n):
    chains.append([int(x) for x in input().split()])

# Calculate the longest simple cycle
longest_cycle = 0
for chain in chains:
    c = chain[0]
    for i in range(1, len(chain)):
        if chain[i - 1] == chain[i]:
            continue
        else:
            c += 1
    longest_cycle = max(longest_cycle, c)

# Print the result
print(longest_cycle)