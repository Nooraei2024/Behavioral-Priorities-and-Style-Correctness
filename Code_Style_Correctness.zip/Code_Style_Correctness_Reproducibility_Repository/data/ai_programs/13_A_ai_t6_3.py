import math

def solve(A):
    # Calculate the sum of digits for each base from 2 to A - 1
    sums = []
    for i in range(2, A):
        sum = 0
        while i > 0:
            sum += i % 10
            i //= 10
        sums.append(sum)
    
    # Calculate the average value of the sums
    avg = sum(sums) / len(sums)
    
    # Convert the average to an irreducible fraction
    gcd = math.gcd(avg, 10)
    num = int(avg // gcd)
    den = int(10 // gcd)
    
    return f"{num}/{den}"

# Test case
A = 3
print(solve(A))