import sys

def solve(people):
    houses = {}
    for person in people:
        if person not in houses:
            houses[person] = 0
        else:
            houses[person] += 1
    
    sorted_houses = sorted(houses.items(), key=lambda x: x[1], reverse=True)
    
    for i, (person, house) in enumerate(sorted_houses):
        print(f"{person} {i}")