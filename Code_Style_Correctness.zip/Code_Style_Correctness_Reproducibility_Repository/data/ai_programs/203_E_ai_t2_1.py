import sys

# Read input from stdin
n = int(input())
robots = []
for _ in range(n):
    robots.append(int(input()))

# Initialize a dictionary to store the number of robots that can be carried by each robot
capacity = {}
for i in range(len(robots)):
    capacity[i] = robots[i]

# Loop through all the robots and their capacities
for i in range(len(robots)):
    # If the current robot can carry other robots, add its capacity to the dictionary
    if robots[i] > 0:
        capacity[i] += robots[i] * capacity[i]

# Sort the dictionary by value (capacity) in descending order
sorted_capacity = sorted(capacity.items(), key=lambda x: x[1], reverse=True)

# Print the top 3 robots with the highest capacity
for i in range(3):
    print(sorted_capacity[i][0])