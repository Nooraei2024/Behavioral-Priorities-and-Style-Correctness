import sys

n = int(input())

# Initialize a list to store the black squares
black_squares = []

# Loop through each row and column of the graph paper
for i in range(n):
    for j in range(n):
        # If the current square is black, add it to the list of black squares
        if sys.stdin.read(1) == 'B':
            black_squares.append((i, j))

# Loop through each row and column of the fractal paper
for i in range(n**2):
    for j in range(n**2):
        # If the current square is a black square from the graph paper, paint it black on the fractal paper
        if (i, j) in black_squares:
            print("B", end="")
        else:
            print(".", end="")
    print()