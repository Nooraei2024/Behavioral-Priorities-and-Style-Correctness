import sys

n = int(input())
b = list(map(int, input().split()))

# Calculate the medians of each subarray
medians = []
for i in range(1, n + 1):
    subarray = b[0:i]
    medians.append(sorted(subarray)[len(subarray) // 2])

# Check if b is an OmkArray of some array a
if len(medians) == n and all(medians[i - 1] <= medians[i] for i in range(1, n)):
    print("YES")
else:
    print("NO")