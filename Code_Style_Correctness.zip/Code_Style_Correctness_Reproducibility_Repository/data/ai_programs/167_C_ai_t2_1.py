import sys

# Read input from stdin
a, b = map(int, sys.stdin.readline().split())

# Initialize variables
k = 1
result = 0

# Loop until a is equal to b
while a != b:
    # Check if k is greater than or equal to 0 and b - ak is greater than or equal to 0
    if k >= 0 and b - k * a >= 0:
        # Replace b with b - ak
        b -= k * a
    else:
        # Replace b with b mod a
        b %= a
    
    # Increment k by 1
    k += 1

# Print the result
print(result)