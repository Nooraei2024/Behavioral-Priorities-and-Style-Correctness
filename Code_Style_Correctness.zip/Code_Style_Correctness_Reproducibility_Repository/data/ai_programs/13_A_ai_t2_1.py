import math

def solve(A):
    # Initialize the sum of digits to 0
    sum_digits = 0

    # Loop through all bases from 2 to A - 1
    for base in range(2, A):
        # Convert A to a string in the current base
        num_str = str(A)

        # Calculate the sum of digits in the current base
        for digit in num_str:
            sum_digits += int(digit)

    # Return the average value of the sum of digits as an irreducible fraction
    return sum_digits / math.factorial(A - 1)