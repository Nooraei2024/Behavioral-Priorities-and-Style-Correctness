import sys

s = input()

# Find the longest palindrome in s
max_len = 0
for i in range(len(s)):
    for j in range(i+1, len(s)+1):
        substr = s[i:j]
        if substr == substr[::-1] and len(substr) > max_len:
            max_len = len(substr)

# Find the longest prefix and suffix of the palindrome
prefix = ""
suffix = ""
for i in range(max_len):
    if s[:i+1] == s[:i+1][::-1]:
        prefix = s[:i+1]
    if s[-i-1:] == s[-i-1:][::-1]:
        suffix = s[-i-1:]

# Output the longest palindrome, prefix, and suffix
print(max_len)
print(prefix)
print(suffix)