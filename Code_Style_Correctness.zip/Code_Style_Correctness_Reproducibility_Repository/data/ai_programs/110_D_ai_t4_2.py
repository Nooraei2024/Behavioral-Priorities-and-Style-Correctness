import sys

# Read input from stdin
pl, pr = map(int, sys.stdin.readline().split())
vl, vr = map(int, sys.stdin.readline().split())

# Calculate the number of lucky numbers in the interval [pl, pr]
lucky_count = 0
for i in range(pl, pr+1):
    if str(i).count('4') > 0 and str(i).count('7') > 0:
        lucky_count += 1

# Calculate the number of possible combinations of integers in the interval [vl, vr]
possible_combinations = (vr - vl + 1) * (pr - pl + 1)

# Calculate the probability that Petya and Vasya choose lucky numbers
probability = float(lucky_count) / possible_combinations

# Output the result to stdout
print('{:.3f}'.format(probability))