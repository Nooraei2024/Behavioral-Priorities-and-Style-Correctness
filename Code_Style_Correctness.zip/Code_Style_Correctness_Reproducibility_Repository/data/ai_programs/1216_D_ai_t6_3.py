import sys

# Read input from stdin
n = int(input())
types = []
for _ in range(n):
    types.append(list(map(int, input().split())))
x = list(map(int, input().split()))
y = int(input())
z = int(input())

# Calculate the number of swords of each type broken into by each person
sword_counts = [0] * n
for i in range(n):
    for j in range(x[i]):
        sword_counts[i] += 1

# Calculate the total number of swords taken by all people
total_swords = sum(sword_counts)

# Calculate the number of swords of each type remaining in the theater basement
remaining_swords = [0] * n
for i in range(n):
    remaining_swords[i] = types[i][0] - sword_counts[i]

# Print the result
print(*remaining_swords, sep=' ')