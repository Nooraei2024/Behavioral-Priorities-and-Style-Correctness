import sys

# Read input from stdin
n, m = map(int, sys.stdin.readline().split())
graph = {}
for _ in range(m):
    u, v = map(int, sys.stdin.readline().split())
    if u not in graph:
        graph[u] = []
    graph[u].append(v)

# Token movement
token = 1
while token != n + 1:
    # Find the next vertex to move the token to
    next_vertex = None
    for v in graph[token]:
        if v not in graph or graph[v] == []:
            next_vertex = v
            break
    # If no such vertex exists, then the token cannot move further
    if next_vertex is None:
        break
    # Move the token to the next vertex
    token = next_vertex
    print(f"Token moved from {token - 1} to {token}")

# Graph transposition
k = 0
while k < m:
    # Transpose all edges in the graph
    for u, v in graph.items():
        if len(v) > 0:
            graph[u], graph[v[0]] = graph[v[0]], graph[u]
            print(f"Graph transposed from {u} to {v[0]}")
    k += 1