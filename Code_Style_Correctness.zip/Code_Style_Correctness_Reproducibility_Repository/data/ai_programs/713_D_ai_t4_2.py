# Read input from standard input (stdin)
n, m = map(int, input().split())
puzzle = []
for i in range(n):
    puzzle.append([])
    for j in range(m):
        puzzle[i].append(int(input()))

# Find the empty parts of the puzzle
empty_parts = []
for i in range(n):
    for j in range(m):
        if puzzle[i][j] == 0:
            empty_parts.append((i, j))

# Fill the empty parts with random numbers
import random
for empty_part in empty_parts:
    i, j = empty_part
    puzzle[i][j] = random.randint(1, 9)

# Output the completed puzzle
print('\n'.join([' '.join(map(str, row)) for row in puzzle]))