import sys

# Read input from stdin
input_string = sys.stdin.readline().strip()

# Split the input string into a list of strings using '|' as delimiter
input_list = input_string.split('|')

# Get the dimensions of the plate (k, n, m) from the first element of the list
k, n, m = map(int, input_list[0].split())

# Initialize a 3D array to represent the plate with obstacles and empty squares
plate = [[['.' for _ in range(m)] for _ in range(n)] for _ in range(k)]

# Fill the plate with obstacles and water
for i in range(1, len(input_list)):
    line = input_list[i].split()
    x, y = map(int, line[:2])
    if line[2] == '#':
        plate[x][y]['#']
    else:
        plate[x][y]['.']

# Print the plate as a 3D array
print(plate)