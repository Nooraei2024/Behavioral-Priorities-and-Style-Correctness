import sys

# Read input from standard input (stdin)
input_string = sys.stdin.read()

# Split the input string into a list of lines
lines = input_string.split('\n')

# Initialize variables to store the information about the monster and the secret weapon
monster, weapon = None, None

# Iterate over each line in the input
for line in lines:
    # If the line contains the word "Cthulhu", set the variable "monster" to "True"
    if 'Cthulhu' in line:
        monster = True
    
    # If the line contains the word "Pentagon", set the variable "weapon" to "True"
    if 'Pentagon' in line:
        weapon = True

# Check if both "monster" and "weapon" are set to "True"
if monster and weapon:
    # Output a message indicating that Cthulhu is being prepared for battle by the Pentagon
    print('Cthulhu is being prepared for battle by the Pentagon!')
else:
    # Output a message indicating that Cthulhu is not being prepared for battle by the Pentagon
    print('Cthulhu is not being prepared for battle by the Pentagon.')