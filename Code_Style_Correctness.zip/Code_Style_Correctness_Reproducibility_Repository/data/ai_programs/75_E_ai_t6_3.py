import sys

def find_shortest_path(start, end):
    # Initialize a dictionary to store the distance from start to all other points
    distances = {}
    for i in range(len(points)):
        distances[points[i]] = float("inf")
    distances[start] = 0

    # Breadth-first search to find the shortest path
    queue = [start]
    while queue:
        current = queue.pop(0)
        for neighbor in get_neighbors(current):
            if distances[neighbor] == float("inf"):
                distances[neighbor] = distances[current] + 1
                queue.append(neighbor)

    # Find the shortest path from start to end
    path = [end]
    while path[-1] != start:
        path.append(distances[path[-1]])
    return path

def get_neighbors(point):
    # Return a list of neighboring points that are safe to move to
    neighbors = []
    for i in range(len(points)):
        if is_safe(points[i]):
            neighbors.append(points[i])
    return neighbors

def is_safe(point):
    # Return True if the point is safe to move to, False otherwise
    return True

# Read input from standard input (stdin)
n = int(input())
points = []
for i in range(n):
    points.append