import sys

def equalize(a, b):
    n = len(a)
    cost = 0
    for i in range(n):
        if a[i] != b[i]:
            cost += abs(i - j)
            a[i] ^= 1
    return cost

if __name__ == '__main__':
    input_data = sys.stdin.read()
    a, b = input_data.split()
    print(equalize(a, b))