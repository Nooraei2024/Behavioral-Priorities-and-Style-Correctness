import sys

# Read input from stdin
n = int(input())
pipes = []
for _ in range(n):
    pipes.append(list(map(int, input().split())))

# Initialize tanks and taps
tanks = [0] * n
taps = [0] * n

# Loop through each pipe and update the tanks and taps accordingly
for i in range(n):
    house_in, house_out, diameter = pipes[i]
    if house_in != -1:
        tanks[house_in] += diameter
    if house_out != -1:
        tanks[house_out] -= diameter
    if tanks[house_in] > 0 and tanks[house_out] < 0:
        taps[house_in] = max(taps[house_in], abs(tanks[house_out]))
    elif tanks[house_in] < 0 and tanks[house_out] > 0:
        taps[house_out] = max(taps[house_out], abs(tanks[house_in]))

# Print the maximum amount of water that can be distributed
print(max(taps))