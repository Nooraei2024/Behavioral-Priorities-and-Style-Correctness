import sys

n = int(input())
arr = list(map(int, input().split()))
m = int(input())

subarrays = []
for _ in range(m):
    li, ri = map(int, input().split())
    subarrays.append((li, ri))

mexes = []
for (li, ri) in subarrays:
    m = max(arr[li:ri+1])
    mexes.append(m)

smallest_mex = min(mexes)
print(smallest_mex)