import sys

# Read input from stdin
n = int(input())
p = list(map(int, input().split()))

# Calculate the total price of all tickets
total_price = sum(p)

# Calculate the percentage of each ticket that will be donated to the ecological restoration programs
donation_percentage = [x for x in range(1, 101)]

# Initialize an empty list to store the donations
donations = []

# Loop through each ticket and calculate the donation amount
for i in range(n):
    donation = total_price * (donation_percentage[i] / 100)
    donations.append(donation)

# Print the total price of all tickets, followed by the donation amounts for each ticket
print(total_price)
for i in range(n):
    print(donations[i])