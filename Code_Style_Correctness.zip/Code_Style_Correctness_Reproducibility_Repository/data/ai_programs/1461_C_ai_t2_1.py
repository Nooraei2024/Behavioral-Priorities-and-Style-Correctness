import sys

# Read input from stdin
n = int(input())
a = list(map(int, input().split()))
m = int(input())
experiments = []
for _ in range(m):
    r, p = map(int, input().split())
    experiments.append((r, p))

# Check if the permutation is valid
if len(set(a)) != n:
    print("Invalid")
    sys.exit(0)

# Perform the experiments and count the number of times each element appears
counts = {}
for i in range(n):
    counts[a[i]] = counts.get(a[i], 0) + 1

# Check if the results are valid
for r, p in experiments:
    if r > n or p > n:
        print("Invalid")
        sys.exit(0)
    if counts.get(r, 0) < p:
        print("Invalid")
        sys.exit(0)

# Print the results
for i in range(n):
    print(a[i], end=" ")
print()