import sys

n = int(input())
boxes = []
for i in range(n):
    boxes.append([int(x) for x in input().split()])

def can_put_on_top(box1, box2):
    return box1[0] <= box2[1] and box2[0] <= box1[1]

def find_valid_pairs(boxes):
    valid_pairs = []
    for i in range(len(boxes)):
        for j in range(i+1, len(boxes)):
            if can_put_on_top(boxes[i], boxes[j]):
                valid_pairs.append((i, j))
    return valid_pairs

def solve():
    valid_pairs = find_valid_pairs(boxes)
    for i in range(len(valid_pairs)):
        print(f"{valid_pairs[i][0]} {valid_pairs[i][1]}")

solve()