import sys

def is_lucky(s):
    lucky_digits = ["4", "7"]
    for c in s:
        if c not in lucky_digits:
            return False
    return True

for line in sys.stdin:
    s = line.strip()
    if is_lucky(s):
        print("YES")
    else:
        print("NO")