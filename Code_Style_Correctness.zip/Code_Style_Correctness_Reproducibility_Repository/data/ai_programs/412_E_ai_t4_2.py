import re

def recover_emails(string):
    """
    Recovers email addresses from a string of letters.

    Args:
        string (str): The string containing the letters.

    Returns:
        list[str]: A list of valid email addresses recovered from the string.
    """
    emails = []
    for match in re.finditer(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', string):
        email = match.group()
        if '.' not in email or '@' not in email:
            continue
        emails.append(email)
    return emails