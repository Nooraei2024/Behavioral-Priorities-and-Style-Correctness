import sys

# Read input from stdin
n, k = map(int, sys.stdin.readline().split())
a = list(map(int, sys.stdin.readline().split()))
w = list(map(int, sys.stdin.readline().split()))

# Calculate the happiness of each friend
happiness = [0] * k
for i in range(n):
    happiness[a[i] - 1] += w[i]

# Find the maximum happiness
max_happiness = max(happiness)

# Print the result
print(max_happiness)