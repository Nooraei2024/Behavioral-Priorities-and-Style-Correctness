import sys

n = int(input())
a = list(map(int, input().split()))

# Calculate the sum and product of all elements in the array
sum_a = sum(a)
prod_a = 1
for i in range(n):
    prod_a *= a[i]

# If either the sum or the product is equal to zero, do one more step
if sum_a == 0 or prod_a == 0:
    a.append(1)

# Calculate the new sum and product of all elements in the array after adding 1 to each element
sum_b = sum(a)
prod_b = 1
for i in range(n+1):
    prod_b *= a[i]

print(n+1)