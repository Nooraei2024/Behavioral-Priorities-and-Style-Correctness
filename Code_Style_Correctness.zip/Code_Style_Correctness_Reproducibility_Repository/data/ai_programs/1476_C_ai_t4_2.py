import sys

# Read input from stdin
n = int(input())
chains = []
for _ in range(n):
    chains.append([int(x) for x in input().split()])

# Calculate the longest simple cycle
max_cycle = 0
for chain in chains:
    c = chain[0]
    for i in range(1, len(chain)):
        if chain[i] > c:
            c = chain[i]
    max_cycle = max(max_cycle, c)

# Output the longest simple cycle
print(max_cycle)