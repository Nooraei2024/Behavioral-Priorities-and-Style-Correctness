import sys

n = int(input())
coins = list(map(int, input().split()))

for _ in range(n):
    i, j = map(int, input().split())
    coins[i], coins[j] = coins[j], coins[i]
    if coins[i] == 1:
        coins[i] = -1
    else:
        coins[i] = 1
    if coins[j] == 1:
        coins[j] = -1
    else:
        coins[j] = 1

print(*coins, sep=' ')