import sys

# Read input from stdin
pl, pr = map(int, sys.stdin.readline().split())
vl, vr = map(int, sys.stdin.readline().split())

# Calculate the number of lucky numbers in the interval [pl, pr]
lucky_count = 0
for i in range(pl, pr+1):
    if str(i).count("4") + str(i).count("7") == len(str(i)):
        lucky_count += 1

# Calculate the number of lucky numbers in the interval [vl, vr]
unlucky_count = 0
for i in range(vl, vr+1):
    if str(i).count("4") + str(i).count("7") != len(str(i)):
        unlucky_count += 1

# Calculate the probability that Petya's number is lucky
probability = lucky_count / (pr - pl + 1)

# Print the result
print(f"{probability:.6f}")