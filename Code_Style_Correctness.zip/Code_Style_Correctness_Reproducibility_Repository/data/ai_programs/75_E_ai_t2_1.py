import sys

def shortest_path(start, end):
    # Calculate the distance between the start and end points
    distance = ((end[0] - start[0]) ** 2 + (end[1] - start[1]) ** 2) ** 0.5

    # Initialize a list to store the safe points
    safe_points = []

    # Iterate through all the possible points between the start and end points
    for x in range(start[0], end[0] + 1):
        for y in range(start[1], end[1] + 1):
            # Check if the point is safe
            if is_safe(x, y):
                # Add the safe point to the list
                safe_points.append((x, y))

    # Return the shortest distance between the start and end points
    return min([distance] + [abs(end[0] - x) + abs(end[1] - y) for (x, y) in safe_points])

def is_safe(x, y):
    # Check if the point is on an island
    if x == 0 or y == 0:
        return False

    # Check if the point is not on an island
    return True

# Read input from standard input (stdin)
start = tuple(map(int, sys.stdin.readline().split()))
end = tuple(map(int, sys.stdin.readline().split()))

# Print the shortest distance