import sys

# Read input from stdin
n = int(input())

# Initialize variables
a, b = map(int, input().split())

# Calculate the number of excellent numbers
excellent_numbers = 0
for i in range(1, n+1):
    num = str(i)
    if a in num and b in num:
        sum_digits = sum([int(digit) for digit in num])
        if sum_digits >= a and sum_digits <= b:
            excellent_numbers += 1

# Print the result
print(excellent_numbers)