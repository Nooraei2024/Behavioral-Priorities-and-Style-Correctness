import sys

# Read input from standard input
slogan = sys.stdin.readline().strip()

# Calculate the length of the slogan
n = len(slogan)

# Check if the slogan is valid (has at least one character and no more than 100 characters)
if n < 1 or n > 100:
    print("Error: Invalid slogan length")
    exit(1)

# Calculate the width of each square in meters
width = 1.0 / n

# Print the banner with the slogan
print("Banner:")
for i in range(n):
    print(" " * int(i * width) + slogan[i])