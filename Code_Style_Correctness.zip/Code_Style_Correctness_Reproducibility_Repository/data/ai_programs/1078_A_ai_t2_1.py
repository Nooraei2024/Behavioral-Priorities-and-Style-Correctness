import sys

# Read input from stdin
A = tuple(int(i) for i in sys.stdin.readline().split())
B = tuple(int(i) for i in sys.stdin.readline().split())

# Calculate the distance between A and B using the avenue
ax, ay, bx, by = 1, 0, 0, 1
c = -ay * B[0] + ax * B[1]
d = (B[0] - A[0]) ** 2 + (B[1] - A[1]) ** 2
if d % (ax + by) == c:
    print(f"The distance between {A} and {B} is {int(d ** 0.5)}")
else:
    print("No solution found.")