import sys

def solve(n, k, a):
    # Calculate the sum of all integers in the backpack
    total = sum(a)
    
    # Initialize an array to store the number of integers each friend will get
    w = [0] * k
    
    # Fill the array with the number of integers each friend will get
    for i in range(k):
        w[i] = a[i] // total
    
    # Calculate the remainder that needs to be distributed among friends
    rem = a[0] % total
    
    # Distribute the remainder among the friends
    for i in range(k):
        if rem > 0:
            w[i] += 1
            rem -= 1
    
    # Calculate the happiness of each friend
    h = [0] * k
    for i in range(k):
        h[i] = w[i] * (w[i] - 1) // 2
    
    return h

if __name__ == "__main__":
    n, k = map(int, sys.stdin.readline().split())
    a = list(map(int, sys.stdin.readline().split()))
    print(*solve(n, k, a), sep="\n")