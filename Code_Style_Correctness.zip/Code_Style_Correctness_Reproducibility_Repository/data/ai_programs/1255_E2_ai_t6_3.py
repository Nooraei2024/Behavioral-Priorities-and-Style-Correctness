import sys

n = int(input())
a = list(map(int, input().split()))

# Sort the boxes by the number of chocolate pieces in each box
sorted_boxes = sorted(zip(range(1, n+1), a), key=lambda x: x[1], reverse=True)

# Initialize the output list with the first box
output = [sorted_boxes[0][0]]

# Loop through the remaining boxes and add them to the output if they are not already present
for i in range(1, n):
    if sorted_boxes[i][0] not in output:
        output.append(sorted_boxes[i][0])

print(*output)