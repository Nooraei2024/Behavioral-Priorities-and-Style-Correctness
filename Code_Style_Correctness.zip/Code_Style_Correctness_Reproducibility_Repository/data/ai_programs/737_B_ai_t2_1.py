import sys

n = int(input())
k = int(input())

# Create a dictionary to keep track of the ships
ships = {}

# Read the input and update the dictionary
for _ in range(k):
    x, y = map(int, input().split())
    if (x, y) not in ships:
        ships[(x, y)] = 1
    else:
        ships[(x, y)] += 1

# Check if any of the ships have been hit
hit_ships = []
for ship in ships:
    if ships[ship] > 0:
        hit_ships.append(ship)

# Output the result
print(len(hit_ships))
for ship in hit_ships:
    print(*ship, sep=' ')