import sys

s = input()
l = 0
r = len(s) - 1
good_substrings = 0
while l < r:
    if s[l] == '1' and s[r] == '1':
        good_substrings += 1
    l += 1
    r -= 1
print(good_substrings)