import sys

# Read input from stdin
n, m = map(int, sys.stdin.readline().split())
field = []
for _ in range(n):
    field.append(list(map(int, sys.stdin.readline().split())))

# Initialize the inverted field
inv_field = [[0] * m for _ in range(n)]

# Fill the inverted field with "1" where "0" was in the current field and "0" where "1" was
for i in range(n):
    for j in range(m):
        if field[i][j] == 0:
            inv_field[i][j] = 1

# Add the inverted field to the right of the current field
for i in range(n):
    for j in range(m):
        field[i].append(inv_field[i][j])

# Add the inverted field to the bottom of the current field
for i in range(n):
    for j in range(m):
        field.append([inv_field[i][j]])

# Print the final field
print(*field, sep='\n')