import sys

# Read input from stdin
n = int(input())
S = set(map(int, input().split()))

# Generate all permutations of integers from 0 to 2^x - 1
permutations = []
for i in range(2**n):
    permutations.append([j for j in range(i, 2**n, i+1)])

# Filter out invalid permutations
valid_permutations = []
for p in permutations:
    if all(xor(p[i], p[i+1]) in S for i in range(len(p)-1)):
        valid_permutations.append(p)

# Output the first valid permutation
if len(valid_permutations) > 0:
    print(*valid_permutations[0], sep=' ')
else:
    print(-1)