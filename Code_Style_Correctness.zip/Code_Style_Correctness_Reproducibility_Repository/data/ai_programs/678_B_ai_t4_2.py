import sys

def is_leap(year):
    return year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)

def next_same_calendar_year(year):
    if is_leap(year):
        return year + 4
    else:
        return year + 3

if __name__ == "__main__":
    year = int(sys.stdin.readline())
    print(next_same_calendar_year(year))