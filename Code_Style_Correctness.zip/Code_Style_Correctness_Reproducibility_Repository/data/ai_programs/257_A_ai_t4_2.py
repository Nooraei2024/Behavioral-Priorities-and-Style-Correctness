import sys

# Read input from stdin
n = int(input())
devices = []
for _ in range(n):
    devices.append(int(input()))

m = int(input())
sockets = []
for _ in range(m):
    sockets.append(int(input()))

# Check if each device is plugged to electricity
plugged_devices = set()
plugged_filters = set()
for device in devices:
    if device in sockets:
        plugged_devices.add(device)
    else:
        for filter in filters:
            if device in filters[filter]:
                plugged_filters.add(filter)

# Output the result
print(len(plugged_devices))
print(*sorted(list(plugged_devices)), sep='\n')