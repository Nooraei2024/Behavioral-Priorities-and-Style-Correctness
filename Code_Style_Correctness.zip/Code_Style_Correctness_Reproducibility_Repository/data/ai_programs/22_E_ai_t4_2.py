import sys

# Read input from stdin
input_string = sys.stdin.readline().strip()

# Split the input string into a list of integers
numbers = [int(x) for x in input_string.split()]

# Initialize the first person to call
first_person = 1

# Loop through each number in the list
for i in range(len(numbers)):
    # If the current number is odd, call the next person
    if numbers[i] % 2 == 1:
        second_person = first_person * 2 + 1
        print("Calling", second_person)
    # Otherwise, call the previous person
    else:
        second_person = (first_person - 1) // 2
        print("Calling", second_person)
    first_person = second_person

# Print the final result
print("Final Result:", first_person)