import sys

# Read input from stdin
n = int(sys.stdin.readline())
arr = list(map(int, sys.stdin.readline().split()))

# Find the first number that is not equal to its successor
new_num = 0
for i in range(1, n):
    if arr[i] != arr[i-1] + 1:
        new_num = arr[i]
        break

# Replace the first non-consecutive number with a new one
if new_num != 0:
    for i in range(n):
        if arr[i] == new_num:
            arr[i] = new_num + 1

# Sort the array
arr.sort()

# Print output
print(*arr, sep=' ')