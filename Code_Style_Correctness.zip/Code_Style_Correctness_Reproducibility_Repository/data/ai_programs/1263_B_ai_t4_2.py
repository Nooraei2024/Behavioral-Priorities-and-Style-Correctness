import sys

n = int(input())
pins = []
for i in range(n):
    pin = input()
    pins.append(pin)

# check if all PIN codes are different
if len(set(pins)) == n:
    print("No changes needed.")
else:
    # find the smallest digit that is not used in any of the PIN codes
    smallest_digit = 1
    for pin in pins:
        if smallest_digit in pin:
            smallest_digit += 1

    # add the smallest digit to each PIN code
    new_pins = []
    for pin in pins:
        new_pin = str(smallest_digit) + pin[1:]
        new_pins.append(new_pin)

    print("New PIN codes:")
    for new_pin in new_pins:
        print(new_pin)