import sys

def solve(n):
    intervals = []
    for _ in range(n):
        x, y = map(int, input().split())
        if x < y:
            intervals.append((x, y))

    while True:
        try:
            query = int(input())
        except EOFError:
            break

        if query == 1:
            x, y = map(int, input().split())
            if x < y:
                intervals.append((x, y))
        elif query == 2:
            i1, i2 = map(int, input().split())
            if i1 < len(intervals) and i2 < len(intervals):
                if (intervals[i1][0], intervals[i1][1]) in [(intervals[i2][0], intervals[i2][1]), (intervals[i2][0], intervals[i2][1])]:
                    print("YES")
                else:
                    print("NO")
        else:
            print("INVALID QUERY")

if __name__ == "__main__":
    n = int(input())
    solve(n)