def solve(n):
    itinerary = []
    for i in range(1, n + 1):
        if i == 1:
            itinerary.append((i, i + 1))
        elif i == n:
            itinerary.append((i - 1, i))
        else:
            itinerary.append((i - 1, i))
    return itinerary