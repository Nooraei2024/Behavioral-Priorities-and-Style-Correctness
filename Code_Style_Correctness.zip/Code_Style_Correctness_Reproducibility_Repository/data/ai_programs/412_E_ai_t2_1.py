import re

# Read input from stdin
email_string = input()

# Remove all non-alphanumeric characters
email_string = re.sub(r'[^a-zA-Z0-9]', '', email_string)

# Split the string into individual emails
emails = email_string.split('@')

# Iterate over each email and check if it is a valid email address
valid_emails = []
for email in emails:
    # Check if the email contains only letters, numbers, and @ symbols
    if re.match(r'^[a-zA-Z0-9@]+$', email):
        valid_emails.append(email)

# Output the list of valid emails
print(valid_emails)