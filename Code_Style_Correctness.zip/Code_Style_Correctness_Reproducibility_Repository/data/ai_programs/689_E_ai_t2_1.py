import sys

def f(l, r):
    return r - l + 1

n, k = map(int, input().split())
intervals = []
for _ in range(n):
    li, ri = map(int, input().split())
    intervals.append([li, ri])

count = 0
for i in range(len(intervals)):
    for j in range(i+1, len(intervals)):
        if f(intervals[i][0], intervals[j][1]) >= k:
            count += 1
print(count)