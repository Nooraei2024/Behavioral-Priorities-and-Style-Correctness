import sys

# Read input from stdin
n = int(input())
a = list(map(int, input().split()))
b = []
for i in range(n):
    b.append([])
    for j in range(n):
        b[i].append(int(input()))

# Calculate the bitwise AND of each row and column
row_and = [0] * n
col_and = [0] * n
for i in range(n):
    for j in range(n):
        row_and[i] &= b[i][j]
        col_and[j] &= b[i][j]

# Find the first element that is not equal to 0
first_nonzero = -1
for i in range(n):
    for j in range(n):
        if row_and[i] != 0 or col_and[j] != 0:
            first_nonzero = i * n + j
            break
    if first_nonzero != -1:
        break

# Print the result
print(first_nonzero)