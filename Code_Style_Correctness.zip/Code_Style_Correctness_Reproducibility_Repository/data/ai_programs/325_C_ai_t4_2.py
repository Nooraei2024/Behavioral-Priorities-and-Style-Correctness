import sys

# Read input from stdin
n = int(sys.stdin.readline().strip())
monsters = []
diamonds = 0

for _ in range(n):
    monsters.append(int(sys.stdin.readline().strip()))

# Feed the pie to the monster
monsters[0] -= 1
diamonds += 1

# Split the monster into multiple monsters if necessary
while True:
    for i in range(len(monsters)):
        if monsters[i] > 0:
            break
    else:
        break
    monsters[i] -= 1
    diamonds += 1

# Print output to stdout
print(diamonds)