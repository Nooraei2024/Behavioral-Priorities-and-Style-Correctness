import sys

n = int(input())
slogan = input().strip()

# Calculate the length of each square in meters
square_length = 1 / n

# Calculate the width of the banner in meters
banner_width = square_length * n

# Print the valid Python code to create the banner
print(f"banner = \"\"\"\n{slogan}\"\n\"\"\"")
print(f"banner.setWidth({banner_width})")