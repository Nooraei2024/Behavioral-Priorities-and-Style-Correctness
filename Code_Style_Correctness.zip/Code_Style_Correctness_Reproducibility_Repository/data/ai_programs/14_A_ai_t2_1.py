import sys

# Read input from standard input (stdin)
n, m = map(int, sys.stdin.readline().split())
shaded_squares = set()
for _ in range(n):
    row = list(sys.stdin.readline().strip())
    for i, square in enumerate(row):
        if square == '1':
            shaded_squares.add((i, len(shaded_squares)))

# Output to standard output (stdout)
print(len(shaded_squares))
for square in shaded_squares:
    print(*square)