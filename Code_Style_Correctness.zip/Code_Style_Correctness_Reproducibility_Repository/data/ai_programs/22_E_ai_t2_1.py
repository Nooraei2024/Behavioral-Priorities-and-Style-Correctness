import sys

# Read input from stdin
n = int(input())
k = []
for i in range(n):
    k.append(int(input()))

# Calculate the number of calls needed to spread the news
calls = 0
for i in range(1, n+1):
    if i == 1:
        continue
    else:
        calls += (i-1) * k[i]

print(calls)