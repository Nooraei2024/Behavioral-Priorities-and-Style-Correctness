import sys

def plus_from_picture(picture):
    w, h = len(picture[0]), len(picture)
    center = None
    for i in range(w):
        for j in range(h):
            if picture[i][j]:
                if center is not None:
                    return False
                else:
                    center = (i, j)
    if center is None:
        return False
    for i in range(w):
        for j in range(h):
            if abs(i - center[0]) + abs(j - center[1]) != 1:
                return False
    return True

if __name__ == "__main__":
    input_picture = sys.stdin.readline().split()
    w, h = int(input_picture[0]), int(input_picture[1])
    picture = []
    for _ in range(h):
        picture.append(list(sys.stdin.readline().strip()))
    print(plus_from_picture(picture))