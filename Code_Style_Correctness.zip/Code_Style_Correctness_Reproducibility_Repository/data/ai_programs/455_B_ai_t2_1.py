import sys

def solve(n, k):
    strings = []
    for _ in range(n):
        strings.append(input())
    
    # Initialize the word as empty
    word = ""
    
    # Play the game k times
    for i in range(k):
        # Get the current player's move
        move = input()
        
        # Check if the move is valid
        if not any(move.startswith(string) for string in strings):
            return "Andrew"
        
        # Update the word and check if it is a prefix of any string
        word += move
        if any(word.startswith(string) for string in strings):
            continue
        else:
            return "Alex"
    
    # If we reach this point, the game has ended in a draw
    return "Draw"

# Read input from standard input (stdin) and write output to standard output (stdout)
n = int(input())
k = int(input())
print(solve(n, k))