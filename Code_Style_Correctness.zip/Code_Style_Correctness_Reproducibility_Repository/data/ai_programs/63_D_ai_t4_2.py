import sys

# Read input from standard input (stdin)
a, b, c, d = map(int, sys.stdin.readline().split())

# Calculate the area of each rectangle
rectangle_a = a * b
rectangle_c = c * d

# Calculate the total area of the island
total_area = rectangle_a + rectangle_c

# Initialize an empty list to store the valid partitionings
valid_partitions = []

# Loop through all possible partitionings of the island
for i in range(1, total_area + 1):
    # Calculate the area of each partition
    partition_a = a * (i // a)
    partition_c = c * (total_area - partition_a)
    
    # Check if the partitioning is valid
    if partition_a > 0 and partition_c > 0:
        # Add the valid partitioning to the list
        valid_partitions.append((partition_a, partition_c))

# Output the number of valid partitionings
print(len(valid_partitions))

# Output each valid partitioning on a new line
for partition in valid_partitions:
    print(*partition)