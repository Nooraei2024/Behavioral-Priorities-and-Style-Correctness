import sys

n = int(input())
edges = []
for _ in range(n):
    edges.append([int(x) for x in input().split()])

# Initialize all edges as black
black_edges = set((i, j) for i in range(1, n + 1) for j in range(i + 1, n + 1))

# Check if the graph is a beard graph
for edge in edges:
    if len(edge) > 2 or (len(edge) == 2 and edge[0] != edge[1]):
        print("NO")
        sys.exit()

print("YES")