import sys

# Read input from stdin
n, m = map(int, sys.stdin.readline().split())
s_list = list(map(int, sys.stdin.readline().split()))

# Initialize the board with blank cells
board = [0] * n

# Place the heroes on the board
for i in range(m):
    board[s_list[i] - 1] = 1

# Loop through each cell of the board and check if it contains a monster or potion
for i in range(n):
    # If the cell contains a monster, move the hero to the next blank cell
    if board[i] == 1:
        for j in range(i + 1, n):
            if board[j] == 0:
                board[j] = 2
                break

# Print the final state of the board
print(*board)