import sys

n = int(input())
k = int(input())

# Initialize the blackboard with the given numbers
blackboard = []
for i in range(n):
    blackboard.append(int(input()))

# Check if it is possible to make the final number equal to 1
can_make_one = False

# Try all possible combinations of two numbers on the blackboard
for i in range(n - 1):
    for j in range(i + 1, n):
        # Calculate the sum of the two numbers
        sum = blackboard[i] + blackboard[j]
        
        # Check if the sum is divisible by k
        if sum % k == 0:
            # If it is, erase the two numbers and write one extra number
            blackboard.pop(i)
            blackboard.pop(j - 1)
            blackboard.append(sum / k)
            
            # Check if the final number is equal to 1
            if sum / k == 1:
                can_make_one = True
                break

# Output the result
if can_make_one:
    print("Yes")
else:
    print("No")