import sys

def solve(a):
    n = len(a)
    dp = [0] * (n + 1)
    for i in range(n - 1, -1, -1):
        dp[i] = max(dp[i], dp[i + 1])
        if a[i] > 2:
            dp[i] += 1
    return sum(dp)

if __name__ == "__main__":
    n = int(input())
    a = list(map(int, input().split()))
    print(solve(a))