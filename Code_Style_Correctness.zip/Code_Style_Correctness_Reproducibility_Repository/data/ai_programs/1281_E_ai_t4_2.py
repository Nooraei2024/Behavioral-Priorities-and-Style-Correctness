import sys

# Read input from stdin
n = int(input())
k = 2*n
pairs = []
for _ in range(k):
    pairs.append(list(map(int, input().split())))

# Assign each person to a house
houses = [[] for i in range(2*n)]
for pair in pairs:
    houses[pair[0]].append(pair[1])
    houses[pair[1]].append(pair[0])

# Output the assignment
for house in houses:
    print(*house, sep=' ')