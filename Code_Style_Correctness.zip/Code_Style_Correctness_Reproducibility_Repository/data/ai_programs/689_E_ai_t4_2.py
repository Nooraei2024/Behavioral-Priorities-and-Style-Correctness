import sys

def f(l, r):
    return r - l + 1

n, k = map(int, input().split())
intervals = []
for _ in range(n):
    li, ri = map(int, input().split())
    intervals.append([li, ri])

result = 0
for i in range(len(intervals) - k + 1):
    current_interval = intervals[i:i+k]
    x_min = min(current_interval, key=lambda x: x[0])[0]
    x_max = max(current_interval, key=lambda x: x[1])[1]
    result += f(x_min, x_max)

print(result)