import sys

n, k = map(int, input().split())
a = list(map(int, input().split()))
w = list(map(int, input().split()))

# Calculate the total number of integers to be distributed
total = sum(a)

# Initialize an empty dictionary to store the distribution of integers
distribution = {}

# Loop through each integer in the backpack
for i in range(n):
    # Get the current integer and its weight
    curr_int, curr_weight = a[i], w[i]
    
    # Check if the current integer has already been distributed to a friend
    if curr_int in distribution:
        # If it has, increment the count of integers distributed to that friend
        distribution[curr_int] += 1
    else:
        # If not, add the current integer to the dictionary with its weight as the count
        distribution[curr_int] = curr_weight
    
# Calculate the total number of integers distributed to each friend
friend_counts = [distribution.get(i, 0) for i in range(1, k+1)]

# Calculate the happiness of each friend
happiness = [sum(a[i] * w[i] for i in range(k+1)) - sum(friend_counts[i] * a[i] for i in range(k+1))]

print(*happiness, sep='\n')