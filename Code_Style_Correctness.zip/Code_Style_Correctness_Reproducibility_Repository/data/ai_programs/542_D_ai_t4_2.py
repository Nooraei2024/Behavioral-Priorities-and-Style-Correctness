import sys

# Read input from stdin
code = sys.stdin.readline().strip()

# Validate input
if len(code) != 5:
    print("Invalid input")
    exit(1)

# Check if the code is a valid Python variable name
if not code.isidentifier():
    print("Invalid input")
    exit(1)

# Check if the code is a valid Python keyword
if code in ["False", "None", "True"]:
    print("Invalid input")
    exit(1)

# Check if the code is a valid Python function name
if code.startswith("_"):
    print("Invalid input")
    exit(1)

# Check if the code is a valid Python variable name
if not code.isidentifier():
    print("Invalid input")
    exit(1)

# Print the validated code
print(code)