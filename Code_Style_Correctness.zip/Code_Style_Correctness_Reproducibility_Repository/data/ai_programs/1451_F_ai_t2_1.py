import sys

n, m = map(int, input().split())
matrix = [[int(x) for x in input().split()] for _ in range(n)]

# Initialize variables
r1, c1 = 0, 0
r2, c2 = 0, 0
t = 0

# Loop through the matrix and find the first non-zero cell
for i in range(n):
    for j in range(m):
        if matrix[i][j] != 0:
            r1, c1 = i + 1, j + 1
            break

# If no non-zero cell is found, the game ends
if r1 == 0 or c1 == 0:
    print("No solution")
    sys.exit(0)

# Loop through the matrix and find the first cell with value t
for i in range(n):
    for j in range(m):
        if matrix[i][j] == t:
            r2, c2 = i + 1, j + 1
            break

# If no cell with value t is found, the game ends
if r2 == 0 or c2 == 0:
    print("No solution")
    sys.exit(0)

# Decrease the value of t
t -= 1

# Print the updated matrix
print("\n".join([" ".join([str(x) for x in row]) for row in matrix]))