import sys

def solve(n):
    # create a dictionary to store the parts and their dependencies
    parts = {}
    for i in range(n):
        parts[i+1] = []

    # read the input from stdin
    for line in sys.stdin:
        parts[int(line.split()[0])].append(int(line.split()[1]))

    # find the parts that can be completed on each computer
    computers = {}
    for i in range(3):
        computers[i+1] = []
        for part in parts:
            if len(parts[part]) == 0 or all(p in computers[i+1] for p in parts[part]):
                computers[i+1].append(part)

    # output the solution
    print("Computer 1:", ", ".join([str(p) for p in computers[1]]))
    print("Computer 2:", ", ".join([str(p) for p in computers[2]]))
    print("Computer 3:", ", ".join([str(p) for p in computers[3]]))