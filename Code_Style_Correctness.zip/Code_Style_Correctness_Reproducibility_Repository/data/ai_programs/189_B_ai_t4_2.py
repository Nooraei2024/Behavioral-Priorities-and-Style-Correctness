import sys

w, h = map(int, input().split())

# Calculate the number of rhombi with vertices at integer points
num_rhombi = 0
for x in range(w+1):
    for y in range(h+1):
        if x + y <= w and x - y <= h:
            num_rhombi += 1

# Print the result
print(num_rhombi)