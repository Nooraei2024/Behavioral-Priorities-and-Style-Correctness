import sys

for line in sys.stdin:
    num = int(line)
    if is_prime(num):
        print("Prime")
    elif is_palindromic(num):
        print("Palindromic")
    else:
        print("Neither Prime nor Palindromic")
def is_prime(n):
    if n < 2:
        return False
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True