import sys

n, d = map(int, input().split())
m = 10**9 + 7

for i in range(n):
    if (i - 1) * m % n == 0:
        continue
    else:
        break

x = (i - 1) * m + d
if x >= n * m:
    print("INF")
else:
    print(x)