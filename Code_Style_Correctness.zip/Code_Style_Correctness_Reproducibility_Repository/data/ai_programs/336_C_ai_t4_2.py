import sys

# Read input from stdin
n = int(input())
a = list(map(int, input().split()))

# Find the maximum beauty v such that a1, a2, ..., an are divisible by 2v without remainder
v = 0
while True:
    if all(ai % (2 * v) == 0 for ai in a):
        break
    v += 1

# Output the maximum beauty v
print(v)