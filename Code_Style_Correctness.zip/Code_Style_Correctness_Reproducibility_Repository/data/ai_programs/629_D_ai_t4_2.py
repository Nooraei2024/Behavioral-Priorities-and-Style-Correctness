import sys

# Read input from stdin
n = int(input())

# Initialize variables
cake_count = 0
cake_volume = 0

# Loop through each cake
for i in range(1, n+1):
    # Calculate the volume of the current cake
    cake_volume += (2 * 3.14 * (i**2) + 2 * 3.14 * i) / 3
    
    # Check if the current cake can be placed on top of the previous one
    if cake_count > 0 and cake_volume <= cake_volume:
        break
    
    # Increment the number of cakes and update the volume
    cake_count += 1

# Print the final answer
print(cake_count)