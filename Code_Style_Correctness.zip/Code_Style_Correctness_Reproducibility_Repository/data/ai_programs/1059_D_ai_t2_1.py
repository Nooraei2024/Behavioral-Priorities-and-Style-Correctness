import sys

# Read input from stdin
n = int(input())
lairs = []
for i in range(n):
    x, y = map(int, input().split())
    lairs.append((x, y))

# Calculate the center of the circle
center_x = sum([x for x, y in lairs]) / n
center_y = sum([y for x, y in lairs]) / n
center = (center_x, center_y)

# Calculate the radius of the circle
radius = 0
for i in range(n):
    radius = max(radius, abs(lairs[i][0] - center_x) + abs(lairs[i][1] - center_y))

# Check if the river intersects with the reserve
intersects = False
for x, y in lairs:
    if abs(x - center_x) <= radius and abs(y - center_y) <= radius:
        intersects = True
        break

# Output the result
if intersects:
    print("YES")
else:
    print("NO")