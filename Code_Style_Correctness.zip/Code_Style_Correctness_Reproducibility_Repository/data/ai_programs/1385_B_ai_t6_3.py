import sys

def restore_permutation(p):
    n = len(p)
    result = []
    for i in range(n):
        for j in range(i, 2*n, n):
            result.append(p[j % n])
    return result

if __name__ == '__main__':
    p = list(map(int, input().split()))
    print(restore_permutation(p))