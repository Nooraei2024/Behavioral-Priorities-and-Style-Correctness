import sys

# Read input from stdin
E = set(map(tuple, sys.stdin.read().split()))

# Find all vertices that are incident on at least one edge in E'
vertices = set()
for edge in E:
    vertices.add(edge[0])
    vertices.add(edge[1])

# Compute the independent set
V_prime = vertices - E

print(" ".join(map(str, V_prime)))