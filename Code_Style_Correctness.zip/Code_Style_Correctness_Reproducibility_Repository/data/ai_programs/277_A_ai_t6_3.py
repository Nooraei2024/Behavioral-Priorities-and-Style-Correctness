import sys

n, m = map(int, input().split())
languages = []
for _ in range(n):
    languages.append(list(map(int, input().split())))

# Calculate the minimum number of lessons needed for each employee to learn all official languages
min_lessons = [0] * n
for i in range(n):
    for lang in languages[i]:
        min_lessons[i] += 1

# Print the minimum number of lessons needed for each employee to learn all official languages
print(*min_lessons, sep='\n')