import sys

# Read input from stdin
a, b = map(int, sys.stdin.readline().split())

# Initialize variables for the game
k = 1
turn = 0

while True:
    # Check if a is less than or equal to b
    if a <= b:
        # If so, break out of the loop
        break
    
    # Cast spell 1 (replace b with b - ak)
    b -= k * a
    
    # Increment turn counter
    turn += 1
    
    # Check if a is less than or equal to b after casting spell 1
    if a <= b:
        # If so, break out of the loop
        break
    
    # Cast spell 2 (replace b with b mod a)
    b %= a
    
    # Increment turn counter
    turn += 1

# Output the final values of a and b
print(a, b)