import sys

n, m = map(int, input().split())

for i in range(10**2230):
    a = i
    b = (i + 1) % 10**2230
    if s(a) >= n and s(b) >= n and s(a + b) <= m:
        print(a, b)
        break
else:
    print(-1, -1)