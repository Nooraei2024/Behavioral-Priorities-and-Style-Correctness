import sys

n = int(input())
k = int(input())

def split_square(a):
    if a == 1:
        return False
    else:
        return True

for i in range(k):
    n = n // 2

if split_square(n):
    print("YES")
else:
    print("NO")