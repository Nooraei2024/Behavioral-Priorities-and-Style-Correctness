import sys

# Read input from stdin
input_str = sys.stdin.readline().strip()

# Split input into two sets of integers
first_set, second_set = input_str.split(',')

# Calculate the numerator and denominator
numerator = int(first_set)
denominator = int(second_set)

# Reduce the fraction if necessary
gcd = reduce(lambda x, y: x*y, range(1, denominator + 1))
if gcd > 1:
    numerator //= gcd
    denominator //= gcd

# Print the reduced fraction
print(f'{numerator}/{denominator}')