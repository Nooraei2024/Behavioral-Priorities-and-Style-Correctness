import sys

def get_comments(article):
    # Split the article into individual comments
    comments = article.split('|')
    
    # Initialize an empty dictionary to store the comments
    comment_dict = {}
    
    # Iterate over each comment and add it to the dictionary
    for comment in comments:
        parent_comment, child_comment = comment.split(',')
        if parent_comment not in comment_dict:
            comment_dict[parent_comment] = []
        comment_dict[parent_comment].append(child_comment)
    
    return comment_dict

def get_comment_tree(comments):
    # Initialize an empty list to store the comment tree
    comment_tree = []
    
    # Iterate over each comment and add it to the comment tree
    for comment in comments:
        if len(comment) == 0:
            continue
        parent_comment, child_comment = comment.split(',')
        if parent_comment not in comment_tree:
            comment_tree.append(parent_comment)
        if child_comment not in comment_tree:
            comment_tree.append(child_comment)
    
    return comment_tree

def main():
    # Read the article from standard input
    article = sys.stdin.readline().strip()
    
    # Get the comments dictionary
    comments = get_comments(article)
    
    # Get the comment tree
    comment_tree = get_comment_tree(comments)