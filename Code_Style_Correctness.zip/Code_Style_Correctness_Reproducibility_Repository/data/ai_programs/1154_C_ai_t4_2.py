import sys

# Read input from stdin
day = sys.stdin.readline().strip()

# Map days of the week to food types
food_map = {
    "Monday": "fish",
    "Tuesday": "rabbit",
    "Wednesday": "chicken",
    "Thursday": "fish",
    "Friday": "chicken",
    "Saturday": "rabbit",
    "Sunday": "fish"
}

# Get the food type for the current day
food_type = food_map[day]

# Print the output
print(f"{food_type}_stake")