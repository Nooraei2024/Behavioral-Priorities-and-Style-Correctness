import sys

# Read input from stdin
n = int(input())
devices = []
for _ in range(n):
    devices.append(int(input()))

m = int(input())
sockets = []
for _ in range(m):
    sockets.append(int(input()))

# Check if the devices can be plugged to the sockets
plugged_devices = set()
for device in devices:
    for socket in sockets:
        if device <= socket:
            plugged_devices.add(device)
            break

print(len(plugged_devices))