import sys

# Read input from stdin
n, m = map(int, sys.stdin.readline().split())
A = []
for i in range(n):
    A.append([])
    for j in range(m):
        A[i].append(int(sys.stdin.readline()))

# Calculate the spectrum of the matrix A
X = [0] * n
Y = [0] * m
for i in range(n):
    for j in range(m):
        X[i] += A[i][j]
        Y[j] += A[i][j]

# Print the spectrum as a tuple
print((X, Y))