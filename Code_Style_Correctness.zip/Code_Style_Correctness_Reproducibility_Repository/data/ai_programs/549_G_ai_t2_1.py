import sys

# Read input from stdin
n = int(input())
berland_dollars = list(map(int, input().split()))

# Initialize a dictionary to store the number of dollars for each person
person_dollars = {}
for i in range(n):
    person_dollars[i] = berland_dollars[i]

# Loop through the queue and perform swaps
for i in range(n-1):
    # Check if the current person can afford to swap with the next person
    if person_dollars[i] >= 1:
        # If so, update the dictionary and reduce the number of dollars for both people
        person_dollars[i] -= 1
        person_dollars[i+1] -= 1

# Print the final order of the queue
print(person_dollars)