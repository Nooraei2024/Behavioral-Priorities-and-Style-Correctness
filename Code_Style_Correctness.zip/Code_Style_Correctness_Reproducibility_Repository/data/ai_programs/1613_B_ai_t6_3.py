import math

def solve(a):
    n = len(a)
    pairs = []
    for i in range(n):
        for j in range(i+1, n):
            x = a[i]
            y = a[j]
            if x != y and x % y == 0:
                pairs.append((x, y))
    return pairs

if __name__ == '__main__':
    input_n = int(input())
    a = [int(x) for x in input().split()]
    pairs = solve(a)
    print(*pairs, sep='\n')