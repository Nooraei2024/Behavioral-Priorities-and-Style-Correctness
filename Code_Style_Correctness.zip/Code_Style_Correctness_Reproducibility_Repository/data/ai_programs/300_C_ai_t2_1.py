input()
a, b = map(int, input().split())
length = int(input())

def is_good(n):
    s = str(n)
    for c in s:
        if c not in (a, b):
            return False
    return True

def is_excellent(n):
    s = str(n)
    sum = 0
    for c in s:
        if c == a or c == b:
            sum += int(c)
    return sum in (a, b)

count = 0
for i in range(1, length+1):
    n = a**i + b**i
    if is_good(n) and is_excellent(n):
        count += 1
print(count)