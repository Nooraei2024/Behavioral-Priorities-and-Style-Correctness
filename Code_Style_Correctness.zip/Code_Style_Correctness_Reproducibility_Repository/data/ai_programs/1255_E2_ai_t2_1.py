import sys

n = int(input())
a = list(map(int, input().split()))

# Initialize a dictionary to store the number of chocolates in each box
boxes = {}
for i in range(1, n+1):
    boxes[i] = a[i-1]

# Sort the boxes by the number of chocolates in each box
sorted_boxes = sorted(boxes.items(), key=lambda x: x[1], reverse=True)

# Print the sorted list of boxes
print(*sorted_boxes, sep='\n')