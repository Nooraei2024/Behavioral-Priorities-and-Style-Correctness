import sys

# Read input from stdin
input_string = sys.stdin.readline().strip()

# Split input string into individual attributes of Master Yang and monster
yang_attributes = input_string.split(' ')
monster_attributes = yang_attributes[1].split(' ')

# Extract individual attributes of Master Yang and monster
yang_hp, yang_atk, yang_def = [int(x) for x in yang_attributes]
monster_hp, monster_atk, monster_def = [int(x) for x in monster_attributes]

# Calculate the decrease of HP for both Master Yang and the monster every second
yang_hp -= max(0, yang_atk - monster_def)
monster_hp -= max(0, monster_atk - yang_def)

# Check if either Master Yang or the monster's HP is ≤ 0
if yang_hp <= 0 or monster_hp <= 0:
    # If both are ≤ 0, then Master Yang wins
    if yang_hp <= 0 and monster_hp <= 0:
        print("Yang")
    # Otherwise, the monster wins
    else:
        print("Monster")
# Otherwise, continue the battle until one of them is defeated
else:
    print("Battle continues...")