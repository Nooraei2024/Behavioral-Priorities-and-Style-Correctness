import sys

# Read input from stdin
n = int(sys.stdin.readline())

# Initialize variables
rain_count = 0
pouring_rain = False

# Loop through each line of input
for i in range(n):
    # Get the current line of input
    line = sys.stdin.readline().strip()
    
    # Check if the line is "Pouring rain"
    if line == "Pouring rain":
        # Increment the rain count and set pouring_rain to True
        rain_count += 1
        pouring_rain = True
    else:
        # If the line is not "Pouring rain", set pouring_rain to False
        pouring_rain = False
    
    # Check if it's raining and we are pouring rain
    if rain_count > 0 and pouring_rain:
        # Print "YES"
        print("YES")
        break
    else:
        # If it's not raining or we are not pouring rain, print "NO"
        print("NO")