import sys
from collections import deque

def bfs(graph, start):
    queue = deque([start])
    visited = set()
    while queue:
        vertex = queue.popleft()
        if vertex not in visited:
            visited.add(vertex)
            for neighbor in graph[vertex]:
                queue.append(neighbor)
    return visited

def solve():
    # Read the number of vertices and edges from standard input
    n, m = map(int, sys.stdin.readline().split())
    
    # Initialize a dictionary to store the graph
    graph = {}
    for i in range(1, n+1):
        graph[i] = []
    
    # Read the edges from standard input and add them to the graph
    for _ in range(m):
        u, v = map(int, sys.stdin.readline().split())
        graph[u].append(v)
        graph[v].append(u)
    
    # Find the vertex that Denis is located at
    denis_vertex = 1
    
    # Use BFS to find all the vertices that are reachable from Denis's vertex
    visited = bfs(graph, denis_vertex)
    
    # Print the number of vertices that are reachable from Denis's vertex
    print(len(visited))