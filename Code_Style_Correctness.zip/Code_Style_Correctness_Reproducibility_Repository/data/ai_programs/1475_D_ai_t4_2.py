import sys

# Read input from stdin
n = int(input())
a = list(map(int, input().split()))
m = int(input())
b = list(map(int, input().split()))

# Calculate the total memory usage of each application
total_memory = [0] * n
for i in range(n):
    total_memory[i] = a[i] * b[i]

# Sort the applications by their memory usage in descending order
sorted_indices = sorted(range(n), key=lambda x: total_memory[x], reverse=True)

# Remove the least important applications until the desired amount of memory is freed
total_freed = 0
while total_freed < m and len(sorted_indices) > 0:
    i = sorted_indices.pop()
    total_freed += a[i]

# Print the final list of applications, in the order they were given
print(*sorted_indices, sep=' ')