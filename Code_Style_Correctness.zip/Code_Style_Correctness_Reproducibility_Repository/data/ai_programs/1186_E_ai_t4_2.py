import sys

n, m = map(int, input().split())
field = []
for _ in range(n):
    field.append([int(x) for x in input()])

# Step 1: find new inverted field
new_field = [[0] * m for _ in range(n)]
for i in range(n):
    for j in range(m):
        if field[i][j] == 0:
            new_field[i][j] = 1

# Step 2: add inverted field to the right
for i in range(n):
    for j in range(m):
        if new_field[i][j] == 1:
            field[i].append(0)

# Step 3: add inverted field to the bottom
for i in range(n):
    for j in range(m):
        if new_field[i][j] == 1:
            field.append([0] * m)

print(*field, sep='\n')