import sys

# Read input from stdin
input_string = sys.stdin.readline().strip()

# Split the input string into a list of vertices
vertices = input_string.split(' ')

# Initialize the snitch's position at the first vertex
x0, y0, z0 = map(int, vertices[0].split(','))

# Initialize the snitch's velocity vector
vx0, vy0, vz0 = 0, 0, 0

# Loop through each vertex and calculate the snitch's position at that point
for i in range(1, len(vertices)):
    x1, y1, z1 = map(int, vertices[i].split(','))
    dx = x1 - x0
    dy = y1 - y0
    dz = z1 - z0
    vx = (dx * 2) / (len(vertices) - 1)
    vy = (dy * 2) / (len(vertices) - 1)
    vz = (dz * 2) / (len(vertices) - 1)
    x0 += vx
    y0 += vy
    z0 += vz

# Print the snitch's final position
print(f"The snitch is at ({x0}, {y0}, {z0})")