import sys

n = int(input())
paints = []
for i in range(n):
    paints.append(int(sys.stdin.readline()))

current_color = 1
next_square = 1
while next_square <= n:
    if current_color == paints[next_square - 1]:
        print("YES")
        break
    else:
        current_color += 1
        next_square += 1
else:
    print("NO")