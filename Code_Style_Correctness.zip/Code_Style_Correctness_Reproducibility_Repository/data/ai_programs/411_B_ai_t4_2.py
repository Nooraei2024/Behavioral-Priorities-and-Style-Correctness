import sys

n, k = map(int, input().split())

# Create a list to store the instructions for each core
instructions = [[] for _ in range(n)]

# Read the instructions for each core from stdin
for i in range(n):
    instructions[i] = list(map(int, input().split()))

# Initialize the cache memory with 0s
cache = [0] * k

# Execute the instructions and update the cache
for core in range(n):
    for instruction in instructions[core]:
        if instruction == -1:
            continue
        else:
            cache[instruction] += 1

# Print the cache memory
print(*cache, sep=' ')