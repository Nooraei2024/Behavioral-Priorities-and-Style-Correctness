import sys

# Read input from stdin
s = sys.stdin.readline().strip()
n = int(sys.stdin.readline())
m = int(sys.stdin.readline())
t = []
for _ in range(m):
    t.append(sys.stdin.readline().strip())

# Calculate the shortest prefix length for each friend
prefix_lengths = [0] * m
for i in range(m):
    for j in range(n):
        if t[i][j] == 'a':
            prefix_lengths[i] += 1
            break

# Output the shortest prefix length for each friend
for i in range(m):
    print(prefix_lengths[i])