import sys

n, m = map(int, input().split())
puzzle = []
for _ in range(n):
    puzzle.append([int(x) for x in input().split()])

# Check if the puzzle is valid (all rows and columns have the same number of elements)
if len(set(len(row) for row in puzzle)) != 1:
    print("Invalid puzzle")
    sys.exit(1)

# Fill in the empty parts with the missing picture
for i in range(n):
    for j in range(m):
        if puzzle[i][j] == 0:
            puzzle[i][j] = 1

# Print the completed puzzle
print("\n".join(" ".join(str(x) for x in row) for row in puzzle))