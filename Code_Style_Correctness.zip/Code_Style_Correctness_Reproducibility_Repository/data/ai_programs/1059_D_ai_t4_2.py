import sys

# Read input from stdin
n = int(input())
lairs = []
for i in range(n):
    x, y = map(int, input().split())
    lairs.append((x, y))

# Calculate the center of the circle
center_x = sum([lair[0] for lair in lairs]) / n
center_y = sum([lair[1] for lair in lairs]) / n
center = (center_x, center_y)

# Calculate the radius of the circle
radius = 0
for lair in lairs:
    radius = max(radius, abs(lair[0] - center_x) + abs(lair[1] - center_y))

# Check if the river intersects with the reserve
intersects = False
for i in range(n):
    x, y = lairs[i]
    distance = abs(center_x - x) + abs(center_y - y)
    if distance <= radius:
        intersects = True
        break

# Output the result
if intersects:
    print("YES")
else:
    print("NO")