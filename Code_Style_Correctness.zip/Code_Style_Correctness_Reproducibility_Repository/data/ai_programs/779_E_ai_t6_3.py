import sys

# Read input from stdin
m = int(sys.stdin.readline())
n = int(sys.stdin.readline())

# Initialize variables
variables = []
for i in range(n):
    variables.append(int(sys.stdin.readline()))

# Compute the values of the n variables
values = []
for i in range(n):
    value = variables[i]
    for j in range(m-1, -1, -1):
        if value % 2 == 1:
            value = value ^ (1 << j)
        else:
            value = value & ~(1 << j)
    values.append(value)

# Print the output
for i in range(n):
    print(values[i])