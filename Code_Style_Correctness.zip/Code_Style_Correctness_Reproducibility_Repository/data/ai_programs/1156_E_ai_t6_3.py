from sys import stdin

def solve(p):
    n = len(p)
    special_segments = 0
    for i in range(n-1):
        l, r = i+1, n-1
        while l < r and p[l] + p[r] <= p[i]:
            r -= 1
        if p[l] + p[r] == p[i]:
            special_segments += 1
    return special_segments

if __name__ == '__main__':
    n = int(stdin.readline())
    p = list(map(int, stdin.readline().split()))
    print(solve(p))