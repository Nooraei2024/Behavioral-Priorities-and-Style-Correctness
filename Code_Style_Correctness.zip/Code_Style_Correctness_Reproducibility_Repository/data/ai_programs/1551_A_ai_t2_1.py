import sys

n = int(input())
c_1 = 0
c_2 = 0

while n > 0:
    if n % 2 == 0:
        c_2 += 1
        n -= 2
    else:
        c_1 += 1
        n -= 1

print(c_1, c_2)