import sys

# Read input from stdin
n = int(sys.stdin.readline().strip())
a = list(map(int, sys.stdin.readline().split()))
m = int(sys.stdin.readline().strip())
b = [0] * m

# Assign the value of a1 to some variable bx (1 ≤ x ≤ m)
b[n-1 % m] += a[0]

# Each of the following n - 1 operations is assigning to some variable by the value that is equal to the sum of values that are stored in the variable
for i in range(2, n+1):
    b[(i-1) % m] = (b[i-1 % m] + a[i-1]) % 1000000007

# Output only valid Python code
print(*b, sep='\n')