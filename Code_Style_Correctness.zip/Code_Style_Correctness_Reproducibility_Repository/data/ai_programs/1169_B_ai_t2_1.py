n, m = map(int, input().split())

def check_pairs(a, b):
    for i in range(len(a)):
        if a[i] == x or b[i] == y:
            return True
    return False

x = 1
while x <= n:
    y = x + 1
    while y <= n:
        if check_pairs(range(1, n+1), range(1, n+1)):
            print("Yes")
            break
        else:
            y += 1
    else:
        print("No")
        break