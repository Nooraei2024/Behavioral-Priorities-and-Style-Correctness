import sys

# Read input from standard input (stdin)
n = int(sys.stdin.readline())

# Initialize a dictionary to store the nodes and their parents
nodes = {}

# Loop through each edge in the directed graph
for _ in range(n):
    # Read the current edge from stdin
    edge = sys.stdin.readline().split()
    
    # Add the node to the dictionary if it doesn't already exist
    if edge[0] not in nodes:
        nodes[edge[0]] = []
    
    # Add the parent of the current node to the list of parents
    nodes[edge[0]].append(edge[1])

# Initialize a variable to store the longest path in the graph
longest_path = 0

# Loop through each node in the graph
for node in nodes:
    # Initialize a variable to store the current path length
    path_length = 0
    
    # Loop through each parent of the current node
    for parent in nodes[node]:
        # Increment the path length by the length of the parent's path
        path_length += len(nodes[parent])
    
    # Update the longest path if the current path is longer than the previous longest path
    longest_path = max(longest_path, path_length)

# Print the longest path in the graph
print(longest_path)