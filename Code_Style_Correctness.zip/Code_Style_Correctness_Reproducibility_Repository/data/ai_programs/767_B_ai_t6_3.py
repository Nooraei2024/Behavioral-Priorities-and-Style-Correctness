import sys

# read input from stdin
ts = int(sys.stdin.readline())
tf = int(sys.stdin.readline())

# calculate the last minute when the receptionist starts working
start_time = 1440 - ts

# calculate the last minute when the receptionist closes
end_time = start_time + tf - 1

# print the answer
print(f"{start_time} {end_time}")