import sys

# Read input from standard input (stdin)
n = int(input())

# Initialize variables
simple_cake_volume = 0
special_cake_volume = 0

# Calculate the volume of each simple cake and the total volume of all simple cakes
for i in range(n):
    radius, height = map(int, input().split())
    simple_cake_volume += (4/3) * math.pi * radius ** 3 * height

# Calculate the volume of the special cake
special_cake_volume = simple_cake_volume / n

# Print the result
print(int(special_cake_volume))