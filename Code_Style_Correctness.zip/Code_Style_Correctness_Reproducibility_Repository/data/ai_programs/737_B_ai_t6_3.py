import sys

n = int(input())
k = int(input())

# Create a dictionary to store the locations of the ships
ships = {}

# Read the input and update the dictionary
for _ in range(k):
    cell = int(input()) - 1
    if cell not in ships:
        ships[cell] = True

# Check if any of the cells have been hit
hit_cells = []
for i in range(n):
    if i in ships:
        hit_cells.append(i + 1)

# Output the hit cells
print(*hit_cells, sep=' ')