import sys

# Read input from stdin
n = int(input())
k = n // 2
people = []
for _ in range(n):
    people.append(list(map(int, input().split())))

# Assign each person to a house based on their happiness level
houses = [[] for _ in range(k)]
for i in range(n):
    houses[people[i][1] - 1].append(people[i])

# Output the assignment
for house in houses:
    print(*house, sep=' ')