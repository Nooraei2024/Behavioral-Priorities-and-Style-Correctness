import sys

s = input()
q = int(input())

for i in range(q):
    li, ri = map(int, input().split())
    sub_str = s[li-1:ri]
    count = 0
    for j in range(len(sub_str)):
        if sub_str[j] == sub_str[-j-1]:
            count += 1
    print(count)