# Read input from stdin
a, b, c = map(int, input().split())

# Calculate the length of the longest good string
max_length = 0
for i in range(a):
    for j in range(b):
        for k in range(c):
            s = 'ab' * (i + j) + 'a' * k
            if is_good(s):
                max_length = max(max_length, len(s))

# Print the length of the longest good string
print(max_length)

def is_good(s):
    # Check if the string consists only of 'a' and 'b' letters
    for c in s:
        if c not in ['a', 'b']:
            return False
    
    # Check if every two consecutive letters are distinct
    for i in range(len(s) - 1):
        if s[i] == s[i + 1]:
            return False
    
    return True