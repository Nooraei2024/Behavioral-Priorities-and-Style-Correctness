import sys

n, k = map(int, input().split())
cache = [0] * k

for _ in range(n):
    command = list(map(int, input().split()))
    core_id, cell_id = command[0], command[1]
    if cache[cell_id - 1] == 0:
        cache[cell_id - 1] = core_id
    else:
        print("Conflict")