import sys

n, k = map(int, input().split())

# Initialize a dictionary to store the number of times each toy appears
toys = {}
for i in range(1, n+1):
    toys[i] = 0

# Initialize a variable to store the number of pairs found
pairs = 0

# Loop through all possible pairs of toys
for i in range(1, n+1):
    for j in range(i+1, n+1):
        if i + j == k:
            # Increment the number of pairs found
            pairs += 1
            # Update the dictionary to store the number of times each toy appears
            toys[i] += 1
            toys[j] += 1

# Output the number of pairs found
print(pairs)