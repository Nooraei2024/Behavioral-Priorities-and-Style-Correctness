import sys

# Read input from stdin
input_string = sys.stdin.readline().strip()

# Split the input string into a list of integers
numbers = [int(x) for x in input_string.split()]

# Initialize the variables to zero
variables = [0] * m

# Loop through each number in the sequence and assign it to a variable
for i, num in enumerate(numbers):
    # Find the smallest variable that is not yet assigned
    min_var = None
    for j in range(m):
        if variables[j] == 0:
            min_var = j
            break
    
    # Assign the number to the smallest variable
    variables[min_var] = num

# Print the final values of the variables
print(*variables, sep='\n')