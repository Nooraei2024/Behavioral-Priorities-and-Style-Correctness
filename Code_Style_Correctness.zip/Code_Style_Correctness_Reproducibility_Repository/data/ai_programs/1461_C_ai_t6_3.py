import sys

n, m = map(int, input().split())
a = list(map(int, input().split()))

for _ in range(m):
    r_i, p_i = map(int, input().split())
    if r_i > n or p_i > n:
        print("Invalid input")
        continue
    if any(x >= p_i for x in a[1:r_i]):
        print("Invalid input")
        continue
    a = a[:r_i] + [p_i] + a[r_i:]

print(*a, sep=' ')