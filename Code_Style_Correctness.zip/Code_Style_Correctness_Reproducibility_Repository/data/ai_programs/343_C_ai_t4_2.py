import sys

# Read input from stdin
n = int(sys.stdin.readline())
hi = list(map(int, sys.stdin.readline().split()))

# Initialize output array
output = []

# Loop through each reading head and move it to the right track
for i in range(n):
    hi[i] += 1
    if hi[i] > n:
        hi[i] -= n
    output.append(hi[i])

# Print output array
print(*output, sep='\n')