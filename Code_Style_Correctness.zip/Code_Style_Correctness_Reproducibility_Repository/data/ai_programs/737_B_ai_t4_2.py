import sys

n = int(input())
k = int(input())

# Create a dictionary to keep track of the cells that have been hit
hit_cells = {}

# Read the input and update the dictionary with the hits
for _ in range(k):
    cell = int(input()) - 1
    if cell not in hit_cells:
        hit_cells[cell] = 0
    hit_cells[cell] += 1

# Check if any of the ships have been destroyed
for ship in range(n):
    if sum(hit_cells.get(i, 0) for i in range(ship * b, (ship + 1) * b)) == b:
        print("Destroyed")
        break
else:
    print("Safe")