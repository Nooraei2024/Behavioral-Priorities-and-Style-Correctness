import sys

# Read input from standard input
n, m = map(int, sys.stdin.readline().split())
boxes = list(map(int, sys.stdin.readline().split()))

# Initialize variables for the game
doll_box = 0
guess_count = 0

# Loop until Alice wins or runs out of guesses
while doll_box == 0 and guess_count < m:
    # Ask Alice to make a guess
    guess = int(sys.stdin.readline())
    
    # Check if the guess is correct
    if guess in boxes:
        # If the guess is correct, set the doll's box to the guessed number
        doll_box = guess
    else:
        # If the guess is incorrect, remove the guess from the list of possible boxes
        boxes.remove(guess)
    
    # Increment the guess count
    guess_count += 1

# Print the result
if doll_box > 0:
    print("Alice wins!")
else:
    print("Marisa wins!")