import sys

n = int(input())
a = []
for i in range(n):
    subset = list(map(int, input().split()))
    mex = 0
    for j in subset:
        if j not in a:
            break
        else:
            mex += 1
    a.append(mex)
print(*a, sep='\n')