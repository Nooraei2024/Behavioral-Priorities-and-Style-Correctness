import sys

def recover_polygon(contamination):
    # Initialize a dictionary to store the contamination levels for each vertex
    contamination_dict = {}
    
    # Iterate over the contamination levels and update the dictionary
    for i in range(len(contamination)):
        x, y, level = contamination[i]
        if (x, y) not in contamination_dict:
            contamination_dict[(x, y)] = level
    
    # Find the vertex with the highest contamination level
    highest_level = 0
    highest_vertex = None
    for vertex in contamination_dict:
        if contamination_dict[vertex] > highest_level:
            highest_level = contamination_dict[vertex]
            highest_vertex = vertex
    
    # Return the coordinates of the highest contamination level vertex
    return highest_vertex

# Read input from standard input (stdin)
contamination = []
for line in sys.stdin:
    x, y, level = map(int, line.split())
    contamination.append((x, y, level))

# Call the recover_polygon function with the contamination levels as input
result = recover_polygon(contamination)

# Print the result to standard output (stdout)
print(result[0], result[1])