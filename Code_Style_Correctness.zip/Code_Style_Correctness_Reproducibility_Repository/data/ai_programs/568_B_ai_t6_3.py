def is_symmetric(relation):
    for pair in relation:
        if (pair[1], pair[0]) not in relation:
            return False
    return True

def is_transitive(relation):
    for pair1, pair2 in zip(relation, relation):
        if (pair1[1], pair2[0]) not in relation:
            return False
    return True

def check_equivalence_relation(A, relation):
    symmetric = is_symmetric(relation)
    transitive = is_transitive(relation)
    return symmetric and transitive

if __name__ == "__main__":
    A = input()  # set of elements
    relation = []  # binary relation on the set
    for _ in range(len(A)):
        pair = input().split(",")  # read a pair from stdin
        relation.append((pair[0], pair[1]))  # add the pair to the relation
    print(check_equivalence_relation(A, relation))  # output the result of the check