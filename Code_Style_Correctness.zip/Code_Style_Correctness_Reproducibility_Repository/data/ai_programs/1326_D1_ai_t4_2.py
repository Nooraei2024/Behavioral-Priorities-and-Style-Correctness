import sys

s = input()

# Find the longest palindrome in s
max_len = 0
for i in range(len(s)):
    for j in range(i+1, len(s)+1):
        substr = s[i:j]
        if substr == substr[::-1] and len(substr) > max_len:
            max_len = len(substr)
            t = substr

# Find the two strings a and b that make up t
a = ""
b = ""
for i in range(len(t)):
    if i % 2 == 0:
        a += t[i]
    else:
        b += t[i]

print(a + b)