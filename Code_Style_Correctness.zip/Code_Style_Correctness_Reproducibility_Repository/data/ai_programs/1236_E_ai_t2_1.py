import sys

# Read input from stdin
n, m = map(int, sys.stdin.readline().split())
boxes = list(map(int, sys.stdin.readline().split()))

# Initialize variables
doll_location = 0
correct_guesses = 0

# Loop through each guess
for i in range(m):
    # Read the current guess from stdin
    guess = int(sys.stdin.readline())
    
    # Check if the guess is correct
    if guess == doll_location:
        # Increment the number of correct guesses
        correct_guesses += 1
        
        # If the guess is correct, update the location of the doll
        doll_location = (doll_location + 1) % n
    
    # Print the current state of the game
    print(f"Game {i+1}: Doll is in box {doll_location}")

# Check if Alice won the game
if correct_guesses == m:
    print("Alice wins!")
else:
    print("Marisa wins.")