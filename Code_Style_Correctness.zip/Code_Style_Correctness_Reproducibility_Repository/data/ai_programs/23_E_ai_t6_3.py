n = int(input())
tree = []
for i in range(n):
    tree.append([])
for i in range(n-1):
    u, v = map(int, input().split())
    tree[u].append(v)
    tree[v].append(u)

def dfs(node, visited, low, parent):
    visited.add(node)
    low[node] = min(low[node], len(visited))
    for neighbor in tree[node]:
        if neighbor != parent:
            if neighbor not in visited:
                dfs(neighbor, visited, low, node)
            else:
                low[node] = min(low[node], low[neighbor])

visited = set()
low = [0] * n
for i in range(n):
    if i not in visited:
        dfs(i, visited, low, -1)

result = 1
for i in range(n):
    if len(visited & tree[i]) == 1 and low[i] == 1:
        result *= len(tree[i])

print(result)