import sys

# Read input from standard input (stdin)
x1, y1, z1 = map(int, input().split())

# Calculate the opposite vertex of the box
x2, y2, z2 = 0, 0, 0

# Calculate the length of each side of the box
a1 = abs(x1 - x2)
a2 = abs(y1 - y2)
a3 = abs(z1 - z2)

# Check if all sides have the same length
if a1 == a2 and a2 == a3:
    print("YES")
else:
    print("NO")