import sys

n = int(input())
colors = list(map(int, input().split()))

# Initialize the color of the first square as 1
color = 1

# Iterate through each jar and paint the squares one by one
for i in range(1, n+1):
    # If the current jar contains a different color than the previous one
    if colors[i] != color:
        # Update the color of the current square to be the same as the previous one
        color = colors[i]
        print("paint", color, "at", i)