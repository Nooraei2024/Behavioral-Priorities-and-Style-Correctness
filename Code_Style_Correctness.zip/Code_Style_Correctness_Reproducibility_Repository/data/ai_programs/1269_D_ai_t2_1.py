import sys

def solve(a):
    n = len(a)
    dp = [[0] * (n + 1) for _ in range(n + 1)]
    for i in range(n):
        for j in range(i, n + 1):
            if a[i - 1] > a[j - 1]:
                dp[i][j] = max(dp[i][j], dp[i - 1][j - 1] + 1)
    return sum(dp[n][i] for i in range(n + 1))

if __name__ == "__main__":
    a = list(map(int, sys.stdin.readline().split()))
    print(solve(a))