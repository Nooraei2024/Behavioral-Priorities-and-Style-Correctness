import sys

n = int(input())
graph = {}
for i in range(1, n+1):
    graph[i] = []

# Add edges between prime numbers
for i in range(2, n+1):
    for j in range(i*2, n+1, i):
        if is_prime(j):
            graph[i].append(j)

def is_prime(n):
    if n == 1 or n == 0:
        return False
    for i in range(2, int(n**0.5)+1):
        if n % i == 0:
            return False
    return True

print(graph)