import sys

def solve(n):
    ans = 0
    for i in range(1, n+1):
        x = 1
        while x % i == 0:
            x += 1
        ans += x
    return (ans % (10**9 + 7))

if __name__ == "__main__":
    t = int(input())
    for _ in range(t):
        n = int(input())
        print(solve(n))