import sys

n = int(input())
arr = list(map(int, input().split()))
m = int(input())

subarrays = []
for i in range(m):
    li, ri = map(int, input().split())
    subarrays.append([a for a in arr[li:ri+1]])

mexes = [min(subarray) for subarray in subarrays]
print(min(mexes))