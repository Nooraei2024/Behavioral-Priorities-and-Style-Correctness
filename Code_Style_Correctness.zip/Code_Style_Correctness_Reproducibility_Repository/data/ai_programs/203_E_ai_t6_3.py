import sys

# Read input from standard input (stdin)
n = int(input())
robots = []
for i in range(n):
    robots.append([int(x) for x in input().split()])

# Calculate the number of robots that can be transported by each robot
transportable_robots = [[0] * n for _ in range(n)]
for i in range(n):
    for j in range(i, n):
        if robots[i][1] + robots[j][1] <= robots[i][0]:
            transportable_robots[i][j] = 1

# Find the shortest path from Valera to the luggage compartment
shortest_path = []
for i in range(n):
    if transportable_robots[i][-1] == 1:
        shortest_path.append(i)

print(*shortest_path, sep=" ")