import sys

n = int(input())
b = list(map(int, input().split()))

# Check if b is an OmkArray of some array a
is_omkar_array = True
for i in range(1, n//2+1):
    # Calculate the median of a_1, a_2, ..., a_{2i-1}
    median = sorted(b[:i*2])[i-1]
    # Check if b_i is equal to the median
    if b[i] != median:
        is_omkar_array = False
        break

print("YES" if is_omkar_array else "NO")