import sys

n = int(input())
a = list(map(int, input().split()))

# Calculate the maximum number of non-overlapping dominos that can be drawn
max_dominos = 0
for i in range(len(a)):
    for j in range(i+1, len(a)):
        if a[i] >= 2 and a[j] >= 1:
            max_dominos += 1

print(max_dominos)