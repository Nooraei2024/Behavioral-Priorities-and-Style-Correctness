import sys

def solve(road):
    # Convert the binary string to a list of intervals
    intervals = []
    for i in range(len(road)):
        if road[i] == '1':
            intervals.append((i, i + 1))

    # Sort the intervals by their start point
    sorted_intervals = sorted(intervals, key=lambda x: x[0])

    # Find the maximum length of a contiguous subarray of intervals that do not overlap
    max_length = 0
    for i in range(len(sorted_intervals)):
        start = sorted_intervals[i][0]
        end = sorted_intervals[i][1]
        for j in range(i + 1, len(sorted_intervals)):
            if start <= sorted_intervals[j][0] and end >= sorted_intervals[j][1]:
                break
        else:
            max_length = max(max_length, end - start)

    return max_length

# Test case 1:
road = "1010"
print(solve(road))

# Test case 2:
road = "101010"
print(solve(road))