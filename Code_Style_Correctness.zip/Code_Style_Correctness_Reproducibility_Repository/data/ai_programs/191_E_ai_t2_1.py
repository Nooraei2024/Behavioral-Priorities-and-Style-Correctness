import sys

n, k = map(int, input().split())
soldiers = list(map(int, input().split()))

# Sort the soldiers by their number in descending order
soldiers.sort(reverse=True)

# Initialize the schedule with the largest soldier first
schedule = [soldiers[0]]

# Iterate over the remaining soldiers and add them to the schedule if they are not already present
for i in range(1, len(soldiers)):
    if soldiers[i] not in schedule:
        schedule.append(soldiers[i])

# Print the final schedule
print(*schedule, sep='\n')