import sys

# Read input from stdin
A, B = map(int, sys.stdin.readline().split())

# Calculate the distance between A and B using the Manhattan distance formula
distance = abs(A[0] - B[0]) + abs(A[1] - B[1])

# Check if the points are on the avenue
if A[0] * B[1] + B[0] * A[1] == 0:
    # If they are, then the distance is reduced by half
    distance //= 2

print(distance)