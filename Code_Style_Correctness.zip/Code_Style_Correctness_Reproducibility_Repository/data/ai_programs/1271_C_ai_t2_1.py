import sys

s_x, s_y = map(int, input().split())
n = int(input())
x_i, y_i = [], []
for _ in range(n):
    x, y = map(int, input().split())
    x_i.append(x)
    y_i.append(y)

# Calculate the distance between each pair of houses and the main school
distances = [[(abs(s_x - x) + abs(s_y - y)) for x in range(100)] for y in range(100)]

# Find the closest house to the main school for each student
closest_house = [None] * n
for i in range(n):
    min_dist = float('inf')
    for j in range(n):
        if x_i[j] == x_i[i] and y_i[j] == y_i[i]:
            continue
        dist = distances[x_i[i]][y_i[j]] + distances[x_i[j]][y_i[i]]
        if dist < min_dist:
            min_dist = dist
            closest_house[i] = j

# Print the closest house for each student
for i in range(n):
    print(closest_house[i] + 1)