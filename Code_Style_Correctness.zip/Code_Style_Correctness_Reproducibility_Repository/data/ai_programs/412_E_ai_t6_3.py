import re

def recover_emails(string):
    """
    Recovers email addresses from a string.
    
    Args:
        string (str): The input string containing email addresses.
        
    Returns:
        list[str]: A list of email addresses recovered from the input string.
    """
    emails = []
    pattern = r"[\w\.-]+@r1\.com"
    for match in re.finditer(pattern, string):
        emails.append(match.group())
    return emails