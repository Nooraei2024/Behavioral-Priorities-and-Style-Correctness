import sys

def solve(points):
    # Sort the points by their x-coordinates
    sorted_points = sorted(points, key=lambda p: p[0])

    # Initialize the minimum number of segments to 1
    min_segments = 1

    # Iterate through the sorted points
    for i in range(len(sorted_points)):
        # Get the current point and its x-coordinate
        curr_point = sorted_points[i]
        curr_x = curr_point[0]

        # Check if there are any points to the left of the current point
        for j in range(i):
            # Get the previous point and its x-coordinate
            prev_point = sorted_points[j]
            prev_x = prev_point[0]

            # If the previous point is to the left of the current point,
            # then we need to add a segment from the previous point to the current point
            if prev_x < curr_x:
                min_segments += 1

    return min_segments

# Read input from standard input (stdin)
points = []
for _ in range(3):
    points.append(list(map(int, sys.stdin.readline().split())))

# Call the solve function and print the result to standard output (stdout)
print(solve(points))