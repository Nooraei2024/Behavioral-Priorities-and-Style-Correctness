import sys

n = int(input())
b = list(map(int, input().split()))

# Calculate the median of each subarray
medians = []
for i in range(1, n + 1):
    medians.append(sorted(b[i * (i - 1) // 2:i * (i + 1) // 2])[i // 2])

# Check if b is an OmkArray of some array a
if len(medians) == n and all(medians[i] == medians[0] for i in range(n)):
    print("Yes")
else:
    print("No")