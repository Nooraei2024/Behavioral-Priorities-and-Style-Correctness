import sys

def solve(n, boxes):
    # Initialize a list to store the maximum number of boxes that can be placed on each box
    max_boxes = [0] * n
    
    # Loop through each box and calculate the maximum number of boxes that can be placed on it
    for i in range(n):
        # Get the strength of the current box
        strength = boxes[i]
        
        # Initialize a variable to store the maximum number of boxes that can be placed on the current box
        max_boxes[i] = 1
        
        # Loop through each box that has a higher strength than the current box
        for j in range(n):
            if boxes[j] > strength:
                # Update the maximum number of boxes that can be placed on the current box
                max_boxes[i] = max(max_boxes[i], max_boxes[j] + 1)
    
    # Return the maximum number of boxes that can be placed on each box
    return max_boxes

# Read input from standard input (stdin)
n = int(sys.stdin.readline())
boxes = []
for _ in range(n):
    boxes.append(int(sys.stdin.readline()))

# Call the solve function and output the result to standard output (stdout)
print(*solve(n, boxes), sep='\n')