import sys

n = int(input())
houses = []
for _ in range(n):
    houses.append(tuple(map(int, input().split())))

# calculate the distance between each house and the exhibition point
distances = [(abs(x - 0) + abs(y - 0)) for x, y in houses]

# find the minimum distance
min_distance = min(distances)

# count the number of places with the minimum distance
count = distances.count(min_distance)

print(count)