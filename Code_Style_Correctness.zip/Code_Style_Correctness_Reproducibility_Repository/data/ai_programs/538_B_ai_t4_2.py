import sys

def quasi_binary(n):
    # Calculate the number of digits in n
    num_digits = len(str(n))

    # Initialize variables to keep track of the minimum number of quasibinary numbers and their sum
    min_num_quasi_bin = sys.maxsize
    sum_quasi_bin = 0

    for i in range(1, num_digits + 1):
        # Calculate the current digit of n
        digit = int(str(n)[:i])

        # Check if the current digit is quasibinary
        if (digit == 0 or digit == 1) and str(digit).isdigit():
            # If the current digit is quasibinary, add it to the sum and update the minimum number of quasibinary numbers
            sum_quasi_bin += digit
            min_num_quasi_bin = min(min_num_quasi_bin, i)

    return min_num_quasi_bin

# Read input from standard input (stdin)
n = int(input())

# Print the minimum number of quasibinary numbers and their sum
print(quasi_binary(n))