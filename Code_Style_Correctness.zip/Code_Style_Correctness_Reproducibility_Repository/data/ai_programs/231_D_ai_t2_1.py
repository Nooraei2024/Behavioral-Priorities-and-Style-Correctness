import sys

# Read input from stdin
input_str = sys.stdin.readline().strip()

# Split the input string into a list of integers
numbers = [int(x) for x in input_str.split(',')]

# Calculate the sum of all the numbers on the box
sum = 0
for num in numbers:
    sum += num

# Print the result
print(sum)