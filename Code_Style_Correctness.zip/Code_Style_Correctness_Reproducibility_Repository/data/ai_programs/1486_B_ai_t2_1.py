import sys

def solve(n):
    houses = []
    for _ in range(n):
        houses.append(tuple(map(int, input().split())))

    exhibition = tuple(map(int, input().split()))

    distances = [abs(exhibition[0] - house[0]) + abs(exhibition[1] - house[1]) for house in houses]

    return min(distances)

if __name__ == "__main__":
    n = int(input())
    print(solve(n))