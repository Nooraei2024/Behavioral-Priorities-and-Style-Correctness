import sys

# Read input from stdin
n, m = map(int, input().split())
factory_data = []
for _ in range(n):
    factory_data.append([int(x) for x in input().split()])

# Convert each number to its binary form
binary_data = [[bin(x)[2:] for x in row] for row in factory_data]

# Print the result
print(*binary_data, sep='\n')