import sys

w = int(sys.stdin.readline())
m = int(sys.stdin.readline())

def get_sequence_length(n):
    length = 0
    while n > 0:
        length += 1
        n //= 10
    return length

def get_cost(n, k):
    cost = 0
    for i in range(get_sequence_length(n)):
        cost += S(n) * k
    return cost

max_length = 0
for i in range(m, m + w + 1):
    if get_cost(i, k) <= w:
        max_length = max(max_length, get_sequence_length(i))

print(max_length)