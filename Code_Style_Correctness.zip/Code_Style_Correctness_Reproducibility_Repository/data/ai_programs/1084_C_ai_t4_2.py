import sys

s = input()
k = len(s)
count = 0
for i in range(k):
    if s[i] == 'a':
        count += 1
        j = i + 1
        while j < k and s[j] != 'b':
            j += 1
        if j < k:
            count -= 1
print(count % (10**9 + 7))