import sys

def find_complete_parts(game, computers):
    # Initialize a set to store the completed parts
    completed_parts = set()
    
    # Loop through each computer
    for computer in computers:
        # Get the parts that can be completed on this computer
        possible_parts = game[computer]
        
        # Loop through each part that can be completed on this computer
        for part in possible_parts:
            # If the part has not been completed yet, mark it as complete and add it to the set
            if part not in completed_parts:
                completed_parts.add(part)
    
    return completed_parts

# Read game from standard input
game = {}
for line in sys.stdin:
    parts = line.split()
    computer = int(parts[0])
    part = int(parts[1])
    if computer not in game:
        game[computer] = set()
    game[computer].add(part)
    
# Find the complete parts
complete_parts = find_complete_parts(game, computers)

# Print the complete parts
for part in complete_parts:
    print(part)