import sys

n, k = map(int, input().split())
cores = []
for _ in range(n):
    cores.append([0] * k)

while True:
    line = input()
    if line == '':
        break
    
    core_id, cell_id = map(int, line.split())
    cores[core_id][cell_id] += 1

for core in cores:
    for cell in core:
        print(cell, end=' ')
    print()