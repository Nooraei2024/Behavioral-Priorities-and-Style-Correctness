import sys

def is_isomorphic(tree1, tree2):
    if len(tree1) != len(tree2):
        return False
    
    seen = set()
    queue = [(tree1[0], tree2[0])]
    
    while queue:
        vertex1, vertex2 = queue.pop()
        
        if vertex1 not in seen:
            seen.add(vertex1)
            
            for neighbor1 in tree1[vertex1]:
                neighbor2 = tree2.index(neighbor1)
                
                if neighbor2 not in seen:
                    queue.append((neighbor1, neighbor2))
                    
                    if len(queue) != len(tree1):
                        return False
    
    return True

def solve():
    tree1 = []
    tree2 = []
    
    for _ in range(int(input())):
        vertex, neighbors = input().split()
        tree1.append([vertex] + [neighbor for neighbor in neighbors.split(',') if neighbor])
        tree2.append([vertex] + [neighbor for neighbor in neighbors.split(',') if neighbor])
    
    return is_isomorphic(tree1, tree2)

print(solve())