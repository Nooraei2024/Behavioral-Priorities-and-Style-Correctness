import sys

def find_beautiful_array(a):
    n = len(a)
    b = []
    for i in range(n):
        if a[i] % 2 == 0:
            b.append(a[i] // 2)
        else:
            b.append(3 * a[i] + 1)
    return b

if __name__ == "__main__":
    input = sys.stdin.readline().strip()
    a = list(map(int, input.split()))
    b = find_beautiful_array(a)
    print(*b, sep=" ")