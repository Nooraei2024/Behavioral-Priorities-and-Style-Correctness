import sys

def recover_polygon():
    n = int(input())
    points = []
    for _ in range(n):
        x, y = map(int, input().split())
        points.append((x, y))
    return points

if __name__ == "__main__":
    sys.stdout.write(str(recover_polygon()))