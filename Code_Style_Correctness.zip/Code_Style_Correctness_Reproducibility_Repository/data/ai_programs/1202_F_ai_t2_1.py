import sys

a, b = map(int, input().split())

def get_period(s):
    # Find the smallest positive integer k such that s[i] == s[(i+k)%|s|] for all i
    for k in range(1, len(s)):
        if all(s[i] == s[(i+k)%len(s)] for i in range(len(s))):
            return k
    return 0

def count_periods(a, b):
    # Count the number of different periods over all possible strings with a letters 'A' and b letters 'B'
    num_strings = 1 << (a + b)
    periods = set()
    for i in range(num_strings):
        s = ""
        for j in range(a):
            if i & (1 << j):
                s += "A"
            else:
                s += "B"
        for k in range(b):
            if i & (1 << (j + a + k)):
                s += "A"
            else:
                s += "B"
        periods.add(get_period(s))
    return len(periods)

print(count_periods(a, b))