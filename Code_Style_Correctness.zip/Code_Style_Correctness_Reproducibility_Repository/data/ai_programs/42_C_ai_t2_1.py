import sys

def solve(p):
    p = list(map(int, p))
    while True:
        if all(x == 1 for x in p):
            break
        for i in range(len(p) - 1):
            if p[i] % 2 == 0 and p[i + 1] % 2 == 0:
                p[i] //= 2
                p[i + 1] //= 2
            elif p[i] < p[i + 1]:
                p[i] += 1
                p[i + 1] += 1
    return "".join(map(str, p))

if __name__ == "__main__":
    input_data = sys.stdin.readline().strip()
    print(solve(input_data))