import sys

# Read input from stdin
code = sys.stdin.readline().strip()

# Check if the code is valid
if len(code) == 4 and all(c in '0123456789' for c in code):
    # If the code is valid, print it to stdout
    print(f"The cancel code is {code}")
else:
    # If the code is not valid, print an error message to stdout
    print("Invalid cancel code")