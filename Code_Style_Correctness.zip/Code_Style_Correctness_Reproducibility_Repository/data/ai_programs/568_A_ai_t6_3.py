while True:
    try:
        n = int(input())
    except EOFError:
        break
    if is_prime(n):
        print("Prime")
    else:
        print("Palindromic")

def is_prime(n):
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True