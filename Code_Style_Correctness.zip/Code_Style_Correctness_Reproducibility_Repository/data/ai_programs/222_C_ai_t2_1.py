import sys

# Read input from stdin
line = sys.stdin.readline().strip()

# Split the line into two sets of integers
nums1, nums2 = line.split(' ')

# Calculate the numerator and denominator
numerator = int(nums1[0]) * int(nums1[1])
denominator = int(nums2[0]) * int(nums2[1])

# Reduce the fraction if necessary
if numerator % denominator == 0:
    print(f"{numerator // denominator}")
else:
    print(f"{numerator} / {denominator}")