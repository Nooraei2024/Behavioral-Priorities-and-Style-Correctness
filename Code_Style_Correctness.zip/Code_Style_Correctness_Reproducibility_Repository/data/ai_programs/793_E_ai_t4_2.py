import sys

# Read input from standard input (stdin)
n = int(input())
departments = list(map(int, input().split()))

# Initialize variables
total_cash = 0
route = []

# Iterate through the departments and calculate the total cash collected
for i in range(n):
    total_cash += departments[i]
    route.append(departments[i])

# Print the total cash collected and the route taken by the collectors
print(total_cash)
print(*route, sep=' ')