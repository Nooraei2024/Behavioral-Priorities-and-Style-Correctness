import sys

def recover_polygon(contamination):
    """
    Recovers the polygon from the given contamination levels.

    Args:
        contamination (list[int]): The contamination levels for each cell of the lattice.

    Returns:
        tuple[int]: The coordinates of the vertices of the polygon.
    """
    # Initialize a dictionary to store the coordinates of the vertices
    vertices = {}

    # Iterate over the contamination levels and find the highest level
    highest_level = max(contamination)

    # Iterate over the contamination levels again and find the cells with the highest level
    for i, level in enumerate(contamination):
        if level == highest_level:
            vertices[i] = True

    # Find the number of vertices
    num_vertices = len(vertices)

    # Initialize a list to store the coordinates of the vertices
    vertex_coords = []

    # Iterate over the vertices and add them to the list
    for i in range(num_vertices):
        if vertices[i]:
            vertex_coords.append(i)

    return tuple(vertex_coords)

if __name__ == "__main__":
    # Read the contamination levels from standard input
    contamination = [int(x) for x in sys.stdin.readline().split()]

    # Recover the polygon and print its coordinates
    vertices = recover