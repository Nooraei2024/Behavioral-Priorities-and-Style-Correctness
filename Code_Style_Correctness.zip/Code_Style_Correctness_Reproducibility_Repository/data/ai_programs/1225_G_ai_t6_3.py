import sys

def f(x):
    return x if x % k == 0 else x // k

n = int(input())
k = int(input())

numbers = list(map(int, input().split()))

for i in range(n - 1):
    x, y = numbers[i], numbers[i + 1]
    numbers[i] = f(x + y)

print(f(sum(numbers)))