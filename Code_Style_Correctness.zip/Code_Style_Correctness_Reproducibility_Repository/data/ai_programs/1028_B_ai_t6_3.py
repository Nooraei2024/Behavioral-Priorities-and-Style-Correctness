import sys

def solve(n, m):
    a = 0
    b = 1
    while s(a) < n:
        a += 1
    while s(b) < n:
        b += 1
    while s(a + b) > m:
        b -= 1
    return [a, b]

def s(x):
    return sum([int(i) for i in str(x)])

n, m = map(int, sys.stdin.readline().split())
print(*solve(n, m), sep='\n')