import sys

# Read input from stdin
n = int(input())

# Initialize variables
count = 0
total_water = 0

# Loop through each line of input
for _ in range(n):
    # Read the next line of input and convert it to an integer
    water = int(sys.stdin.readline().strip())
    
    # Increment the count if the water is positive
    if water > 0:
        count += 1
    
    # Add the water to the total_water variable
    total_water += water

# Print the result
print(count, total_water)