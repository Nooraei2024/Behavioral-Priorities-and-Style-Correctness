import sys

# Read input from stdin
n = int(input())
board = []
for _ in range(n):
    board.append([int(x) for x in input().split()])

# Calculate the total weight of each row and column
row_weights = [sum(r) for r in board]
col_weights = [sum(c) for c in zip(*board)]

# Find the heaviest row and column
heaviest_row = max(range(n), key=lambda i: row_weights[i])
heaviest_col = max(range(n), key=lambda j: col_weights[j])

# Print the winner
print("A" if heaviest_row == heaviest_col else "B")