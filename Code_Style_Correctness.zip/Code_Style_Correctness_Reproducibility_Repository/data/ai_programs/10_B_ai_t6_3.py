import sys

# Read input from standard input (stdin)
n = int(sys.stdin.readline())

# Initialize an empty matrix to store the seats
seats = [[0 for _ in range(K)] for _ in range(K)]

# Loop through each row and seat, marking them as occupied
for i in range(1, K + 1):
    for j in range(1, K + 1):
        seats[i - 1][j - 1] = 1

# Output the seats matrix
print(*seats)