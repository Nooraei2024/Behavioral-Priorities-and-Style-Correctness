import sys

# Read input from stdin
n = int(input())
colors = list(map(str, sys.stdin.readline().split()))

# Initialize a dictionary to store the number of each color
color_count = {}
for color in colors:
    if color not in color_count:
        color_count[color] = 1
    else:
        color_count[color] += 1

# Find the most common color and the second most common color
most_common = max(color_count, key=color_count.get)
second_most_common = sorted(color_count, key=color_count.get, reverse=True)[1]

# If the most common color is not equal to the second most common color, recolor some puppies
if most_common != second_most_common:
    # Find the number of puppies that need to be recolored
    num_puppies = n - color_count[most_common]

    # Recolor the puppies
    for i in range(num_puppies):
        colors[i] = second_most_common

# Print the new colors of the puppies
print(*colors, sep='\n')