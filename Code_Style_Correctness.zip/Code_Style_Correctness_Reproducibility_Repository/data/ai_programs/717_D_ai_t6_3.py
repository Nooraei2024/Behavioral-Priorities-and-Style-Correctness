import sys

# Read input from stdin
n = int(input())

# Initialize variables
score1 = 0
score2 = 0

# Loop through each turn
for i in range(n):
    # Get the current state of the game
    state = list(map(int, input().split()))

    # Check if Dexterina is the first player
    if state[0] == 1:
        # Update the score for Dexterina
        score1 += 1
    else:
        # Update the score for Womandark
        score2 += 1

# Output the final scores
print(score1, score2)