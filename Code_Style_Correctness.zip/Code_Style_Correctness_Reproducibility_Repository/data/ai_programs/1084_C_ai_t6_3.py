import sys

s = input()
k = len(s)

count = 0
for i in range(1, k):
    if s[i] == 'a':
        count += 1
    else:
        j = i - 1
        while j >= 0 and s[j] != 'b':
            j -= 1
        if j >= 0:
            count += 1

print(count % (10**9 + 7))