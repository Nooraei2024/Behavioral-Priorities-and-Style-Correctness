import sys

n = int(input())

IQ = 0
points = 0
problems = {}
for i in range(1, n+1):
    c_i, tag_i, s_i = map(int, input().split())
    problems[i] = (c_i, tag_i, s_i)

while IQ < 2**n:
    min_diff = float('inf')
    for i in range(1, n+1):
        c_i, tag_i, s_i = problems[i]
        if IQ < c_i and tag_i != '':
            diff = abs(c_i - IQ)
            if diff < min_diff:
                min_diff = diff
                best_problem = i
    if min_diff == float('inf'):
        break
    else:
        c_best, tag_best, s_best = problems[best_problem]
        IQ = c_best - IQ
        points += s_best - s_i
        del problems[best_problem]

print(points)