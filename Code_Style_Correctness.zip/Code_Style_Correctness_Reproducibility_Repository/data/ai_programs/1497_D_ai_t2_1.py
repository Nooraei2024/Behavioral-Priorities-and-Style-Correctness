import sys

n = int(input())
IQ = 0
scores = []
tags = []
for i in range(1, n+1):
    c_i, tag_i, s_i = map(int, input().split())
    scores.append(s_i)
    tags.append(tag_i)

while IQ < 2**n:
    best_score = -1
    best_problem = -1
    for i in range(1, n+1):
        if IQ < 2**i and (IQ + 1) % 2 == 0:
            continue
        if scores[i] > best_score or (scores[i] == best_score and tags[i] != tags[best_problem]):
            best_score = scores[i]
            best_problem = i
    IQ += 1
    print(f"Solving problem {best_problem}")
    print(f"IQ: {IQ}")
    print(f"Score: {scores[best_problem]}")
    print(f"Tag: {tags[best_problem]}")