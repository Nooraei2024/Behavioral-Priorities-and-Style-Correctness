import sys

def solve(n):
    # Initialize the state of each conveyor belt as clockwise
    belts = [True] * n

    # Read the input from standard input (stdin)
    for _ in range(n):
        room, direction = map(int, sys.stdin.readline().split())

        # Update the state of the conveyor belt
        if direction == 1:
            belts[room] = True
        else:
            belts[room] = False

    # Find the first room that is connected to a clockwise conveyor belt
    for i in range(n):
        if belts[i]:
            return i

    # If no room is connected to a clockwise conveyor belt, return -1
    return -1

# Read the number of rooms from standard input (stdin)
n = int(sys.stdin.readline())

# Call the solve function with the number of rooms as an argument
print(solve(n))