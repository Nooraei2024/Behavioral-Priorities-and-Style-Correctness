import sys

n = int(input())
a = list(map(int, input().split()))

for i in range(n):
    d1 = 2
    while True:
        if (d1 + 1) % a[i] == 0:
            break
        d1 += 1
    d2 = a[i] // (d1 + 1)
    print(d1, d2)