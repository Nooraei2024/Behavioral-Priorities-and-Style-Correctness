import sys

def solve(a):
    steps = 0
    while a != '':
        i = a.find('_')
        if i == -1:
            break
        a = a[:i] + a[i+1:]
        steps += 1
    return steps

if __name__ == '__main__':
    input_string = sys.stdin.readline().strip()
    print(solve(input_string))