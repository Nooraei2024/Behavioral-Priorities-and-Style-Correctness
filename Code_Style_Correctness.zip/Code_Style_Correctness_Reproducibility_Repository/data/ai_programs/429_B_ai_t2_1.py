import sys

n, m = map(int, input().split())
a = []
for _ in range(n):
    a.append(list(map(int, input().split())))

# Initialize variables for Iahub and Iahubina
i = 1
j = 1
calories_burned = 0

# Loop through the gym matrix
while i <= n and j <= m:
    # Calculate the calories burned by performing workout at current cell
    calories_burned += a[i][j]
    
    # Move to next cell in the gym matrix
    if i < n and j < m:
        i += 1
        j += 1
    elif i == n and j < m:
        j += 1
    elif i < n and j == m:
        i += 1
    
# Print the total calories burned by Iahub and Iahubina
print(calories_burned)