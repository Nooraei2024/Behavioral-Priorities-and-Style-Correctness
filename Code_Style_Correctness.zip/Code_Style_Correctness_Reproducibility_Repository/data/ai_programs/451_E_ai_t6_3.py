import sys

n = int(input())
s = int(input())
boxes = []
for _ in range(n):
    boxes.append([int(x) for x in input().split()])

colors = set()
flowers = 0
for box in boxes:
    flowers += len(box)
    colors.update(box)

if flowers < s:
    print(0)
else:
    num_ways = 1
    for color in colors:
        count = sum(len(box) for box in boxes if color in box)
        if count >= s:
            num_ways *= count // s
    print(num_ways)