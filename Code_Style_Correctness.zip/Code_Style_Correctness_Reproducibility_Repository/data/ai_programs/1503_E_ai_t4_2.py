import sys

n, m = map(int, input().split())
grid = []
for _ in range(n):
    grid.append([])
    for j in range(m):
        grid[i].append(input())

# Check if the grid is stupid
is_stupid = True
for i in range(n):
    blue_count = 0
    yellow_count = 0
    for j in range(m):
        if grid[i][j] == 'B':
            blue_count += 1
        elif grid[i][j] == 'Y':
            yellow_count += 1
        else:
            is_stupid = False
            break
    if not is_stupid:
        break

if is_stupid:
    print("YES")
else:
    print("NO")