import sys

# Read input from stdin
n = int(input())
a = list(map(int, input().split()))

# Initialize the graph with n rooms and n - 1 tunnels
graph = [[0 for _ in range(n)] for _ in range(n)]
for i in range(n):
    for j in range(i + 1, n):
        graph[i][j] = max(a[i] + a[j], graph[i][j - 1])

# Find the shortest path from room 1 to room n
path = [1]
for i in range(n - 1):
    path.append(graph[path[-1]][path[-2]])

print(*path, sep='\n')