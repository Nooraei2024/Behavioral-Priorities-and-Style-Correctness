import sys

def is_palindrome(s):
    return s == s[::-1]

if __name__ == '__main__':
    input = sys.stdin.read()
    words = input.split()
    for word in words:
        if is_palindrome(word):
            print(f"{word} - True")
        else:
            print(f"{word} - False")