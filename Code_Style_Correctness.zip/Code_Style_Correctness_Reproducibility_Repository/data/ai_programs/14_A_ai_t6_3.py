import sys

# Read input from standard input
n, m = map(int, sys.stdin.readline().split())
shaded_squares = []
for _ in range(n * m):
    shaded_squares.append(sys.stdin.readline().strip() == '1')

# Calculate the minimum number of squares to send
min_squares = 0
for i in range(n):
    for j in range(m):
        if shaded_squares[i * m + j]:
            min_squares += 1
print(min_squares)