import sys

# Read input from stdin
n = int(input())
points = []
for i in range(n):
    x, y = map(int, input().split())
    points.append((x, y))

# Check if any key point is reachable from (0, 0)
reachable = False
for p in points:
    if p == (0, 0):
        reachable = True
        break

# If no key point is reachable, output -1
if not reachable:
    print(-1)
else:
    # Find the minimum number of moves to reach a key point from (0, 0)
    min_moves = float('inf')
    for p in points:
        moves = abs(p[0]) + abs(p[1])
        if moves < min_moves:
            min_moves = moves
    
    # Output the minimum number of moves
    print(min_moves)