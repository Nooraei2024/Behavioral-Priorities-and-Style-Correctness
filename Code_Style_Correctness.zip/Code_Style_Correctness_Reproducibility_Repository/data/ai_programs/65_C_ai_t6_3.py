import sys

# Read input from standard input
input_string = sys.stdin.readline()

# Split the input string into a list of vertices
vertices = input_string.split(',')

# Initialize the position of the snitch at the starting point
x0, y0, z0 = int(vertices[0]), int(vertices[1]), int(vertices[2])

# Loop through each vertex and calculate the distance between the snitch and the vertex
distances = []
for i in range(3, len(vertices), 3):
    x1, y1, z1 = int(vertices[i]), int(vertices[i+1]), int(vertices[i+2])
    distances.append(abs(x0 - x1) + abs(y0 - y1) + abs(z0 - z1))

# Print the minimum distance as output
print(min(distances))