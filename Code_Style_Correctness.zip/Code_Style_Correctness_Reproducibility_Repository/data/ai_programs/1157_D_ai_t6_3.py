import sys

# Read input from stdin
n, k = map(int, sys.stdin.readline().split())

# Calculate the minimum number of problems to solve
min_problems = max(1, k // 2)

# Check if the minimum number of problems is greater than or equal to n
if min_problems >= n:
    print("YES")
else:
    print("NO")