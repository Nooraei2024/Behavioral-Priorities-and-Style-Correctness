import sys

# Read input from standard input
a, b, c, d = map(int, sys.stdin.readline().split())

# Calculate the area of the two rectangles
area1 = a * b
area2 = c * d

# Calculate the total area of the island
total_area = area1 + area2

# Calculate the number of parties that can be divided equally into the island
num_parties = int(total_area / (a + c))

# Print the result
print(num_parties)