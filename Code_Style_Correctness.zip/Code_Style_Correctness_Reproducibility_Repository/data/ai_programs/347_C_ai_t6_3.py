import sys

# Read input from stdin
n = int(sys.stdin.readline())
nums = list(map(int, sys.stdin.readline().split()))

# Initialize set of integers
set_ints = set(nums)

# Initialize Alice's turn
alice_turn = True

while len(set_ints) > 0:
    # Get the current player's turn
    if alice_turn:
        x, y = map(int, sys.stdin.readline().split())
        set_ints -= {abs(x - y)}
    else:
        x, y = map(int, sys.stdin.readline().split())
        set_ints -= {abs(y - x)}
    
    # Switch player's turn
    alice_turn = not alice_turn

# Output the final set of integers
print(*sorted(set_ints), sep='\n')