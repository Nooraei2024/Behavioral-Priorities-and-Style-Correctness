import sys

def array_k_coloring(a):
    n = len(a)
    k = max(a) + 1
    coloring = [[] for _ in range(k)]
    for i in range(n):
        color = a[i] - 1
        if coloring[color]:
            return "NO"
        else:
            coloring[color].append(i)
    for i in range(k):
        if len(coloring[i]) < n / k:
            return "NO"
    return "YES"

if __name__ == "__main__":
    input = sys.stdin.readline().strip()
    a = list(map(int, input.split()))
    print(array_k_coloring(a))