import sys

def get_good_substrings(s):
    good_substrings = []
    for i in range(len(s)):
        for j in range(i+1, len(s)+1):
            substring = s[i:j]
            if len(substring) == f(substring):
                good_substrings.append(substring)
    return good_substrings

def f(t):
    return int(t, 2)

if __name__ == '__main__':
    s = sys.stdin.readline().strip()
    good_substrings = get_good_substrings(s)
    print(*good_substrings, sep='\n')