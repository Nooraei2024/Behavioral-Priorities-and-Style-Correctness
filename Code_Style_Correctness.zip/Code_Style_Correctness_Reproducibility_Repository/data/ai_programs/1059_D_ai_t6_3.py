import math

# Read input from standard input (stdin)
n = int(input())
points = []
for i in range(n):
    x, y = map(int, input().split())
    points.append((x, y))

# Calculate the center of the circle
center_x = 0
center_y = 0
for point in points:
    center_x += point[0]
    center_y += point[1]
center_x /= n
center_y /= n

# Calculate the radius of the circle
radius = 0
for point in points:
    radius = max(radius, math.sqrt((point[0] - center_x) ** 2 + (point[1] - center_y) ** 2))

# Check if the circle intersects with the river
intersects = False
for point in points:
    if math.sqrt((point[0] - center_x) ** 2 + (point[1] - center_y) ** 2) <= radius:
        intersects = True
        break

# Output the result
print(intersects)