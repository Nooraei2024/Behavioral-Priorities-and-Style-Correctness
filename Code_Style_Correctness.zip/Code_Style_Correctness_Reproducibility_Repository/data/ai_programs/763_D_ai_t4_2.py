import sys

n = int(input())
tree = []
for _ in range(n):
    tree.append([int(x) for x in input().split()])

# Calculate the number of non-isomorphic subtrees
subtrees = 0
for i in range(n):
    for j in range(i+1, n):
        if len(set(tree[i]).intersection(set(tree[j]))) == 0:
            subtrees += 1

print(subtrees)