import sys

# Read input from stdin
n, m = map(int, sys.stdin.readline().split())
A = []
for _ in range(n):
    A.append(list(map(int, sys.stdin.readline().split())))

# Calculate the spectrum of the matrix A
X = [R[i] for i in range(n) for R in A]
Y = [C[j] for j in range(m) for C in zip(*A)]

# Output the spectrum as a tuple
print((X, Y))