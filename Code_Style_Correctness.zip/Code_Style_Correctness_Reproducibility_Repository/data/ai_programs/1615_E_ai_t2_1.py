import sys

n = int(input())
tree = [[] for _ in range(n + 1)]
for i in range(2 * n):
    node, parent = map(int, input().split())
    tree[parent].append(node)

red_turns = []
blue_turns = []

def dfs(node, color):
    if color == "R":
        red_turns.append(node)
    else:
        blue_turns.append(node)
    for child in tree[node]:
        dfs(child, color)

dfs(1, "R")
print(" ".join(map(str, red_turns)))
print(" ".join(map(str, blue_turns)))