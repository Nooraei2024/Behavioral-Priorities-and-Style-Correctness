import sys

n = int(input())
a = list(map(int, input().split()))
S = sum(a)

# Find a beautiful array by iteratively trying to find divisors for each element
b = []
for i in range(n):
    # Try to find a divisor for the current element
    for j in range(i+1, n):
        if a[j] % a[i] == 0 or a[i] % a[j] == 0:
            b.append(a[j])
            break
    else:
        # If no divisor is found, use the current element as is
        b.append(a[i])

# Check if the array satisfies the constraints
if not all(1 <= x <= 10**9 for x in b):
    print("No beautiful array exists")
else:
    print(*b)