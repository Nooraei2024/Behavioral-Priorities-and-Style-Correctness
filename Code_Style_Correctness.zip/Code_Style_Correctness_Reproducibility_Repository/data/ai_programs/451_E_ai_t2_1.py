import sys

n = int(input())
s = int(input())
boxes = []
for _ in range(n):
    boxes.append([int(x) for x in input().split()])

def count_ways(boxes, s):
    ways = 1
    for box in boxes:
        ways *= len(box) + 1
    return ways % (10**9 + 7)

print(count_ways(boxes, s))