import sys

q = int(input())
A = set()
for _ in range(q):
    query = input().strip()
    if query[0] == '+':
        A.add(int(query[1:]))
    elif query[0] == '-':
        A.remove(int(query[1:]))
    else:
        x = int(query[1:])
        print(max(A) if x in A else -1)