import sys

# Read input from stdin
n, q = map(int, sys.stdin.readline().split())
tree = []
for _ in range(n):
    tree.append(list(map(int, sys.stdin.readline().split())))
queries = []
for _ in range(q):
    queries.append(list(map(int, sys.stdin.readline().split())))

# Calculate centroid of each subtree
centroids = [0] * n
for i in range(n):
    for j in tree[i]:
        centroids[j - 1] += 1
for i in range(n):
    centroids[i] //= 2

# Print the output
for query in queries:
    print(centroids[query[0] - 1])