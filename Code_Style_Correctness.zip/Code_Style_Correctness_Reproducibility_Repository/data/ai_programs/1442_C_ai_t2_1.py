import sys

# Read input from stdin
n, m = map(int, sys.stdin.readline().split())
graph = {}
for _ in range(m):
    u, v = map(int, sys.stdin.readline().split())
    if u not in graph:
        graph[u] = []
    graph[u].append(v)

# Initialize token position
token_position = 1

# Perform actions
for _ in range(n):
    # Move token to next vertex
    token_position = graph[token_position][0] if token_position in graph else -1
    # Transpose graph
    for u, v in graph.items():
        graph[u], graph[v] = graph[v], graph[u]

# Output token position
print(token_position)