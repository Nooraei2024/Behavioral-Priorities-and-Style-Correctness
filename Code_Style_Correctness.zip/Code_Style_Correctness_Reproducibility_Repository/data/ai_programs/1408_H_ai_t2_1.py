import sys

def solve(n):
    # Initialize a dictionary to store the indices of the triplets
    triplets = {}

    # Loop through each element in the sequence
    for i in range(1, n+1):
        # Check if the current element is 0
        if a[i] == 0:
            # If it is, add its index to the dictionary
            triplets[(i-1)//3] = (i-1)%3 + 1

    # Initialize the maximum number of triples to 0
    max_triples = 0

    # Loop through each key in the dictionary
    for key in triplets:
        # If the current key is greater than the maximum number of triples, update it
        if key > max_triples:
            max_triples = key

    return max_triples + 1

# Read input from standard input (stdin)
t = int(sys.stdin.readline())

# Loop through each test case
for _ in range(t):
    # Read the length of the sequence
    n = int(sys.stdin.readline())

    # Initialize the sequence
    a = [0] * (n+1)

    # Read the elements of the sequence
    for i in range(1, n+1):
        a[i] = int(sys.stdin.readline())

    # Print the maximum number of triples
    print(solve(n))