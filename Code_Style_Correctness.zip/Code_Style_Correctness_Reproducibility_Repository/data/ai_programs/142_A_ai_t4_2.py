import sys

# Read input from stdin
input_string = sys.stdin.readline().strip()

# Split the input string into a list of integers using ',' as delimiter
input_list = [int(x) for x in input_string.split(',')]

# Calculate A and B
A = input_list[0] * input_list[1]
B = input_list[2] * input_list[3]

# Print the result
print(f"{A}·{B}")