import sys

# Read input from stdin
line = sys.stdin.readline()

# Split the input into two sets of integers
nums1, nums2 = line.split(' ')

# Calculate the fraction numerator and denominator
numerator = int(nums1[0]) * int(nums1[1])
denominator = int(nums2[0]) * int(nums2[1])

# Reduce the fraction if necessary
if numerator % denominator == 0:
    reduced_numerator = numerator // denominator
else:
    reduced_numerator = numerator

# Output the reduced fraction
print(f"{reduced_numerator}/{denominator}")