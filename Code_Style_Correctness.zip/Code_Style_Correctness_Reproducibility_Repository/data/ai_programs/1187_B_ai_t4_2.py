import sys

def solve(s):
    n = len(s)
    m = int(input())
    t = []
    for i in range(m):
        t_i = input()
        t.append(t_i)
    
    ans = []
    for i in range(m):
        name = t[i]
        min_len = n + 1
        for j in range(n):
            if s[:j+1] == name:
                min_len = min(min_len, j+1)
        ans.append(min_len)
    
    print(*ans, sep='\n')