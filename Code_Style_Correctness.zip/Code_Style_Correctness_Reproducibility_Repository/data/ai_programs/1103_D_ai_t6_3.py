import sys

# Read input from stdin
n = int(sys.stdin.readline().strip())
k = int(sys.stdin.readline().strip())
a = list(map(int, sys.stdin.readline().split()))
e = list(map(int, sys.stdin.readline().split()))

# Initialize variables
passed_judges = 0
failed_judges = 0

# Loop through each judge and determine if they have passed or failed the exam
for i in range(n):
    # Calculate the total uncertainty and experience for this judge
    total_uncertainty = sum([a[j] for j in range(i, n)])
    total_experience = sum([e[j] for j in range(i, n)])
    
    # Determine if the judge has passed or failed the exam
    if total_uncertainty * k > total_experience:
        passed_judges += 1
    else:
        failed_judges += 1

# Print the number of passed and failed judges
print(passed_judges)
print(failed_judges)