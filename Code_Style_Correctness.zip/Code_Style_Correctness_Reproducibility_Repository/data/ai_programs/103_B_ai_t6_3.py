import sys

# Read input from standard input
input_string = sys.stdin.readline().strip()

# Split the input string into a list of words
words = input_string.split(" ")

# Create a dictionary to store the frequency of each word
word_freq = {}

# Iterate over the list of words and increment the frequency count for each word
for word in words:
    if word not in word_freq:
        word_freq[word] = 1
    else:
        word_freq[word] += 1

# Sort the dictionary by value (frequency) and print the top 5 most frequent words
sorted_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)[:5]
for word, freq in sorted_words:
    print(word, end=" ")