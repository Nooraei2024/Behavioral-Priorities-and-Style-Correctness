import sys

# Read input from stdin
n = int(input())
a = list(map(int, input().split()))
m = int(input())
b = list(map(int, input().split()))

# Calculate the total memory usage of all applications
total_memory = sum(a)

# Initialize a dictionary to store the number of important applications
important_apps = {}

# Loop through each application and its memory usage
for i in range(n):
    # If the current application is important, add it to the dictionary
    if b[i] == 2:
        important_apps[i] = a[i]

# Calculate the total memory usage of all important applications
important_memory = sum(important_apps.values())

# Check if there are enough units of memory to remove
if m >= total_memory - important_memory:
    # Output "YES" if it is possible to free at least m units of memory
    print("YES")
else:
    # Output "NO" if it is not possible to free at least m units of memory
    print("NO")