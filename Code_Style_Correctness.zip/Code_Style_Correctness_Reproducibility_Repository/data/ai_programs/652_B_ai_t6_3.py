import sys

n = int(input())
a = list(map(int, input().split()))

# Check if the array is already z-sorted
if all(i >= i - 1 for i in a if i % 2 == 0) and all(i <= i - 1 for i in a[1:] if i % 2 != 0):
    print("Yes")
else:
    # Sort the array in place using the z-sort algorithm
    for i in range(n - 1):
        if a[i] > a[i + 1]:
            a[i], a[i + 1] = a[i + 1], a[i]
    print("No")