def is_lucky(s):
    # Check if all digits in the string are lucky
    for c in s:
        if not (c == '4' or c == '7'):
            return False
    return True

# Read input from standard input
input_string = input()

# Check if the input string is lucky
if is_lucky(input_string):
    print("LUCKY")
else:
    print("NOT LUCKY")