import sys

n = int(input())
a = list(map(int, input().split()))
q = int(input())

for i in range(q):
    x, y = map(int, input().split())
    l = (a[-1] + x) % n + 1
    r = (a[-1] + y) % n + 1
    a.extend(range(l, r+1))
    a[-1] = r

print(*a, sep=' ')