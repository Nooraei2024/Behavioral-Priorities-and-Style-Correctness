import sys

n = int(input())
p_i = []
for i in range(n):
    p_i.append(str(input()))

# Check if all PIN codes are different
if len(set(p_i)) == n:
    print("No change")
else:
    # Get the minimum number of digits in all PIN codes
    min_digits = min([len(pin) for pin in p_i])
    # Increment each digit by 1 to make them different
    new_pins = [str(int(pin) + 1).zfill(min_digits) for pin in p_i]
    print(" ".join(new_pins))