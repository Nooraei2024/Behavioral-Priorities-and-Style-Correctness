import sys

# Read input from stdin
n, m = map(int, sys.stdin.readline().split())
s_1 = list(map(int, sys.stdin.readline().split()))

# Initialize the board with blank cells
board = [[] for _ in range(n)]

# Fill the board with monsters and potions
for i in range(m):
    cell = s_1[i] - 1
    if board[cell]:
        continue
    else:
        board[cell].append('M')

# Print the final board
print(*board, sep='\n')