import sys

# Read input from standard input (stdin)
input_data = sys.stdin.readline().strip()

# Split the input data into a list of integers
input_list = [int(x) for x in input_data.split()]

# Initialize variables to keep track of the collectors' positions and the total distance traveled
collector1_pos = 0
collector2_pos = 0
total_distance = 0

# Loop through each integer in the list
for i in range(len(input_list)):
    # If the current element is a department, move both collectors to that position
    if input_list[i] == 1:
        collector1_pos = i
        collector2_pos = i
    # If the current element is an office, move only one collector to that position
    elif input_list[i] == 0:
        collector1_pos = i
    else:
        collector2_pos = i
    
    # Calculate the distance traveled by both collectors and add it to the total distance
    distance = abs(collector1_pos - collector2_pos)
    total_distance += distance

# Print the total distance traveled
print(total_distance)