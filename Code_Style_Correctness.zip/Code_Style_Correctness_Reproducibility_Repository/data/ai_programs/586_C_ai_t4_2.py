import sys

n = int(input())
children = []
for i in range(n):
    children.append(int(input()))

confidence = 0
for child in children:
    if child == 1:
        confidence += 1
    else:
        confidence -= 1

print(confidence)