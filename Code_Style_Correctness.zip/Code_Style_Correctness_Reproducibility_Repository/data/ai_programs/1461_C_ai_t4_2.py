import sys

n = int(input())
a = list(map(int, input().split()))
m = int(input())

for i in range(m):
    r, p = map(int, input().split())
    if r > n or p > n:
        continue
    for j in range(r):
        a[j] += 1
    for j in range(p-1, -1, -1):
        a[j] -= 1

print(*a)