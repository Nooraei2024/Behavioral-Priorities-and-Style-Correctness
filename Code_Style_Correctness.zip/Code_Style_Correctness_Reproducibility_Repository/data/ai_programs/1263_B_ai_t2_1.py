import sys

n = int(input())
pins = []
for i in range(n):
    pin = input()
    pins.append(pin)

# Check if all PIN codes are different
if len(set(pins)) == n:
    print("No changes needed")
else:
    # Find the smallest number of digits that would make all PIN codes different
    min_digits = 10
    for pin in pins:
        digits = len(pin)
        if digits < min_digits:
            min_digits = digits
    
    # Update the PIN codes to have at least min_digits digits
    updated_pins = []
    for pin in pins:
        while len(pin) < min_digits:
            pin = "0" + pin
        updated_pins.append(pin)
    
    print("Updated PIN codes:")
    for pin in updated_pins:
        print(pin)