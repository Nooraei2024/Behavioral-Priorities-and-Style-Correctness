import sys

def covered_points(segments):
    points = set()
    for segment in segments:
        x1, y1, x2, y2 = segment
        if x1 == x2:
            for y in range(min(y1, y2), max(y1, y2) + 1):
                points.add((x1, y))
        elif y1 == y2:
            for x in range(min(x1, x2), max(x1, x2) + 1):
                points.add((x, y1))
        else:
            slope = (y2 - y1) / (x2 - x1)
            intercept = y1 - slope * x1
            for x in range(min(x1, x2), max(x1, x2) + 1):
                y = int(slope * x + intercept)
                points.add((x, y))
    return len(points)

if __name__ == "__main__":
    n = int(input())
    segments = []
    for _ in range(n):
        segments.append(list(map(int, input().split())))
    print(covered_points(segments))