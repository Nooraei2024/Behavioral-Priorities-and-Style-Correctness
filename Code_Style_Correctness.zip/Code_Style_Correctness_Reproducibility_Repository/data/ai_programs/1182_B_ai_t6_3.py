import sys

def plus_from_picture(picture):
    w, h = len(picture[0]), len(picture)
    center = None
    for i in range(w):
        for j in range(h):
            if picture[i][j]:
                if center is not None:
                    return False
                center = (i, j)
    if center is None:
        return False
    
    for i in range(center[0]-1, center[0]+2):
        for j in range(center[1]-1, center[1]+2):
            if not picture[i][j]:
                return False
    
    for i in range(w):
        for j in range(h):
            if i != center[0] and j != center[1] and picture[i][j]:
                return False
    
    return True

picture = [list(input()) for _ in range(int(sys.stdin.readline().strip()))]
print(plus_from_picture(picture))