import sys

def solve(n, m):
    result = n
    for i in range(m):
        result = str(result)
        for j in range(len(result)):
            if result[j].isdigit():
                result = result[:j] + str(int(result[j]) + 1) + result[j+1:]
    return len(str(result)) % (10**9 + 7)

t = int(input())
for _ in range(t):
    n, m = map(int, input().split())
    print(solve(n, m))