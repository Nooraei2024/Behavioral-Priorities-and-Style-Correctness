import sys

# Read input from stdin
n = int(input())

# Initialize variables
cake_height = 0
cake_radius = 0
total_volume = 0

# Loop through each cake
for i in range(1, n+1):
    # Get the height and radius of the current cake
    cake_height = int(input())
    cake_radius = int(input())
    
    # Calculate the volume of the current cake
    cake_volume = (cake_height * 2 * math.pi * cake_radius) + (cake_height * cake_radius)
    
    # Add the volume to the total volume
    total_volume += cake_volume

# Print the total volume
print(total_volume)