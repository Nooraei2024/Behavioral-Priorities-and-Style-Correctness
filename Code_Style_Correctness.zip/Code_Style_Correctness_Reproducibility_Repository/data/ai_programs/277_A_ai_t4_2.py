import sys

# Read input from stdin
n = int(sys.stdin.readline())
m = int(sys.stdin.readline())
languages = []
for i in range(n):
    languages.append([int(x) for x in sys.stdin.readline().split()])

# Calculate the cost of learning each language
costs = [0] * m
for i in range(n):
    for j in languages[i]:
        costs[j-1] += 1

# Find the minimum cost to learn all official languages
min_cost = float('inf')
for i in range(m):
    if costs[i] > 0:
        min_cost = min(min_cost, costs[i])

# Output the result
print(min_cost)