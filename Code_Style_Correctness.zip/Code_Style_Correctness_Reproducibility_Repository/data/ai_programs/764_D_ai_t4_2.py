import sys

# Read input from standard input (stdin)
n = int(input())

# Initialize a list to store the colors of the rectangles
colors = []

# Loop through each rectangle and assign a color
for i in range(n):
    # If the current rectangle is not colored, assign it a new color
    if len(colors) < n:
        colors.append(i % 4 + 1)
    # Otherwise, check if the next available color is already used by another rectangle
    else:
        for j in range(len(colors)):
            if colors[j] == (i + 1) % 4 + 1:
                break
        else:
            colors.append((i + 1) % 4 + 1)

# Print the list of assigned colors
print(*colors, sep='\n')