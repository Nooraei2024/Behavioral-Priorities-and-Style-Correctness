import sys

n = int(input())
a = list(map(int, input().split()))

# Calculate the sum and product of all elements in the array
sum_val = sum(a)
prod_val = 1
for i in range(n):
    prod_val *= a[i]

# Check if either the sum or the product is equal to zero
if sum_val == 0 or prod_val == 0:
    # If so, do one more operation
    GuyManuelAndThomasDoOneMoreOperation()
else:
    # Otherwise, print the minimum number of steps needed to make both the sum and product different
    print(n)

def GuyManuelAndThomasDoOneMoreOperation():
    # Increase the value of one element by 1
    a[0] += 1