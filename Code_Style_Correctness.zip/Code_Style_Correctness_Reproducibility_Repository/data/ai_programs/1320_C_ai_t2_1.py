import sys

# Read input from stdin
n = int(input())
m = int(input())
p = int(input())
weapons = []
armor_sets = []
for i in range(n):
    weapons.append((int(input()), int(input())))
for j in range(m):
    armor_sets.append((int(input()), int(input())))
monsters = []
for k in range(p):
    monsters.append((int(input()), int(input())))

# Calculate the optimal equipment for each monster
optimal_equipment = {}
for monster in monsters:
    defense, x = monster
    best_weapon = None
    best_armor_set = None
    best_cost = 0
    for weapon in weapons:
        attack, cost = weapon
        if defense >= attack:
            continue
        for armor_set in armor_sets:
            defense_, cost_ = armor_set
            if defense_ >= defense:
                continue
            total_cost = cost + cost_
            if total_cost > best_cost:
                best_weapon = weapon
                best_armor_set = armor_set
                best_cost = total_cost
    optimal_equipment[monster] = (best_weapon, best_armor_set)

# Print the optimal equipment for each monster
for monster in monsters:
    weapon, armor