import sys

# Read input from stdin
n, k = map(int, sys.stdin.readline().split())
a = list(map(int, sys.stdin.readline().split()))
e = list(map(int, sys.stdin.readline().split()))

# Initialize the scores for each judge
scores = [0] * n

# Loop through each judge and calculate their score
for i in range(n):
    # Calculate the score for this judge based on your skill and experience
    score = (k - a[i]) / e[i]
    
    # Add the score to the total score for this judge
    scores[i] += score

# Print the total score for each judge
for i in range(n):
    print(scores[i])