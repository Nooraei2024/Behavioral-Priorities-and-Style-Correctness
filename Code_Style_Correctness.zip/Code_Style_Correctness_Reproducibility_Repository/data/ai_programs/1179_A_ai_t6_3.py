import sys

n = int(input())
deque = []
for i in range(1, n+1):
    deque.append(i)

while len(deque) > 2:
    A = deque.popleft()
    B = deque.popleft()
    if A > B:
        deque.appendleft(A)
        deque.append(B)
    else:
        deque.append(B)
        deque.appendleft(A)

print(deque[0], end="")
for i in range(1, len(deque)):
    print(",", deque[i], end="")