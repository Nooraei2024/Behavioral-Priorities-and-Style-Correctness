import sys

input_string = sys.stdin.readline()
input_list = input_string.split()
n = int(input_list[0])
m = int(input_list[1])
k = int(input_list[2])
bricks = [int(i) for i in sys.stdin.readline().strip().split(' ')]

# Initialize the wall with a default design
wall = [[0 for _ in range(m)] for _ in range(n)]

# Loop through each brick and place it on the wall according to the chosen design
for i in range(k):
    row, col, height = bricks[3*i], bricks[3*i+1], bricks[3*i+2]
    for j in range(height):
        wall[row-1+j][col-1] = 1

# Print the final wall design
for row in wall:
    print(' '.join([str(x) for x in row]))