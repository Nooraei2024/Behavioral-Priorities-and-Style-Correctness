import sys

def is_valid(arr):
    if len(set(arr)) < 4:
        return False
    for i in range(len(arr) - 1):
        if arr[i] == arr[i + 1]:
            return False
    return True

if __name__ == '__main__':
    n = int(input())
    arr = list(map(int, input().split()))
    if is_valid(arr):
        print("YES")
    else:
        print("NO")