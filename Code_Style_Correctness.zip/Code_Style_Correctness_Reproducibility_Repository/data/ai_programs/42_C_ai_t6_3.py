import sys

# Read input from stdin
input_str = sys.stdin.readline().strip()

# Split input into a list of integers
numbers = [int(x) for x in input_str.split()]

# Initialize variables to keep track of the minimum and maximum values
min_val, max_val = 0, 0

# Loop through each number and update the min and max values
for num in numbers:
    if num < min_val or min_val == 0:
        min_val = num
    if num > max_val:
        max_val = num

# Check if the minimum value is even, if so divide all numbers by two
if min_val % 2 == 0:
    for i in range(len(numbers)):
        numbers[i] //= 2

# Update the minimum and maximum values again after dividing by two
min_val = min(numbers)
max_val = max(numbers)

# If the minimum value is still not equal to one, increase all numbers by one
if min_val != 1:
    for i in range(len(numbers)):
        numbers[i] += 1

# Print the updated list of integers as a single line of output
print(' '.join([str(x) for x in numbers]))