import sys

def build_wall(bricks, designs):
    # Select a random design from the given list of designs
    design = designs[random.randint(0, len(designs) - 1)]

    # Create a list to store the brick positions
    brick_positions = []

    # Place bricks on top of each other according to the chosen design
    for row in range(len(design)):
        for col in range(len(design[row])):
            if design[row][col] == 1:
                brick_positions.append((row, col))

    # Return the list of brick positions
    return brick_positions

# Read input from standard input (stdin)
bricks = int(input())
designs = []
for _ in range(bricks):
    designs.append([int(x) for x in input().split()])

# Call the build_wall function with the given bricks and designs
print(build_wall(bricks, designs))