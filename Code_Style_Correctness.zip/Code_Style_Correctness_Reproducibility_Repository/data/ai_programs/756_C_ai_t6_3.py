import sys

n, m = map(int, input().split())
stack = []
for i in range(1, n+1):
    op = int(input())
    if op == 0:
        stack.append(i)
    elif op == 1 and len(stack) > 0:
        stack.pop()
    else:
        print("Error")

for i in range(m):
    pi = int(input())
    if pi < n+1 and pi not in stack:
        print("Error")
    elif pi == n+1:
        print("".join(str(x) for x in stack))
    else:
        print("Okay")