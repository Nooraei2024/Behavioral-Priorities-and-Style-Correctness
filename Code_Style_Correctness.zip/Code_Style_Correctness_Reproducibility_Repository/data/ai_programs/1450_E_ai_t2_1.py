import sys

def is_capitalist(friends):
    for i in range(len(friends)):
        for j in range(i+1, len(friends)):
            if friends[i] == friends[j] + 1:
                return False
    return True

if __name__ == "__main__":
    input = sys.stdin.readline().strip()
    friends = list(map(int, input.split()))
    print("YES" if is_capitalist(friends) else "NO")