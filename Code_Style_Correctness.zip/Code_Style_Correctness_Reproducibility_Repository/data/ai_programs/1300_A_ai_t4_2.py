import sys

n = int(input())
a = list(map(int, input().split()))

# Find the minimum number of steps to make both the sum and product of all elements different from zero
min_steps = 0
while True:
    # Check if the sum is equal to zero
    if sum(a) == 0:
        min_steps += 1
        for i in range(n):
            a[i] += 1
    # Check if the product is equal to zero
    elif prod(a) == 0:
        min_steps += 1
        for i in range(n):
            a[i] += 1
    else:
        break

print(min_steps)