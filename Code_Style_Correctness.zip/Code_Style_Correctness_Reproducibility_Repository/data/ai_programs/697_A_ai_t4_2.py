import sys

# Read input from stdin
t = float(input())
x = float(input())

# Calculate the time of the first bark
first_bark = t + s

# Check if Barney will be able to eat the pineapple at time x
if x < first_bark or x % (2 * s) != 0:
    print("NO")
else:
    print("YES")