import sys

# Read input from stdin
n = int(input())
S = set([int(x) for x in input().split()])

# Generate all permutations of 0 to 2^n - 1
permutations = [list(range(i, i + n)) for i in range(2**n)]

# Check if each permutation is a magical permutation
for p in permutations:
    # Check if the bitwise xor of any two consecutive elements is an element in S
    for i in range(len(p) - 1):
        if (p[i] ^ p[i + 1]) not in S:
            break
    else:
        print(*p, sep=' ')