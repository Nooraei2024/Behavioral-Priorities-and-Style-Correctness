import sys

# Read input from stdin
sentence = sys.stdin.readline().strip()

# Convert all letters to lowercase
sentence = sentence.lower()

# Reverse each word individually
words = sentence.split(" ")
reversed_words = [word[::-1] for word in words]
sentence = " ".join(reversed_words)

# Remove all spaces
sentence = sentence.replace(" ", "")

# Output the ciphered sentence to stdout
print(sentence)