import sys

# Read input from stdin
n = int(input())
locations = []
for _ in range(n):
    xi, yi, ki = map(int, input().split())
    locations.append((xi, yi, ki))

# Calculate the maximum distance between any two points
max_distance = 0
for i in range(n):
    for j in range(i+1, n):
        distance = (locations[i][0] - locations[j][0]) ** 2 + (locations[i][1] - locations[j][1]) ** 2
        if distance > max_distance:
            max_distance = distance

# Calculate the maximum number of people that can be accommodated within the city boundaries
max_people = 0
for i in range(n):
    for j in range(i+1, n):
        distance = (locations[i][0] - locations[j][0]) ** 2 + (locations[i][1] - locations[j][1]) ** 2
        if distance <= max_distance:
            max_people += locations[i][2] + locations[j][2]

# Output the maximum number of people that can be accommodated within the city boundaries
print(max_people)