import sys

# Read input from stdin
input_string = sys.stdin.readline().strip()

# Convert input string to a list of characters
puppies = list(input_string)

# Initialize dictionary to store frequency of each color
color_freq = {}

# Loop through the puppies and update the frequency of each color
for puppy in puppies:
    if puppy not in color_freq:
        color_freq[puppy] = 1
    else:
        color_freq[puppy] += 1

# Find the most frequent color and its frequency
most_frequent_color = max(color_freq, key=color_freq.get)
most_frequent_freq = color_freq[most_frequent_color]

# Loop through the puppies again and recolor them to the most frequent color
for i in range(len(puppies)):
    if puppies[i] != most_frequent_color:
        puppies[i] = most_frequent_color

# Output the recolored list of puppies
print("".join(puppies))