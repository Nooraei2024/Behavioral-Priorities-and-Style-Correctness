import sys

# Read input from stdin
n = int(input())
p = list(map(int, input().split()))

# Calculate the total revenue of selling all the tickets in different orders
total_revenue = sum(p)

# Initialize variables to store the revenue of each order and the number of tickets sold
revenue_list = [0] * (n + 1)
num_tickets_sold = [0] * (n + 1)

# Loop through all possible orders
for i in range(1, n + 1):
    # Calculate the revenue of each order by multiplying the price of each ticket by its quantity sold
    revenue = sum([p[j - 1] * (i - j + 1) for j in range(1, i + 1)])
    
    # Add the revenue to the list of revenues and increment the number of tickets sold
    revenue_list[i] += revenue
    num_tickets_sold[i] += i

# Find the order that maximizes the revenue while applying the ecological restoration programs
max_revenue = 0
max_order = 0
for i in range(1, n + 1):
    x = int(total_revenue * 0.05)
    a = int(x / p[i - 1])
    
    # Calculate the revenue of the order with the ecological restoration programs applied
    re