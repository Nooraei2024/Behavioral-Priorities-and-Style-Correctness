import sys

# Read input from stdin
n_1, n_2, m = map(int, sys.stdin.readline().split())
edges = []
for _ in range(m):
    edges.append(list(map(int, sys.stdin.readline().split())))

# Initialize the dp table with 0 for each edge
dp = [[0] * (n_1 + n_2) for _ in range(3)]

# Fill the dp table with the minimum cost of painting each edge red or blue
for i in range(m):
    u, v, r, b = edges[i]
    dp[0][u - 1] += min(r, b)
    dp[1][v - 1] += min(r, b)
    dp[2][u - 1] += max(r, b)
    dp[2][v - 1] += max(r, b)

# Find the minimum cost of painting all edges red or blue
min_cost = float('inf')
for i in range(3):
    min_cost = min(min_cost, sum(dp[i]))

print(min_cost)