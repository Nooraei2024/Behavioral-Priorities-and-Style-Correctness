import sys

n, d = map(int, input().split())
platforms = []
for _ in range(n):
    platforms.append(list(map(int, input().split())))

current_position = 0
while current_position < n:
    platform = platforms[current_position]
    if current_position == platform[0]:
        current_position += d
    elif current_position == platform[1]:
        current_position += d - 1
    else:
        break

if current_position < n:
    print("-1")
else:
    print(platforms[current_position][0])