import sys

n = int(input())
p = list(map(int, input().split()))
q = list(map(int, input().split()))

# Calculate the sum of the permutations
sum_p = 0
for i in range(n):
    sum_p += p[i] * (n - i)

sum_q = 0
for j in range(n):
    sum_q += q[j] * (n - j)

# Calculate the ordinal of the permutations
ord_p = 1
for k in range(n):
    if p[k] != k:
        ord_p *= n - k
        ord_p %= 1000000007

ord_q = 1
for l in range(n):
    if q[l] != l:
        ord_q *= n - l
        ord_q %= 1000000007

# Calculate the sum of the permutations and their ordinal
sum = (sum_p + sum_q) % 1000000007
ord = (ord_p * ord_q) % 1000000007

print(sum, end='')
print(ord, end='')