import sys

def graph_subset_problem(graph, k):
    # Initialize a dictionary to keep track of the neighbors for each vertex
    neighbors = {}
    for i in range(len(graph)):
        neighbors[i] = set()

    # Iterate over the edges and update the neighbors dictionary
    for edge in graph:
        neighbors[edge[0]].add(edge[1])
        neighbors[edge[1]].add(edge[0])

    # Initialize a list to store the vertices with at least k neighbors
    vertices = []

    # Iterate over the vertices and check if they have at least k neighbors
    for vertex in range(len(graph)):
        if len(neighbors[vertex]) >= k:
            vertices.append(vertex)

    # If there are no such cliques and subsets, report about it
    if not vertices:
        print("No such clique or subset found.")
    else:
        # Print the vertices with at least k neighbors
        for vertex in vertices:
            print(vertex)

# Read input from standard input (stdin)
graph = []
for line in sys.stdin:
    graph.append([int(x) for x in line.split()])

# Call the function to find the clique or subset and output the results
k = int(sys.stdin.readline())
graph_subset_problem(graph, k)