import sys

# Read input from standard input
n = int(input())
a = list(map(int, input().split()))

# Initialize a dictionary to store the illusion rates for each room
illusions = {}
for i in range(1, n + 1):
    illusions[i] = a[i - 1]

# Initialize a dictionary to store the distances between rooms
distances = {}
for i in range(1, n + 1):
    for j in range(1, n + 1):
        if i != j:
            distances[(i, j)] = float('inf')

# Breadth-first search to find the shortest distance between each pair of rooms
queue = [(1, 1)]
while queue:
    x, y = queue.pop(0)
    for i in range(1, n + 1):
        if i != y and (x, i) not in distances:
            distances[(x, i)] = max(a[x - 1] + a[i - 1], distances[(x, y)] + 1)
            queue.append((i, y))

# Output the shortest distance between each pair of rooms
for i in range(1, n + 1):
    for j in range(1, n + 1):
        if i != j and (i, j) in distances:
            print(f"{distances[(i, j)]}", end=" ")