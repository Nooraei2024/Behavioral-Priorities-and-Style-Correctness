import sys

n = int(input())
deque = []
for i in range(1, n+1):
    deque.append(i)

while len(deque) > 2:
    a = deque.popleft()
    b = deque.popleft()
    if a > b:
        deque.append(a)
        deque.append(b)
    else:
        deque.append(b)
        deque.append(a)

print(deque[0], end='')
for i in range(1, len(deque)):
    print(',', deque[i], end='')