import sys

# Read input from stdin
s = sys.stdin.readline().strip()

# Initialize variables
n = len(s)
l = 0
r = n - 1

# Loop through the string and reverse each substring
while l < r:
    # Reverse the substring
    s[l:r] = s[l:r][::-1]
    
    # Update the indices for the next iteration
    l += 1
    r -= 1

# Print the cleaned up string
print(s)