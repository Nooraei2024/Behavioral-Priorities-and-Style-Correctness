import sys

# Read input from stdin
t, s, x = map(int, sys.stdin.readline().split())

# Calculate the time when the pineapple will bark for the first time
bark_time = t + s

# Check if Barney's time to eat is during the barking period
if x >= bark_time:
    print("Yes")
else:
    print("No")