import sys

# Read input from stdin
n = int(input())
toys = list(map(int, sys.stdin.readline().split()))

# Restore the piles' arrangement
piles = []
for i in range(n):
    if len(piles) == 0 or toys[i] != piles[-1][-1]:
        piles.append([toys[i]])
    else:
        piles[-1].append(toys[i])

# Print the restored arrangement
for pile in piles:
    print(*pile, sep=' ')