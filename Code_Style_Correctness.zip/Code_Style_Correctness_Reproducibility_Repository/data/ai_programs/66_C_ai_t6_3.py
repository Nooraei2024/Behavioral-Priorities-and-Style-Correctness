import os

def get_subfolders(folder):
    subfolders = []
    for file in os.listdir(folder):
        path = os.path.join(folder, file)
        if os.path.isdir(path):
            subfolders.append(file)
    return subfolders

def get_files(folder):
    files = []
    for file in os.listdir(folder):
        path = os.path.join(folder, file)
        if not os.path.isdir(path):
            files.append(file)
    return files

def main():
    folder = input()
    subfolders = get_subfolders(folder)
    files = get_files(folder)
    print("Subfolders:", len(subfolders))
    print("Files:", len(files))

if __name__ == "__main__":
    main()