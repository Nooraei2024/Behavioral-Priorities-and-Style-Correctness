import sys

def get_permutation(n):
    permutation = []
    for i in range(n):
        permutation.append(i)
    return permutation

def get_ord(permutation):
    ord = 0
    for i in range(len(permutation)):
        ord += (permutation[i] * (permutation[i] + 1)) // 2
    return ord

def get_sum(p, q):
    sum = []
    for i in range(len(p)):
        sum.append(p[i] + q[i])
    return sum

if __name__ == '__main__':
    n = int(input())
    p = get_permutation(n)
    q = get_permutation(n)
    print(get_sum(p, q))