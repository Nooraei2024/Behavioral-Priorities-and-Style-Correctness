import sys

# Read input from stdin
input_string = sys.stdin.readline().strip()

# Split input string into a list of integers
numbers = [int(x) for x in input_string.split()]

# Find the maximum beauty value that is divisible by 2v without remainder
max_beauty = -1
for v in range(len(numbers)):
    if all(n % (2 * v) == 0 for n in numbers):
        max_beauty = max(max_beauty, v)

# Print the maximum beauty value
print(max_beauty)