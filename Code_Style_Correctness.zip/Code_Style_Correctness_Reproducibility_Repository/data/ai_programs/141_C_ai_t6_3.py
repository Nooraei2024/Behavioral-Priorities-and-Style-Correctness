import sys

n = int(input())
heights = list(map(int, input().split()))
seated_heights = []
for i in range(n):
    seated_heights.append(heights[i])

# Sort the heights in descending order
seated_heights.sort(reverse=True)

# Calculate the number of people who are taller than each person and stand in front of them
tallest = 0
for i in range(n):
    if seated_heights[i] > tallest:
        tallest = seated_heights[i]
        num_taller = 1
    else:
        num_taller += 1

# Output the result
print(num_taller)