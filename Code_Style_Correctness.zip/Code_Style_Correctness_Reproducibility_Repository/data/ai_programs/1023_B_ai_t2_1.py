import sys

n, k = map(int, input().split())

# Calculate the number of pairs of toys that can be chosen
num_pairs = (k * (k + 1)) // 2

# Initialize a dictionary to store the counts of each toy
toy_counts = {}
for i in range(1, n+1):
    toy_counts[i] = 0

# Iterate over the pairs of toys and increment the count for each toy
for pair in range(num_pairs):
    a, b = map(int, input().split())
    if a != b:
        toy_counts[a] += 1
        toy_counts[b] += 1

# Calculate the number of ways to choose two toys with total cost k
num_ways = 0
for i in range(1, n+1):
    num_ways += toy_counts[i] * (toy_counts[i] - 1) // 2

print(num_ways)