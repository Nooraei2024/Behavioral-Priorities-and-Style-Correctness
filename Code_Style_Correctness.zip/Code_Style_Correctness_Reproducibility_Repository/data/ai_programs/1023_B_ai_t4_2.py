import itertools

def solve(n, k):
    # Calculate the number of pairs of toys that can be chosen
    num_pairs = int((k * (k + 1)) / 2)

    # Generate all possible pairs of toys
    pairs = [(i, j) for i in range(1, n + 1) for j in range(i, n + 1)]

    # Filter out pairs that are not valid
    valid_pairs = [pair for pair in pairs if sum(pair) == k]

    # Count the number of unique pairs
    return len(set(valid_pairs))

# Read input from standard input
n, k = map(int, input().split())

# Print output to standard output
print(solve(n, k))