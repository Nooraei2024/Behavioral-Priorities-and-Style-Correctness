import sys

# Read input from standard input (stdin)
n = int(input())
m = int(input())

# Initialize a list to store the number of brains for each zombie
brains = []
for i in range(n):
    brains.append(0)

# Read the number of brains for each zombie from standard input (stdin)
for i in range(n):
    brains[i] = int(input())

# Calculate the total number of brains
total_brains = sum(brains)

# Print the result
print(total_brains * m)