from collections import deque

def get_connected_components(tree):
    visited = set()
    components = []
    for node in tree:
        if node not in visited:
            component = []
            queue = deque([node])
            while queue:
                node = queue.popleft()
                if node not in visited:
                    visited.add(node)
                    component.append(node)
                    for neighbor in tree[node]:
                        queue.append(neighbor)
            components.append(component)
    return components

def get_max_product(tree):
    connected_components = get_connected_components(tree)
    max_product = 1
    for component in connected_components:
        product = 1
        for node in component:
            product *= len(component) - node.index
        max_product = max(max_product, product)
    return max_product

if __name__ == "__main__":
    n = int(input())
    tree = {}
    for i in range(n):
        tree[i] = []
    for i in range(n - 1):
        u, v = map(int, input().split())
        tree[u].append(v)
        tree[v].append(u)
    print(get_max_product(tree))