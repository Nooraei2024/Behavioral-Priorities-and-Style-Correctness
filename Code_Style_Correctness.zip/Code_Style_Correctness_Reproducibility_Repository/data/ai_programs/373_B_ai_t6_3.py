import sys

w = int(sys.stdin.readline())
m = int(sys.stdin.readline())

max_length = 0
current_cost = 0
for i in range(m, m + w + 1):
    cost = S(i) * k
    if current_cost + cost <= w:
        max_length += 1
        current_cost += cost

print(max_length)