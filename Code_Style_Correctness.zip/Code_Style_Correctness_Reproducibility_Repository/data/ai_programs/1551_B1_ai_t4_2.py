import sys

s = input()
red_count = 0
green_count = 0
for c in s:
    if c == 'r':
        red_count += 1
    elif c == 'g':
        green_count += 1
if red_count > 0 and green_count > 0:
    print("Wonderful")
else:
    print("Not wonderful")