import sys

def build_wall(bricks, designs):
    # Select a random design from the list of possible designs
    design = random.choice(designs)
    
    # Create a list to store the wall bricks
    wall_bricks = []
    
    # Loop through each row of the design
    for row in range(len(design)):
        # Loop through each column of the design
        for col in range(len(design[row])):
            # If the current brick is a valid brick, add it to the wall bricks list
            if design[row][col] == 1:
                wall_bricks.append(bricks.pop())
    
    return wall_bricks

# Read input from standard input (stdin)
bricks = sys.stdin.readline().strip()
bricks = [int(x) for x in bricks.split(' ')]
designs = []

# Read the number of possible designs from standard input (stdin)
num_designs = int(sys.stdin.readline())

# Loop through each design and add it to the list of possible designs
for _ in range(num_designs):
    # Read the current design from standard input (stdin)
    design = sys.stdin.readline().strip()
    
    # Convert the design string to a list of integers
    design = [int(x) for x in design.split(' ')]
    
    # Add the current design to the list of possible designs