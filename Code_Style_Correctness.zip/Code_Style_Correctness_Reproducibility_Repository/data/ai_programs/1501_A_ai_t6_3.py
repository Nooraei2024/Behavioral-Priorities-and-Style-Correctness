import sys

n = int(input())
a_b = [(int(x), int(y)) for x, y in (line.split() for line in sys.stdin)]

# Calculate the total expected time of train's arrival at all stations
total_time = 0
for i in range(n):
    total_time += a_b[i][1] - a_b[i][0]

# Check if Alexey can reach his destination on time
if total_time >= n:
    print("YES")
else:
    print("NO")