import sys

def solve(a, k):
    n = len(a)
    count = 0
    for i in range(n-1):
        if a[i] == 1 and a[i+1] == 0:
            count += 1
    return (count + k - 1) / (k * (n - 1))

if __name__ == '__main__':
    input = sys.stdin.read()
    data = list(map(int, input.split()))
    n, k = data[0], data[1]
    a = [0] * n
    for i in range(n):
        a[i] = int(input())
    print(solve(a, k))