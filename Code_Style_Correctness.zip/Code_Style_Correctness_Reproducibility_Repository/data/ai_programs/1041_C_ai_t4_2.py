import sys

# Read input from stdin
m = int(input())
n = int(input())
a = list(map(int, input().split()))

# Calculate the maximum number of coffee breaks that Monocarp can take
max_breaks = m // (n + 1)

# Check if Monocarp's boss is satisfied with his schedule
if sum(a) <= max_breaks:
    print("Yes")
else:
    print("No")