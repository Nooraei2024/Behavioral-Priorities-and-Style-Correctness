import sys

# Read input from stdin
n = int(input())
bacteria_types = []
for i in range(n):
    bacteria_types.append(int(input()))

# Initialize the number of bacteria of each type
bacteria_counts = [0] * n
for i in range(n):
    bacteria_counts[i] = int(input())

# Calculate the total energy of all bacteria
total_energy = 0
for i in range(n):
    for j in range(bacteria_types[i]):
        total_energy += (j + 1) * bacteria_counts[i]

# Calculate the energy of each bacterium
bacterium_energies = [0] * n
for i in range(n):
    for j in range(bacteria_types[i]):
        bacterium_energies[j + 1] += (j + 1) * bacteria_counts[i]

# Find the maximum energy of a single bacterium
max_energy = max(bacterium_energies)

# Print the answer
print(max_energy)