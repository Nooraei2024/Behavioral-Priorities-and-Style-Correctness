import sys

def plus_from_picture(w, h):
    # Initialize a 2D array to store the picture
    picture = [[0] * w for _ in range(h)]

    # Read the input from stdin and fill the 2D array with the picture data
    for i in range(h):
        for j in range(w):
            picture[i][j] = int(sys.stdin.read(1))

    # Check if there is a single "+" shape in the picture
    center_x, center_y = -1, -1
    for i in range(h):
        for j in range(w):
            if picture[i][j] == 1:
                if center_x != -1 and center_y != -1:
                    # If we have already found a center cell, then this cell is not part of the "+" shape
                    return False
                else:
                    center_x = j
                    center_y = i

    if center_x == -1 or center_y == -1:
        # If we have not found a center cell, then there is no "+" shape in the picture
        return False

    # Check if there are any non-empty cells in each direction from the center cell
    for i in range(h):
        for j in range(w):
            if abs(i - center_y) + abs(j - center_x) > 1:
                return False

    # If we have