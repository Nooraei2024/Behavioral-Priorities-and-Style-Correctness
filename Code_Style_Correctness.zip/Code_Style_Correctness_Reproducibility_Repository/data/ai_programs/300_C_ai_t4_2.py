import sys

a, b = map(int, input().split())
n = int(input())

good_numbers = []
for i in range(1, n+1):
    if str(i).count(str(a)) == 1 and str(i).count(str(b)) == 1:
        good_numbers.append(i)

excellent_numbers = []
for i in good_numbers:
    if sum(int(digit) for digit in str(i)) in good_numbers:
        excellent_numbers.append(i)

print(len(excellent_numbers))