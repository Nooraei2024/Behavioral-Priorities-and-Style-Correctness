import sys

n = int(input())
k = int(input())

# Initialize a list to store the sizes of the squares
squares = [2**n]

# Perform the splitting operations
for _ in range(k):
    # Get the current size of the largest square
    size = squares[-1]
    
    # If the size is 1, it's not possible to split it further
    if size == 1:
        break
    
    # Split the largest square into four smaller squares with side length a/2
    squares.extend([size // 2] * 4)

# Print the number of squares that remain after all splitting operations are performed
print(len(squares))