import sys

n = int(input())
a = list(map(int, input().split()))

# Find the maximum sum of elements on even positions
max_sum = 0
for i in range(n):
    if i % 2 == 0:
        max_sum += a[i]

# Reverse the subarray with the maximum sum of elements on even positions
rev_subarray = []
for i in range(n-1, -1, -1):
    if i % 2 == 0:
        rev_subarray.append(a[i])

print(*rev_subarray)