import sys

def restore_permutation(p):
    n = len(p)
    result = []
    for i in range(n):
        for j in range(i, 2*n, n):
            result.append(p[j % n])
    return result

if __name__ == '__main__':
    input_data = sys.stdin.read()
    p = list(map(int, input_data.split()))
    result = restore_permutation(p)
    print(*result, sep=' ')