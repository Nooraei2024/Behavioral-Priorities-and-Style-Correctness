import sys

# Read input from stdin
n = int(input())
conveyor_belts = []
for _ in range(n):
    conveyor_belts.append(list(map(int, input().split())))

# Initialize the snake positions and directions
snake_positions = [0] * n
snake_directions = [1] * n

# Simulate the movement of the snakes
for i in range(n):
    # Get the current conveyor belt state
    conveyor_belt = conveyor_belts[i]

    # Update the snake positions and directions based on the current conveyor belt state
    if conveyor_belt == 0:
        # Clockwise conveyor belt
        snake_positions[i] = (snake_positions[i] + 1) % n
        snake_directions[i] = 1
    elif conveyor_belt == 1:
        # Anticlockwise conveyor belt
        snake_positions[i] = (snake_positions[i] - 1) % n
        snake_directions[i] = -1
    else:
        # No conveyor belt
        pass

# Print the final snake positions and directions
print(*snake_positions, sep=' ')
print(*snake_directions, sep=' ')