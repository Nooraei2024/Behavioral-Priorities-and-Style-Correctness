def solve(pages):
    # Initialize a dictionary to store the page numbers and their corresponding letters
    letter_map = {}
    
    # Iterate over each page and extract its number and letter
    for page in pages:
        num, letter = page.split()
        
        # Add the letter to the dictionary with the corresponding page number as the key
        letter_map[num] = letter
    
    # Initialize a list to store the reconstructed book
    reconstructed_book = []
    
    # Iterate over each page and add its corresponding letter to the reconstructed book
    for page in pages:
        num, letter = page.split()
        reconstructed_book.append(letter)
    
    # Return the reconstructed book as a string
    return "".join(reconstructed_book)