import sys

# Read input from stdin
burles = int(sys.stdin.readline())
n_microtransactions = int(sys.stdin.readline())
microtransactions = []
for i in range(n_microtransactions):
    microtransactions.append([int(x) for x in sys.stdin.readline().split()])

# Calculate the number of burles needed to buy all microtransactions
total_burles = 0
for transaction in microtransactions:
    total_burles += transaction[1] * (transaction[2] + 1)

# Check if Ivan has enough burles
if burles >= total_burles:
    print("Yes")
else:
    print("No")