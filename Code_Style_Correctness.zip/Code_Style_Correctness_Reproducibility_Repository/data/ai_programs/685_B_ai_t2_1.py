import sys

def find_centroid(node):
    # Calculate the sum of weights for all nodes in the subtree
    weight_sum = 0
    for child in node.children:
        weight_sum += child.weight
    
    # Find the node with the maximum weight
    max_weight = -1
    max_node = None
    for child in node.children:
        if child.weight > max_weight:
            max_weight = child.weight
            max_node = child
    
    return max_node

def solve():
    # Read the number of nodes and queries from stdin
    n, q = map(int, sys.stdin.readline().split())
    
    # Create a dictionary to store the nodes and their weights
    nodes = {}
    for i in range(1, n+1):
        nodes[i] = {'weight': 0}
    
    # Read the edges from stdin and update the weights of the nodes
    for _ in range(q):
        edge = list(map(int, sys.stdin.readline().split()))
        nodes[edge[0]]['weight'] += 1
        nodes[edge[1]]['weight'] += 1
    
    # Read the queries from stdin and output the centroid of each subtree
    for _ in range(q):
        vi = int(sys.stdin.readline())
        node = find_centroid(nodes[vi])
        print(node['weight'])