import sys

n = int(input())
m = int(input())

# Calculate the number of black squares on each side
black_squares = m // n

# Calculate the number of white squares on each side
white_squares = (n * n) - m

# Check if a black square with side 3 can be formed
if black_squares >= 3:
    print("YES")
else:
    print("NO")