import sys

s = input()
t = ""
for i in range(len(s)):
    if s[i] == s[-1-i]:
        t += s[i]
if len(t) < len(s):
    print("No solution")
else:
    print(t)