import sys

def solve(q, A):
    for query in range(q):
        command = input().strip()
        if command[0] == '+':
            x = int(command[1:])
            A.add(x)
        elif command[0] == '-':
            x = int(command[1:])
            A.remove(x)
        else:
            x = int(command)
            print(max(A))