import sys

# Read input from stdin
n, m = map(int, sys.stdin.readline().split())
junctions = []
for _ in range(m):
    junctions.append(list(map(int, sys.stdin.readline().split())))

# Initialize the graph with n junctions and m two-way roads
graph = [[0] * n for _ in range(n)]
for road in junctions:
    graph[road[0]][road[1]] = 1
    graph[road[1]][road[0]] = 1

# Count the number of dead ends
dead_ends = 0
for i in range(n):
    if sum(graph[i]) == 1:
        dead_ends += 1

# Print the answer
print(n - m + dead_ends)