import sys

def solve(T, S):
    # Initialize the output string
    output = ""
    
    # Loop through each character in the input string
    for i in range(len(S)):
        # Check if the current character is present in the magic spell string
        if T.find(S[i]) != -1:
            # If it is, append the corresponding magic spell to the output string
            output += T[T.find(S[i]):T.find(S[i]) + len(S[i])]
        else:
            # If it's not, append the current character to the output string
            output += S[i]
    
    return output

# Read input from stdin
T = sys.stdin.readline().strip()
S = sys.stdin.readline().strip()

# Call the solve function with the input arguments and print the result
print(solve(T, S))