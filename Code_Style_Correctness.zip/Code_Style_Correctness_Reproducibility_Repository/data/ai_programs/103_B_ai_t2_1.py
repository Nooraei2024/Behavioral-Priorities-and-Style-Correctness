import sys

# Read input from stdin
line = sys.stdin.readline().strip()

# Parse the input string into a list of integers
numbers = [int(x) for x in line.split()]

# Calculate the sum of the numbers
sum = 0
for num in numbers:
    sum += num

# Print the sum to stdout
print(sum)