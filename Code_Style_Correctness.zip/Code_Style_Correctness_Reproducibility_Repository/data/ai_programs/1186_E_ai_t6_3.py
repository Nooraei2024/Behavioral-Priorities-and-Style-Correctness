import sys

n, m = map(int, input().split())
field = []
for _ in range(n):
    field.append([0] * m)

for i in range(n):
    for j in range(m):
        if field[i][j] == 1:
            field[i][j] = 0
        else:
            field[i][j] = 1

print(*field, sep='\n')