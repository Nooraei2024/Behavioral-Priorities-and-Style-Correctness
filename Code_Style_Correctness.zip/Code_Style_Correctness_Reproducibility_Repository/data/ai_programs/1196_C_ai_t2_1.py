import sys

# Read input from stdin
n = int(sys.stdin.readline())
robots = []
for i in range(n):
    x, y = map(int, sys.stdin.readline().split())
    robots.append((x, y))

# Find the location of each robot
for robot in robots:
    print(f"{robot[0]} {robot[1]}")