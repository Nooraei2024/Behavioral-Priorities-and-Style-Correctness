# Read input from stdin
A = set(input().split())

# Define a function to check if a relation is symmetric
def is_symmetric(relation):
    for pair in relation:
        if not (pair[1], pair[0]) in relation:
            return False
    return True

# Define a function to check if a relation is transitive
def is_transitive(relation):
    for triplet in relation:
        if not (triplet[2] in relation) or not (triplet[1] in relation):
            return False
    return True

# Check if the given set of pairs is a symmetric and transitive binary relation
if is_symmetric(A) and is_transitive(A):
    print("Yes")
else:
    print("No")