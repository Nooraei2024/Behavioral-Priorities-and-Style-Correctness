import sys

# Read input from standard input (stdin)
n, m = map(int, sys.stdin.readline().split())
factory_tiles = []
for _ in range(n):
    factory_tiles.append([int(x) for x in sys.stdin.readline().split()])

# Look at each tile's binary form and count the number of 1s
num_ones = [sum(bin(tile).count('1') for tile in row) for row in factory_tiles]

# Print the result
print(*num_ones, sep='\n')