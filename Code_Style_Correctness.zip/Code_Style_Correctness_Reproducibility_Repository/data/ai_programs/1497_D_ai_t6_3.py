import sys

n = int(input())
IQ = 0
points = 0
problems = []
for i in range(1, n+1):
    c_i, tag_i, s_i = map(int, input().split())
    problems.append((c_i, tag_i, s_i))

while IQ < 2**n:
    best_problem = None
    for i in range(1, n+1):
        c_i, tag_i, s_i = problems[i-1]
        if abs(c_i - IQ) > 0 and tag_i != problems[best_problem][1]:
            best_problem = i-1
    if best_problem is not None:
        c_i, tag_i, s_i = problems[best_problem]
        IQ = abs(c_i - IQ)
        points += abs(s_i - s_j)
        print(f"Solved problem {best_problem+1} with IQ {IQ}")
    else:
        break
print(points)