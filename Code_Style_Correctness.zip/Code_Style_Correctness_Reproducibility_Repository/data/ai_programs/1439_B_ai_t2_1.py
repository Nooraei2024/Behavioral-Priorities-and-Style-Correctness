import sys

def find_clique(graph, k):
    # Initialize a dictionary to store the neighbors of each vertex
    neighbors = {}
    for edge in graph:
        neighbors[edge[0]] = []
        neighbors[edge[1]] = []
    
    # Find the neighbors of each vertex
    for edge in graph:
        neighbors[edge[0]].append(edge[1])
        neighbors[edge[1]].append(edge[0])
    
    # Initialize a list to store the vertices that have at least k neighbors
    vertices = []
    for vertex in neighbors:
        if len(neighbors[vertex]) >= k:
            vertices.append(vertex)
    
    # If there are no such cliques and subsets, report about it
    if not vertices:
        print("No clique or subset found")
        return
    
    # Find the maximum clique in the graph
    max_clique = []
    for vertex in vertices:
        if len(max_clique) < k:
            max_clique.append(vertex)
    
    # Print the maximum clique or subset of vertices
    print(max_clique)