import sys

def solve(n, m):
    result = n
    for i in range(m):
        result = str(result)
        result = ''.join([str(int(c) + 1) for c in result])
    return len(result) % (10**9 + 7)

if __name__ == "__main__":
    t = int(input())
    for _ in range(t):
        n, m = map(int, input().split())
        print(solve(n, m))