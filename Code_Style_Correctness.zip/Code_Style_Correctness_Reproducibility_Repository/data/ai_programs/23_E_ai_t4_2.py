from collections import deque

def tree_size(edges):
    n = len(edges) + 1
    visited = [False] * n
    sizes = [0] * n
    for i in range(1, n):
        if not visited[i]:
            queue = deque([i])
            while queue:
                node = queue.popleft()
                for neighbor in edges[node]:
                    if not visited[neighbor]:
                        queue.append(neighbor)
                        visited[neighbor] = True
                sizes[i] += 1
    return sizes

def max_tree_size(n):
    max_size = 0
    for i in range(1, n + 1):
        for j in range(i + 1, n + 1):
            edges = [(i, j)]
            size = tree_size(edges)
            if size > max_size:
                max_size = size
    return max_size

if __name__ == '__main__':
    input = int(input())
    print(max_tree_size(input))