import sys

input_string = sys.stdin.readline().strip()

# Split the input string into a list of words using whitespace as delimiter
words = input_string.split()

# Initialize an empty dictionary to store the word counts
word_counts = {}

# Iterate through each word in the list and increment its count in the dictionary
for word in words:
    if word not in word_counts:
        word_counts[word] = 1
    else:
        word_counts[word] += 1

# Sort the dictionary by value (frequency) in descending order
sorted_dict = sorted(word_counts.items(), key=lambda x: x[1], reverse=True)

# Print the top 5 most frequent words and their frequencies
for i in range(min(len(sorted_dict), 5)):
    print(f"{sorted_dict[i][0]} {sorted_dict[i][1]}")