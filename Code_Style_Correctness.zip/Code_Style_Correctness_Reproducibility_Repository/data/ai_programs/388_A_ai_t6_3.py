import sys

n = int(input())
boxes = []
for _ in range(n):
    xi = int(input())
    boxes.append(xi)

max_stacks = 0
current_stack = 0
for i in range(len(boxes)):
    if current_stack + 1 <= boxes[i]:
        current_stack += 1
        max_stacks = max(max_stacks, current_stack)
    else:
        current_stack = 0

print(max_stacks)