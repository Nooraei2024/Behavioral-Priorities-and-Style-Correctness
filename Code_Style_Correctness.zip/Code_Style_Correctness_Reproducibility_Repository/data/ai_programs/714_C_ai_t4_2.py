import sys

def solve(n, queries):
    multiset = set()
    for query in queries:
        if query[0] == '+':
            multiset.add(int(query[1:]))
        else:
            multiset.discard(int(query[1:]))
    return len(multiset)

if __name__ == '__main__':
    input = sys.stdin.read()
    n, m = map(int, input.split())
    queries = []
    for _ in range(m):
        queries.append(input())
    print(solve(n, queries))