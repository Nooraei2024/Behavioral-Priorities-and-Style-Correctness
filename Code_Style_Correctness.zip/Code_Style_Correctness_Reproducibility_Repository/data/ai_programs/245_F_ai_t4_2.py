import re

# Read input from stdin
logs = []
for line in sys.stdin:
    logs.append(line.strip())

# Validate each log record
valid_logs = []
for log in logs:
    if not re.match(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}:\w+', log):
        continue
    valid_logs.append(log)

# Print the list of valid logs
print(*valid_logs, sep='\n')