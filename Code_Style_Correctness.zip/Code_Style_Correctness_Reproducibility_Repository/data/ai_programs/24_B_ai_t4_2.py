import sys

# Read input from stdin
input_string = sys.stdin.readline().strip()

# Split the input string into a list of integers representing the points earned by each driver after each race
points = [int(x) for x in input_string.split()]

# Initialize a dictionary to store the total points earned by each driver
driver_points = {}

# Iterate through the list of points and update the driver_points dictionary
for i, point in enumerate(points):
    if i < 10:
        driver_points[i + 1] = point
    else:
        break

# Find the champion by comparing the total points earned by each driver
champion = max(driver_points, key=lambda x: driver_points[x])

# Output the winner's name
print("The winner is driver", champion)