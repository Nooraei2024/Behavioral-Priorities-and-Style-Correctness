import sys

def solve(n):
    # Initialize the graph with n vertices and n-1 edges
    graph = {i: set() for i in range(n)}
    for i in range(n):
        graph[i].add((i + 1) % n)
    
    # Read the conveyor belt directions from stdin
    for _ in range(n - 1):
        i, direction = map(int, sys.stdin.readline().split())
        if direction == "clockwise":
            graph[i].add((i + 1) % n)
        else:
            graph[i].add((i - 1) % n)
    
    # Find the start room and end room
    start = 0
    for i in range(n):
        if len(graph[i]) == 1:
            start = i
            break
    
    end = (start + 1) % n
    
    # Breadth-first search to find the shortest path from start to end
    queue = [start]
    visited = set()
    while queue:
        node = queue.pop(0)
        if node == end:
            break
        for neighbor in graph[node]:
            if neighbor not in visited:
                queue.append(neighbor)
                visited.add(neighbor)
    
    # Return the shortest path from start to end
    path = []
    while node != start:
        path.append(node)