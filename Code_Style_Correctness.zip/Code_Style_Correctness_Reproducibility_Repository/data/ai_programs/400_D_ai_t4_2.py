import sys

n = int(input())
k = len(sys.stdin.readline().split())
bacteria_types = {}
for i in range(1, n+1):
    bacteria_types[i] = []

for _ in range(k):
    line = sys.stdin.readline()
    type, count = line.split()
    for i in range(int(count)):
        bacteria_types[type].append(i)

# Move energy from some bacteria into some other one
energy_from = int(input())
energy_to = int(input())
if energy_from not in bacteria_types or energy_to not in bacteria_types:
    print("Invalid input")
else:
    # Move energy from energy_from to energy_to
    bacteria_types[energy_from].pop()
    bacteria_types[energy_to].append(energy_from)

# Print the current state of the bacteria
for type, bacteria in bacteria_types.items():
    print(f"{type}: {', '.join(map(str, bacteria))}")