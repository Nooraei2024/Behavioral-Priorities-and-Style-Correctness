import sys

n, m = map(int, input().split())
grid = []
for _ in range(n):
    grid.append([])
    for _ in range(m):
        grid[-1].append(0)

# Fill the grid with blue and yellow cells
for i in range(n):
    for j in range(m):
        if grid[i][j] == 0:
            grid[i][j] = 1

# Check if the grid is stupid
stupid = True
for i in range(n):
    blue_count = 0
    yellow_count = 0
    for j in range(m):
        if grid[i][j] == 1:
            blue_count += 1
        elif grid[i][j] == 2:
            yellow_count += 1
    if blue_count != 1 or yellow_count != 1:
        stupid = False
        break
for j in range(m):
    blue_count = 0
    yellow_count = 0
    for i in range(n):
        if grid[i][j] == 1:
            blue_count += 1
        elif grid[i][j] == 2:
            yellow_count += 1
    if blue_count != 1 or yellow_count != 1:
        stupid = False
        break

# Print the result
if stupid:
    print("YES")
else:
    print("NO")