import sys

# Read input from standard input
n = int(input())
p = list(map(int, input().split()))

# Calculate the total cost of all tickets
total_cost = sum(p)

# Calculate the x% of the total cost
x = 0.1
eco_restoration_cost = round(total_cost * x)

# Print the eco-restoration cost
print(eco_restoration_cost)