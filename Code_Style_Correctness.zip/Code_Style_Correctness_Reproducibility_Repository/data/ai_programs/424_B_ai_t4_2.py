import sys

# Read input from stdin
n = int(input())
coordinates = []
populations = []
for i in range(n):
    xi, yi, ki = map(int, input().split())
    coordinates.append((xi, yi))
    populations.append(ki)

# Calculate the minimum distance between each pair of points
distances = [[0 for _ in range(n)] for _ in range(n)]
for i in range(n):
    for j in range(n):
        if i == j:
            distances[i][j] = 0
        else:
            x1, y1 = coordinates[i]
            x2, y2 = coordinates[j]
            distances[i][j] = (x2-x1)**2 + (y2-y1)**2

# Find the minimum distance that connects two points and is less than or equal to ci
min_distance = 1000000000
for i in range(n):
    for j in range(n):
        if distances[i][j] <= populations[i] * populations[j]:
            min_distance = min(min_distance, distances[i][j])

# Output the minimum distance
print(min_distance)