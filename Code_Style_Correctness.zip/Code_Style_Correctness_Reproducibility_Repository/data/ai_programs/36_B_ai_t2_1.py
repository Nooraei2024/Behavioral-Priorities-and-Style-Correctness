import sys

# Read input from stdin
n = int(sys.stdin.readline())

# Initialize a list to store the black squares
black_squares = []

# Loop through each row and column of the graph paper
for i in range(n):
    for j in range(n):
        # Check if the current square is black
        if (i + j) % 2 == 0:
            black_squares.append((i, j))

# Initialize a list to store the fractal pattern
fractal = []

# Loop through each row and column of the graph paper
for i in range(n):
    for j in range(n):
        # Check if the current square is black
        if (i, j) in black_squares:
            fractal.append("1")
        else:
            fractal.append("0")

# Print the fractal pattern
print("".join(fractal))