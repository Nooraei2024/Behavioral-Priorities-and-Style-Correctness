import sys

# Read input from stdin
n = int(input())
pipes = []
for _ in range(n):
    pipes.append([int(x) for x in input().split()])

# Initialize the tanks and taps
tanks = [0] * n
taps = [0] * n

# Fill the tanks with water from the pipes
for i in range(n):
    if pipes[i][1] == 1:
        tanks[i] += pipes[i][2]

# Check if there is enough water to fill all the taps
for i in range(n):
    if tanks[i] < taps[i]:
        print("No")
        sys.exit()

print("Yes")