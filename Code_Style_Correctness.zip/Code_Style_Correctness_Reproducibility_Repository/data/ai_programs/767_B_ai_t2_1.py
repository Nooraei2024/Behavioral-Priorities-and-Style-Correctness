import sys

# Read input from stdin
ts = int(sys.stdin.readline())
tf = int(sys.stdin.readline())

# Calculate the number of minutes until midnight
midnight = 24 * 60
minutes_until_midnight = (midnight - ts) % midnight

# Calculate the number of minutes after midnight when the receptionist closes
closing_time = tf + minutes_until_midnight

# Print the result
print(closing_time)