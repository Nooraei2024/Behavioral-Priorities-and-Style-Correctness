import sys

def f(l, r):
    return sorted(filter(lambda x: l <= x <= r, a))

a = list(map(int, input().split()))
x = int(input())

count = 0
for i in range(1, x+1):
    if f(i, i) == sorted(a, reverse=True):
        count += 1

print(count)