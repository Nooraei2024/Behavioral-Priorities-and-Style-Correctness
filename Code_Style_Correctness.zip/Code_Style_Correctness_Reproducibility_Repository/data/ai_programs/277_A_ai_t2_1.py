import sys

# Read input from stdin
n, m = map(int, sys.stdin.readline().split())
languages = []
for _ in range(n):
    languages.append(list(map(int, sys.stdin.readline().split())))

# Calculate the minimum number of lessons needed to learn all official languages
min_lessons = 0
for employee in languages:
    for language in employee:
        min_lessons += max(language - len(employee), 0)

# Print the result
print(min_lessons)