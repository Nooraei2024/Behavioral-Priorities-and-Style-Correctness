import sys

n, k = map(int, input().split())
soldiers = list(range(1, n + 1))

# Create a schedule for each day
schedule = []
for i in range(k):
    # Choose the next soldier to work and remove him from the list
    soldier = soldiers.pop(0)
    # Add the soldier to the current day's schedule
    schedule.append(soldier)

# Output the schedule
print(*schedule, sep='\n')