import sys

# Read input from stdin
n = int(input())
arr = list(map(int, input().split()))

# Find the index of the element to replace
idx = arr.index(max(arr))

# Replace the element with a new number
new_num = (idx + 1) % 109 + 1
arr[idx] = new_num

# Sort the array
arr.sort()

# Output the sorted array
print(*arr, sep=' ')