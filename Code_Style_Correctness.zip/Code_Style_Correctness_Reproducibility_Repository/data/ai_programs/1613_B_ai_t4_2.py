import sys

n = int(input())
a = list(map(int, input().split()))

# initialize a set to store the pairs
pairs = set()

# loop through each element in the array
for i in range(len(a)):
    # get the remainder of dividing the current element by 2
    rem = a[i] % 2
    # if the remainder is not 0, it means that the current element is odd
    if rem != 0:
        # find the next even number after the current element
        even = (a[i] // 2) * 2
        # check if the next even number is in the array
        if even in a:
            # add the pair to the set of pairs
            pairs.add((a[i], even))

# print the pairs
print(list(pairs))