import re

def log_stream_analysis(logs):
    pattern = r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}:[a-zA-Z!.,? ]+$"
    valid_logs = []
    for log in logs:
        if re.match(pattern, log):
            valid_logs.append(log)
    return valid_logs

if __name__ == "__main__":
    logs = [
        "2012-01-01 00:00:00:This is a message.",
        "2012-01-01 00:00:00:This is another message!",
        "2012-01-01 00:00:00:This is a third message,",
        "2012-01-01 00:00:00:This is a fourth message.",
        "2012-01-01 00:00:00:This is a fifth message?",
        "2012-01-01 00:00:00:This is a sixth message."
    ]
    print(log_stream_analysis(logs))