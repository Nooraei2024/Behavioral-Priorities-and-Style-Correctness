import sys

def growing_flowers(input_string):
    flowers = []
    for word in input_string.split():
        if word[0].isupper():
            flowers.append(word)
    return "".join(flowers)

if __name__ == "__main__":
    input_string = sys.stdin.readline()
    output_string = growing_flowers(input_string)
    print(output_string)