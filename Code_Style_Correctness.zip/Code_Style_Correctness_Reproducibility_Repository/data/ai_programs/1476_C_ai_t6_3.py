import sys

def longest_simple_cycle(chains):
    n = len(chains)
    result = 0
    for i in range(1, n):
        chain = chains[i]
        a = chain[0]
        b = chain[-1]
        if a == b:
            continue
        for j in range(1, len(chain)):
            if chain[j] == a or chain[j] == b:
                result += 1
    return result

if __name__ == "__main__":
    input = sys.stdin.readline()
    chains = [list(map(int, input.split())) for _ in range(int(input))]
    print(longest_simple_cycle(chains))