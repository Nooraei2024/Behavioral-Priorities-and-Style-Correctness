import sys
input = sys.stdin.readline().strip()
grid = []
for i in range(len(input)):
    grid.append([])
    for j in range(len(input[i])):
        if input[i][j] == '.':
            grid[i].append(True)
        else:
            grid[i].append(False)

def is_exitable(grid, i, j):
    if i < 0 or j < 0 or i >= len(grid) or j >= len(grid[0]):
        return False
    if grid[i][j]:
        return False
    if grid[i-1][j-1] and grid[i-1][j] and grid[i][j-1]:
        return True
    else:
        return False

def find_exitables(grid):
    exitables = []
    for i in range(len(grid)):
        for j in range(len(grid[0])):
            if is_exitable(grid, i, j):
                exitables.append((i, j))
    return exitables

exitables = find_exitables(grid)
print(*exitables, sep='\n')