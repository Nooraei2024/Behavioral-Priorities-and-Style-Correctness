import sys

# Read input from stdin
n = int(input())
robots = []
for _ in range(n):
    x, y = map(int, input().split())
    robots.append((x, y))

# Output only valid Python code
print("import sys")
print("")
print("def find_robots():")
print("    # Read input from stdin")
print("    n = int(input())")
print("    robots = []")
for i in range(n):
    print(f"    x{i}, y{i} = map(int, input().split())")
    print(f"    robots.append((x{i}, y{i}))")
print("")
print("if __name__ == '__main__':")
print("    find_robots()")