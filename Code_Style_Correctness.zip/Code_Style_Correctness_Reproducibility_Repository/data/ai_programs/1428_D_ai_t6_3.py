import sys

n = int(input())
grid = []
for i in range(n):
    grid.append([])
    for j in range(n):
        grid[i].append(-1)

targets = 0
for i in range(n):
    for j in range(n):
        if grid[i][j] == -1:
            targets += 1

print(targets)