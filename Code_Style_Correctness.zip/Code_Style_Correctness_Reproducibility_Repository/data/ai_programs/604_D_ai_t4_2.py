#!/usr/bin/env python

import sys

def solve(k, p):
    """
    Given k and p, find the value of <image> for any integer x in the range 0 to p - 1, inclusive.
    """
    # Initialize the result as 0
    result = 0
    
    # Iterate through all possible values of x
    for x in range(p):
        # Calculate the value of <image> at this x
        image_val = (k * x) % p
        
        # Add the result to the total
        result += image_val
    
    # Return the final result
    return result

# Read input from standard input
input_string = sys.stdin.readline().strip()

# Extract k and p from the input string
k, p = map(int, input_string.split())

# Call the solve function with k and p as arguments
result = solve(k, p)

# Print the result
print(result)