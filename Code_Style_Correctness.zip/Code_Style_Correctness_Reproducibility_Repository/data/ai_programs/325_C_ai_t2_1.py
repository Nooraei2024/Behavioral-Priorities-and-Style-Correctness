import sys

# Read input from stdin
n = int(sys.stdin.readline().strip())
monsters = []
diamonds = 0

# Initialize the first monster
monsters.append((1, 1))

# Feed pies to monsters until no more diamonds are produced
while diamonds < n:
    # Get the current number of monsters and diamonds
    num_monsters = len(monsters)
    num_diamonds = diamonds

    # Feed a pie to each monster
    for i in range(num_monsters):
        monster, color = monsters[i]
        if color == 1:
            # If the monster is color 1, it will split into two monsters with colors 2 and 3
            monsters.append((monster + 1, 2))
            monsters.append((monster + 1, 3))
        else:
            # If the monster is not color 1, it will produce one diamond
            diamonds += 1

# Output the final number of monsters and diamonds
print(num_monsters)
print(num_diamonds)