import sys

# Read input from standard input
n = int(input())
board = []
for _ in range(n):
    board.append([int(x) for x in input().split()])

# Calculate the total weight of each row
row_weights = [sum(r) for r in board]

# Calculate the total weight of each column
col_weights = [sum(c) for c in zip(*board)]

# Find the maximum weight in each row and column
max_row_weight = max(row_weights)
max_col_weight = max(col_weights)

# If the maximum weight in a row is greater than the maximum weight in a column, then A's position is stronger
if max_row_weight > max_col_weight:
    print("A")
# Otherwise, B's position is stronger
else:
    print("B")