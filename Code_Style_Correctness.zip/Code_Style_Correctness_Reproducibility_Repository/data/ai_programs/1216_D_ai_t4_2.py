import sys

# Read input from stdin
n, x = map(int, input().split())
y, z = map(int, input().split())

# Initialize a dictionary to store the number of swords of each type
sword_types = {}
for i in range(1, n+1):
    sword_types[i] = x

# Update the dictionary with the number of swords taken by each person
for _ in range(y):
    type_, num = map(int, input().split())
    sword_types[type_] -= num

# Print the final number of swords of each type
print(*sword_types.values(), sep='\n')