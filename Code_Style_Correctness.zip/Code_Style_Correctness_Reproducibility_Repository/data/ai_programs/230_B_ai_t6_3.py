import sys

def is_t_prime(n):
    if n == 1:
        return False
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True

if __name__ == "__main__":
    n = int(input())
    for i in range(n):
        x = int(input())
        print("T-prime" if is_t_prime(x) else "Not T-prime")