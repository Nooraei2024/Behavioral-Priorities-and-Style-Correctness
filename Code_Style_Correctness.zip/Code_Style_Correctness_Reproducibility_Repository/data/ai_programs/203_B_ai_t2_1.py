import sys

# Read input from standard input (stdin)
n, m = map(int, sys.stdin.readline().split())

# Initialize a list to store the coordinates of the black squares
black_squares = []

# Loop through each move and check if the current square is a black square with side 3
for i in range(m):
    x, y = map(int, sys.stdin.readline().split())
    if (x + 1) % 3 == 0 and (y + 1) % 3 == 0:
        black_squares.append((x, y))

# Print the number of moves required to paint a black square with side 3
print(len(black_squares))