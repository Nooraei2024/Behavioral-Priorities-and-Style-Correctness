import sys

n = int(input())
a = list(map(int, input().split()))

# Find the maximum sum of elements on even positions
max_sum = 0
for i in range(n):
    if i % 2 == 0:
        max_sum += a[i]

# Reverse the subarray with the maximum sum on even positions
subarray_start = -1
subarray_end = -1
max_sum_on_even = 0
for i in range(n):
    if i % 2 == 0:
        max_sum_on_even += a[i]
        if max_sum_on_even > max_sum:
            subarray_start = i - (max_sum_on_even - max_sum)
            subarray_end = i
            max_sum = max_sum_on_even

# Print the reversed subarray
print(a[subarray_start:subarray_end][::-1])