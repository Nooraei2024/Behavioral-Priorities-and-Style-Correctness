import math

n, s = map(int, input().split())
boxes = []
for i in range(n):
    boxes.append(list(map(int, input().split())))

# Calculate the number of ways to select flowers from each box
ways = [0] * n
for i in range(n):
    ways[i] = math.comb(boxes[i][0], s)
    for j in range(1, len(boxes[i])):
        ways[i] += math.comb(boxes[i][j], s)

# Calculate the total number of ways to select flowers from all boxes
total = 1
for i in range(n):
    total *= ways[i]

print(total % (10**9 + 7))