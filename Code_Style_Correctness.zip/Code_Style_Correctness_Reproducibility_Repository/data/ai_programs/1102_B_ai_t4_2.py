import sys

def array_k_coloring(a):
    n = len(a)
    k = max(a)
    coloring = [0] * (n + 1)
    for i in range(1, k + 1):
        if any(j == i for j in a):
            coloring[i] = 1
    if sum(coloring) < n:
        return "NO"
    else:
        return "YES"

if __name__ == "__main__":
    input_data = sys.stdin.read()
    a = list(map(int, input_data.split()))
    print(array_k_coloring(a))