import sys

# Read input from stdin
s = sys.stdin.readline().strip()

# Find the longest substring t that is a prefix of s and also a suffix of s
t = ""
for i in range(len(s)):
    for j in range(i, len(s)):
        if s[i:j+1] == s[i:j+1][::-1]:
            t = s[i:j+1]
            break
    if t != "":
        break

# Print the result
print(t)