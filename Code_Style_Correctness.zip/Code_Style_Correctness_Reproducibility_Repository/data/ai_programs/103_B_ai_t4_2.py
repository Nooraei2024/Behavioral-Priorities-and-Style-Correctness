import sys

# Read input from stdin
input_string = sys.stdin.readline().strip()

# Parse input string into a dictionary
input_dict = eval(input_string)

# Extract relevant information from the dictionary
seismic_activity = input_dict["seismic_activity"]
weather_conditions = input_dict["weather_conditions"]
satellite_shots = input_dict["satellite_shots"]

# Calculate the probability of Cthulhu appearing based on the input data
probability = 0.5 * seismic_activity + 0.3 * weather_conditions - 0.2 * satellite_shots

# Output the calculated probability
print(f"Probability of Cthulhu appearing: {probability}")