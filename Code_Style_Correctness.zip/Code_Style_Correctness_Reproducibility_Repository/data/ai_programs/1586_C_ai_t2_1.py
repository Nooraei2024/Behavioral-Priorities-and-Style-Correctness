import sys

def is_exitable(grid):
    m = len(grid)
    n = len(grid[0])
    visited = [[False for _ in range(n)] for _ in range(m)]
    queue = [(0, 0)]
    while queue:
        i, j = queue.pop()
        if visited[i][j]:
            continue
        visited[i][j] = True
        if i == m - 1 or j == n - 1:
            return True
        for di, dj in [(0, -1), (0, 1), (-1, 0), (1, 0)]:
            ni, nj = i + di, j + dj
            if 0 <= ni < m and 0 <= nj < n and not visited[ni][nj] and grid[ni][nj] == ".":
                queue.append((ni, nj))
    return False

if __name__ == "__main__":
    input = sys.stdin.readline
    while True:
        try:
            grid = [list(input().strip()) for _ in range(10)]
            if is_exitable(grid):
                print("YES")
            else:
                print("NO")
        except EOFError:
            break