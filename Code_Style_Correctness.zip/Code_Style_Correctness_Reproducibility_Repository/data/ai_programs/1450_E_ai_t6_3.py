import sys

# Read input from stdin
n, m = map(int, sys.stdin.readline().split())
edges = []
for _ in range(m):
    edges.append(list(map(int, sys.stdin.readline().split())))

# Initialize the income array
incomes = [0] * n
for i in range(n):
    incomes[i] = int(sys.stdin.readline())

# Check if the society is capitalist
is_capitalist = True
for i in range(n-1):
    for j in range(i+1, n):
        if incomes[edges[i][0]] + 1 == incomes[edges[j][1]] and incomes[edges[j][0]] + 1 == incomes[edges[i][1]]:
            is_capitalist = False
            break
    if not is_capitalist:
        break

# Print the result
print("YES" if is_capitalist else "NO")