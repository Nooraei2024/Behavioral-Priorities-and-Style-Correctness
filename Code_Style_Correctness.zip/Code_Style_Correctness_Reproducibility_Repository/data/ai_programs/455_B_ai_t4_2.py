import sys

def get_strings(n):
    return [input() for _ in range(n)]

def is_prefix(word1, word2):
    return word1.startswith(word2)

def play_game(k, strings):
    word = ""
    player = 0
    while k > 0:
        if not is_prefix(word, strings[player]):
            player ^= 1
            continue
        word += strings[player][-1]
        player ^= 1
        k -= 1
    return "Andrew" if player == 0 else "Alex"

n = int(input())
strings = get_strings(n)
print(play_game(k, strings))