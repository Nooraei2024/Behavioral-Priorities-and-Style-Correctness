import sys

# Read input from stdin
n = int(input())

# Initialize variables to keep track of weights
queen_weight = 0
rook_weight = 0
bishop_weight = 0
knight_weight = 0
pawn_weight = 0

# Loop through each chess piece and calculate its weight
for i in range(n):
    # Read the type of chess piece (queen, rook, bishop, knight or pawn)
    piece_type = input().lower()
    
    # Calculate the weight of the chess piece based on its type
    if piece_type == "queen":
        queen_weight += 9
    elif piece_type == "rook":
        rook_weight += 5
    elif piece_type == "bishop":
        bishop_weight += 3
    elif piece_type == "knight":
        knight_weight += 3
    else:
        pawn_weight += 1

# Calculate the total weight of all chess pieces
total_weight = queen_weight + rook_weight + bishop_weight + knight_weight + pawn_weight

# Print the result
print(total_weight)