import sys

def process_sentence(sentence):
    # Convert all letters of the sentence to lowercase
    sentence = sentence.lower()
    
    # Reverse each of the words of the sentence individually
    words = sentence.split()
    reversed_words = [word[::-1] for word in words]
    sentence = " ".join(reversed_words)
    
    # Remove all spaces from the sentence
    sentence = sentence.replace(" ", "")
    
    return sentence

# Read input from standard input (stdin)
sentence = sys.stdin.readline().strip()

# Process the sentence using the cipher technique
processed_sentence = process_sentence(sentence)

# Write output to standard output (stdout)
print(processed_sentence)