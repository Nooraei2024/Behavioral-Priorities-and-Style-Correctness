import sys

# Read input from stdin
input_string = sys.stdin.readline().strip()

# Split input string into a list of integers representing driver positions
driver_positions = [int(x) for x in input_string.split()]

# Initialize dictionary to store driver points and wins
drivers = {}

# Iterate over driver positions and update driver points and wins
for position in driver_positions:
    if position <= 10:
        drivers[position] = drivers.get(position, 0) + 25 - position
    else:
        drivers[position] = drivers.get(position, 0) + 18 - position

# Sort dictionary by value (points) in descending order
sorted_drivers = sorted(drivers.items(), key=lambda x: x[1], reverse=True)

# Get the driver with most points and wins
champion = sorted_drivers[0][0]

# Print champion
print(champion)