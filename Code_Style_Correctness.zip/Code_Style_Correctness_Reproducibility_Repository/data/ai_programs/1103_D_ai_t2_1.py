import sys

n, k = map(int, input().split())
a = list(map(int, input().split()))
e = list(map(int, input().split()))

# Calculate the total uncertainty and experience of all judges
total_uncertainty = sum(a)
total_experience = sum(e)

# Calculate the probability of passing the exam for each judge
p = [((k - a[i]) / (n - 1)) * e[i] / total_experience for i in range(n)]

# Output the highest probability of passing the exam
print(max(p))