import sys

n, m = map(int, input().split())
matrix = [[0] * m for _ in range(n)]

for i in range(n):
    for j in range(m):
        matrix[i][j] = int(input())

def nullify_matrix():
    for i in range(n):
        for j in range(m):
            if matrix[i][j] != 0:
                matrix[i][j] -= 1

nullify_matrix()

for row in matrix:
    print(*row, sep=' ')