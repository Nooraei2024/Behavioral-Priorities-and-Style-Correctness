import sys

# Read input from stdin
n, k = map(int, sys.stdin.readline().split())
soldiers = list(map(int, sys.stdin.readline().split()))

# Sort the soldiers by their number in descending order
soldiers.sort(reverse=True)

# Initialize a list to store the scheduled days
scheduled_days = []

# Loop through each day of the demonstration
for i in range(k):
    # Check if the current soldier is available on that day
    if soldiers[0] == i + 1:
        # If so, schedule them to work on that day
        scheduled_days.append(i + 1)
        # Remove the soldier from the list as they have been scheduled
        soldiers.pop(0)
    else:
        # If not, add a placeholder for the soldier
        scheduled_days.append(-1)

# Print the scheduled days
print(*scheduled_days, sep='\n')