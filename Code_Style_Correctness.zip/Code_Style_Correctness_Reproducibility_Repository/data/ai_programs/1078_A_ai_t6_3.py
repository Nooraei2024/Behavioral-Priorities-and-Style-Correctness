import sys

# Read input from stdin
A = tuple(map(int, input().split()))
B = tuple(map(int, input().split()))

# Calculate the distance between A and B
distance = abs(A[0] - B[0]) + abs(A[1] - B[1])

# Check if the points are on the avenue
if A[0] * B[1] + B[0] * A[1] == 0:
    # If they are on the avenue, add the distance to the diagonal
    distance += abs(A[0] - B[0])

# Print the result
print(distance)