import sys

# Read input from stdin
input_string = sys.stdin.readline().strip()

# Split the input string into a list of characters
puppies = list(input_string)

# Create a dictionary to map each color to its index in the alphabet
color_map = {chr(i + ord('a')): i for i in range(26)}

# Initialize the output string
output_string = ""

# Iterate over the puppies and recolor them according to the committee's rules
for puppy in puppies:
    # Get the index of the current puppy's color in the alphabet
    current_index = color_map[puppy]
    
    # Calculate the new index based on the committee's rules
    new_index = (current_index + 1) % 26
    
    # Get the new color of the puppy
    new_color = chr(new_index + ord('a'))
    
    # Add the new color to the output string
    output_string += new_color

# Print the output string
print(output_string)