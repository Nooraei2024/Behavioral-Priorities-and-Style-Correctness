import sys

# Read input from stdin
T = sys.stdin.readline().strip()
S = sys.stdin.readline().strip()
A = ""

# Initialize variables
m, n = len(T), len(S)
magic_spells = [i for i in range(m) if T[:i+1] == S[:i+1]]

# Check if A is a magic spell
if A in magic_spells:
    print("Yes")
else:
    print("No")