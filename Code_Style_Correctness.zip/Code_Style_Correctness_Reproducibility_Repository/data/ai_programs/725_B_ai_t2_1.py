import sys

# Read input from standard input (stdin)
n = int(input())
seats = []
for i in range(1, n+1):
    row = input()
    seats.append([])
    for j in range(0, 6):
        seat = row[j]
        if seat == 'a' or seat == 'f':
            seats[-1].append((i, j))
        elif seat == 'c' or seat == 'd':
            seats[-1].append((i, j+2))
        else:
            seats[-1].append((i, j+1))

# Output only valid Python code
print(seats)