import sys

n = int(input())
a = list(map(int, input().split()))

# Initialize a dictionary to store the pairs
pairs = {}

# Iterate over the elements of the array
for i in range(n):
    for j in range(i+1, n):
        # If the remainder is 0, it means that x and y are equal
        if a[i] % a[j] == 0:
            continue
        
        # If the remainder is not 0, it means that x and y are different
        pairs[(a[i], a[j])] = True

# Print the number of pairs
print(len(pairs))