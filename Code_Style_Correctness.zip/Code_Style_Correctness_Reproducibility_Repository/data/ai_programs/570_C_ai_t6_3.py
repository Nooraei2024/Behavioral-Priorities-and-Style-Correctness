import sys

def replace_periods(string):
    """
    Replaces all consecutive periods (..) in a string with a single period (.),
    starting from the first occurrence of two consecutive periods.

    Args:
        string (str): The input string to be processed.

    Returns:
        str: The modified string with all consecutive periods replaced.
    """
    while True:
        index = string.find("..")
        if index == -1:
            break
        string = string[:index] + "." + string[index+2:]
    return string

if __name__ == "__main__":
    s = sys.stdin.readline().strip()
    print(replace_periods(s))