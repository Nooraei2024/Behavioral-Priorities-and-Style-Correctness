import sys

def is_multihedgehog(G):
    # Check if G is a hedgehog
    if len(G) == 1 and G[0].degree() >= 3:
        return True
    elif len(G) > 1 and all(v.degree() == 1 for v in G):
        return True
    else:
        return False

def make_multihedgehog(G, k):
    # Create a new graph with k-1 copies of G
    H = []
    for _ in range(k-1):
        H.append(G)
    return H

if __name__ == "__main__":
    # Read input from standard input
    N, M = map(int, sys.stdin.readline().split())
    G = []
    for _ in range(M):
        u, v = map(int, sys.stdin.readline().split())
        G.append((u, v))
    
    # Check if G is a hedgehog
    if not is_multihedgehog(G):
        print("Invalid input")
        exit(1)
    
    # Make k-multihedgehog
    H = make_multihedgehog(G, 2)
    
    # Print output to standard output
    for h in H:
        print(*h, sep=" ")