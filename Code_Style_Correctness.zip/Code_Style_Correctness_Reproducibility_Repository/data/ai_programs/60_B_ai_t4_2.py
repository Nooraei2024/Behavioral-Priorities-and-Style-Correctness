import sys

# Read input from stdin
input_string = sys.stdin.readline().strip()

# Split the input string into a list of integers representing the dimensions of the plate
dimensions = [int(x) for x in input_string.split(' ')]

# Initialize an empty grid to represent the plate
grid = [[['.' for _ in range(dimensions[1])] for _ in range(dimensions[2])] for _ in range(dimensions[0])]

# Fill the grid with obstacles
for i in range(dimensions[0]):
    for j in range(dimensions[1]):
        for k in range(dimensions[2]):
            if input_string[i * dimensions[1] * dimensions[2] + j * dimensions[2] + k] == '#':
                grid[i][j][k] = '#'

# Fill the grid with water
for i in range(dimensions[0]):
    for j in range(dimensions[1]):
        if grid[i][j][0] != '#':
            grid[i][j][:] = ['~'] * dimensions[2]

# Print the final grid
print('\n'.join([' '.join(row) for row in grid]))