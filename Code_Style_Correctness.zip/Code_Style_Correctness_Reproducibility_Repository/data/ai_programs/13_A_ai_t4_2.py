import math

def solve(A):
    sum = 0
    for i in range(2, A + 1):
        n = int(str(i), 16)
        sum += sum_digits(n)
    return sum / (A - 1)

def sum_digits(n):
    result = 0
    while n > 0:
        result += n % 10
        n //= 10
    return result

print(solve(int(input())))