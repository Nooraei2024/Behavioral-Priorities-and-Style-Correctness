import sys

# Read input from stdin
n = int(input())
a = list(map(int, input().split()))

# Initialize scores to 0
koa_score = 0
best_friend_score = 0

# Loop through the array and perform moves
for i in range(n):
    # Choose an element from the array
    chosen_element = a[i]
    
    # Remove the chosen element from the array
    del a[i]
    
    # Xor the chosen element with the current score of the player
    koa_score ^= chosen_element
    
    # Update the scores
    best_friend_score = 0 if i % 2 == 0 else chosen_element
    
# Output the final scores
print(koa_score, best_friend_score)