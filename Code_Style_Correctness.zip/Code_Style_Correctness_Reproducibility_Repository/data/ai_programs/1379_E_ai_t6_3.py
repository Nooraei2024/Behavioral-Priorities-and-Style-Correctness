import sys

n = int(input())
s = list(map(int, input().split()))

# Initialize the parents dictionary
parents = {}
for i in range(1, n+1):
    if s[i]:
        parents[i] = [s[i]]
    else:
        parents[i] = []

# Initialize the children dictionary
children = {}
for i in range(1, n+1):
    if parents[i]:
        for parent in parents[i]:
            if parent not in children:
                children[parent] = [i]
            else:
                children[parent].append(i)

# Find the special person
special_person = None
for i in range(1, n+1):
    if not parents[i]:
        special_person = i
        break

# Traverse the genealogy tree to find the inverse
inverse = []
current_person = special_person
while current_person:
    inverse.append(current_person)
    if children[current_person]:
        current_person = children[current_person][0]
    else:
        current_person = None

print(*inverse, sep='\n')