import sys

n, q = map(int, input().split())
nodes = []
for _ in range(n):
    nodes.append(list(map(int, input().split())))
queries = []
for _ in range(q):
    queries.append(list(map(int, input().split())))

def find_centroid(node, parent):
    if node == parent:
        return None
    for child in nodes[node]:
        centroid = find_centroid(child, node)
        if centroid is not None:
            return centroid
    return node

for query in queries:
    vi = query[0] - 1
    vj = query[1] - 1
    centroid = find_centroid(vi, vi)
    print(centroid + 1 if centroid is not None else -1)