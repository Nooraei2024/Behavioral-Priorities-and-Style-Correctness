import sys

n = int(input())
cities = []
for i in range(n):
    xi, yi, ki = map(int, input().split())
    cities.append((xi, yi, ki))

max_population = 0
max_index = -1
for i, (xi, yi, ki) in enumerate(cities):
    if max_population < ki:
        max_population = ki
        max_index = i

ci = int(input())
if ci > max_population:
    print("NO")
else:
    print("YES")