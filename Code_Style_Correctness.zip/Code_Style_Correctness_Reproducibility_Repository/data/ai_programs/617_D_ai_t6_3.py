import sys

def solve(points):
    # Sort the points by their x-coordinates
    sorted_points = sorted(points, key=lambda p: p[0])

    # Initialize the minimum number of segments to 3 (the three initial points)
    min_segments = 3

    # Loop through the sorted points and check for self-intersections and self-touches
    for i in range(len(sorted_points) - 1):
        p1, p2 = sorted_points[i], sorted_points[i + 1]

        # Check if the line segment between the current point and the next point intersects with any previous points
        for j in range(i + 2, len(sorted_points)):
            p3 = sorted_points[j]

            # If the line segments intersect, increase the minimum number of segments by 1
            if do_segments_intersect(p1, p2, p3):
                min_segments += 1

    return min_segments

def do_segments_intersect(p1, p2, p3):
    # Check if the lines are parallel
    if p1[0] == p2[0] or p3[0] == p1[0]:
        return False

    # Calculate the slope and y-intercept of the two lines
    m1 = (p2[1] - p1[1]) / (p2[0] - p1[0])
    c1 = p