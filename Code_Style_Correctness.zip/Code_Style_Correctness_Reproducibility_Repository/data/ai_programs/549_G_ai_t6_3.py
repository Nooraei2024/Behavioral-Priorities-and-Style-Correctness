import sys

# Read input from stdin
n = int(input())
costs = list(map(int, input().split()))

# Initialize variables for the minimum cost and the maximum profit
min_cost = 0
max_profit = 0

# Loop through each person's costs
for i in range(n):
    # Calculate the cost of swapping with the current person
    swap_cost = max(costs[i], min_cost) - costs[i]
    
    # Update the minimum cost and maximum profit
    min_cost = min(min_cost, costs[i])
    max_profit = max(max_profit, swap_cost)

# Output the maximum profit
print(max_profit)