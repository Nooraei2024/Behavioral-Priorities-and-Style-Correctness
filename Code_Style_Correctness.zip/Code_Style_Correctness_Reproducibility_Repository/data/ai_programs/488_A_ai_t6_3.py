import sys

# Read input from stdin
n = int(sys.stdin.readline())

# Calculate the number of floors with "8" in their decimal notation
num_floors = 0
for i in range(1, n+1):
    if str(i).count("8") > 0:
        num_floors += 1

# Print the result
print(num_floors)