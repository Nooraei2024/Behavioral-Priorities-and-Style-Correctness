import sys

# Read input from stdin
n = int(input())
k = int(input())
bacteria_types = [list(map(int, input().split())) for _ in range(k)]

# Initialize a dictionary to store the number of bacteria of each type
bacteria_count = {}
for i in range(k):
    bacteria_count[i + 1] = bacteria_types[i][0]

# Initialize a dictionary to store the energy of each bacteria
bacteria_energy = {}
for i in range(n):
    bacteria_energy[i + 1] = 0

# Loop through all the bacteria and their energies
for i in range(n):
    for j in range(k):
        # If the current bacteria is of type j, add its energy to the total energy of that type
        if i + 1 in bacteria_types[j - 1]:
            bacteria_energy[j] += bacteria_energy[i + 1]

# Print the maximum energy that Dima can obtain
print(max(bacteria_energy.values()))