import math

def is_tprime(n):
    if n == 1:
        return False
    divisors = []
    for i in range(2, int(math.sqrt(n)) + 1):
        if n % i == 0:
            divisors.append(i)
            if len(divisors) == 3:
                break
    return len(divisors) == 3

if __name__ == '__main__':
    n = int(input())
    numbers = [int(x) for x in input().split()]
    for number in numbers:
        print("True" if is_tprime(number) else "False")