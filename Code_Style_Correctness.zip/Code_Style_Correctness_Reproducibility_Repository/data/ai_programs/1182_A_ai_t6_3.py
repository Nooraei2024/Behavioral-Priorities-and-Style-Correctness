import sys

def solve(n):
    # Initialize a 2D array to store the number of ways to fill each tile
    dp = [[0] * (3*n+1) for _ in range(3*n+1)]
    
    # Initialize the first row and column with 1, as there is only one way to fill an empty tile
    dp[0][0] = 1
    
    # Loop through each tile and calculate the number of ways to fill it based on the previous tiles
    for i in range(3*n+1):
        for j in range(i, 3*n+1, 3):
            dp[i][j] = dp[i-1][j-1] + dp[i-1][j] + dp[i-1][j+1]
    
    # Return the number of ways to fill all tiles
    return dp[-1][-1]

if __name__ == "__main__":
    n = int(input())
    print(solve(n))