import sys

# Read input from standard input
n, m = map(int, sys.stdin.readline().split())
shaded_squares = []
for _ in range(n):
    shaded_squares.append(list(map(int, sys.stdin.readline().split())))

# Calculate the number of shaded squares
num_shaded_squares = 0
for row in shaded_squares:
    for square in row:
        if square == 1:
            num_shaded_squares += 1

# Print the minimum cost to send the picture
print(num_shaded_squares * 0.5)