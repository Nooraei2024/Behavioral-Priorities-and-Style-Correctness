import sys

def solve(a):
    steps = 0
    while a != '':
        i = 1
        while i < len(a) and a[i-1] == a[i]:
            i += 1
        if i == len(a):
            break
        steps += 1
        a = a[:i] + a[i+1:]
    return steps

if __name__ == '__main__':
    input_string = sys.stdin.readline().strip()
    print(solve(input_string))