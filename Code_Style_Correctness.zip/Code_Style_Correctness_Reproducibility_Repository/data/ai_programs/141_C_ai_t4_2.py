import sys

n = int(sys.stdin.readline())
heights = []
for i in range(n):
    heights.append(int(sys.stdin.readline()))

seated_order = []
for i in range(n):
    seated_order.append(i)

# shuffle the order of the people sitting down
import random
random.shuffle(seated_order)

# calculate the number of taller people in front of each person
tallers = [0] * n
for i in range(n):
    for j in range(i+1, n):
        if heights[j] > heights[i]:
            tallers[i] += 1

# print the output
print(*seated_order, sep='\n')