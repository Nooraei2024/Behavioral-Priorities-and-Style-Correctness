import sys

# Read input from standard input
n = int(input())
berland_dollars = list(map(int, input().split()))

# Initialize a dictionary to store the number of times each dollar amount is seen
dollar_counts = {}
for dollar in berland_dollars:
    if dollar not in dollar_counts:
        dollar_counts[dollar] = 1
    else:
        dollar_counts[dollar] += 1

# Find the maximum number of times a dollar amount is seen
max_count = max(dollar_counts.values())

# Initialize an array to store the indices of the people who have the maximum number of times their dollar amount is seen
indices = []
for i, count in enumerate(dollar_counts.values()):
    if count == max_count:
        indices.append(i)

# Output the indices of the people who have the maximum number of times their dollar amount is seen
print(*indices, sep='\n')