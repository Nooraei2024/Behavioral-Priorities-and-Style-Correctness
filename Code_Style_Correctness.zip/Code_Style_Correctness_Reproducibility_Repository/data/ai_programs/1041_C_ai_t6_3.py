import sys

# Read input from stdin
m = int(input())
n = int(input())
a = list(map(int, input().split()))

# Calculate the maximum number of coffee breaks that Monocarp can take
max_coffee_breaks = m // (n + 1)

# Check if there are any coffee breaks that fall on a day when Monocarp is not allowed to take a break
for i in range(n):
    if a[i] % (n + 1) == 0:
        max_coffee_breaks -= 1

# Print the maximum number of coffee breaks that Monocarp can take
print(max_coffee_breaks)