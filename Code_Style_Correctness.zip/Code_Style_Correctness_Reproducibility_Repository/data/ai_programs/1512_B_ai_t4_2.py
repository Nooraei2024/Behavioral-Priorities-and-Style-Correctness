import sys

n = int(input())
field = []
for i in range(n):
    field.append([])
    for j in range(n):
        field[i].append('.')

# Mark two cells as '*'
field[0][1] = '*'
field[2][3] = '*'

# Check if the marked cells form a rectangle with sides parallel to the coordinate axes
if (field[0][1] == '*' and field[2][3] == '*') or (field[0][3] == '*' and field[2][1] == '*'):
    print("YES")
else:
    print("NO")