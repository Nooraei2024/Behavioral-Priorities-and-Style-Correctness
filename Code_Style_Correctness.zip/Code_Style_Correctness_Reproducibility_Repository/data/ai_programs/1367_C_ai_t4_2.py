import sys

# Read input from stdin
n, k = map(int, sys.stdin.readline().split())
tables = list(sys.stdin.readline().strip())

# Initialize a set to keep track of occupied tables
occupied_tables = set()

# Iterate through the tables and find the first available table that is k or more away from an occupied table
for i in range(n):
    if tables[i] == "1" and len(occupied_tables) > 0:
        # Check if the current table is k or more away from any of the occupied tables
        for j in occupied_tables:
            if abs(i - j) >= k:
                break
        else:
            # If no table is found, then this table is available
            print(i + 1)
            occupied_tables.add(i)
    elif tables[i] == "0":
        # Add the current table to the set of occupied tables
        occupied_tables.add(i)