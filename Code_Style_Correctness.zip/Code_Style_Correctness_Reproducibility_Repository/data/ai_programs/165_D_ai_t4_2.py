import sys

# Read input from stdin
n = int(sys.stdin.readline())
edges = []
for _ in range(n - 1):
    edges.append(list(map(int, sys.stdin.readline().split())))

# Initialize the graph with all edges black
graph = [[0] * n for _ in range(n)]
for edge in edges:
    graph[edge[0] - 1][edge[1] - 1] = 1
    graph[edge[1] - 1][edge[0] - 1] = 1

# Check if the graph is a beard graph
is_beard = True
for i in range(n):
    degree = 0
    for j in range(n):
        if graph[i][j]:
            degree += 1
    if degree > 2:
        is_beard = False
        break

# Output the result
if is_beard:
    print("YES")
else:
    print("NO")