import sys

n = int(input())
black_squares = set()
for i in range(n):
    for j in range(n):
        if sys.stdin.readline().strip() == '1':
            black_squares.add((i, j))

def paint_fractal(paper, black_squares):
    n = len(paper)
    for i in range(n):
        for j in range(n):
            if (i, j) in black_squares:
                paper[i][j] = '1'
            else:
                paper[i][j] = '0'

paper = [['0'] * n for _ in range(n)]
paint_fractal(paper, black_squares)
print(''.join([''.join(row) for row in paper]))