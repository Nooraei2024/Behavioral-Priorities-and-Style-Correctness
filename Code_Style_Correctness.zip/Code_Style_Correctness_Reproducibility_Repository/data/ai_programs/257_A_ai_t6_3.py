import sys

# Read input from stdin
n = int(input())
devices = []
for _ in range(n):
    devices.append([int(x) for x in input().split()])

k = int(input())
electrical_sockets = [int(x) for x in input().split()]

# Initialize the number of connected devices and sockets
connected_devices = 0
connected_sockets = 0

# Loop through each device and its sockets
for device in devices:
    # Loop through each socket of the device
    for socket in device:
        # If the socket is connected to an electrical socket, increment the number of connected devices
        if socket in electrical_sockets:
            connected_devices += 1
        # If the socket is not connected to an electrical socket, increment the number of unconnected sockets
        else:
            connected_sockets += 1

# Print the result
print(connected_devices, connected_sockets)