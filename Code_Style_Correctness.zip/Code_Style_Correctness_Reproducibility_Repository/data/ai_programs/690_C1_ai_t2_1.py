import sys

# Read input from standard input (stdin)
n = int(sys.stdin.readline())
m = int(sys.stdin.readline())

# Initialize a list to store the number of brains for each zombie
brains = [0] * n

# Loop through each zombie and calculate the number of brains
for i in range(n):
    # Read the number of brains for this zombie from standard input (stdin)
    num_brains = int(sys.stdin.readline())
    
    # Add the number of brains to the list of brains for this zombie
    brains[i] += num_brains

# Print the sum of all brains as a single integer
print(sum(brains))