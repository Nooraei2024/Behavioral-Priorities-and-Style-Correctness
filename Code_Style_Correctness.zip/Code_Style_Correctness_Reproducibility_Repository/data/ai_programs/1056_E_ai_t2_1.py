import sys

# Read input from stdin
s = sys.stdin.readline().strip()
t = sys.stdin.readline().strip()

# Check if t is similar to s
if len(s) != len(t):
    print("No")
else:
    for i in range(len(s)):
        if s[i] != t[i]:
            print("No")
            break
    else:
        print("Yes")