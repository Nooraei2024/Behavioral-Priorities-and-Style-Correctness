import sys

# Read input from stdin
input = sys.stdin.readline()

# Initialize the multiset A
A = set([0])

# Loop through each query
for line in input.splitlines():
    # Get the type of query and the value to be added/erased
    query_type, value = line.strip().split(" ")
    
    if query_type == "+":
        # Add the value to the multiset A
        A.add(int(value))
    elif query_type == "-":
        # Erase one occurrence of the value from the multiset A
        A.discard(int(value))
    else:
        # Compute the maximum value in the multiset A
        print(max(A))