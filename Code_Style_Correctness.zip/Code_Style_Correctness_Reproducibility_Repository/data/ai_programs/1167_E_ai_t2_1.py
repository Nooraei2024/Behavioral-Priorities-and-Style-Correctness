import sys

def solve(a, x):
    # Count the number of pairs (l, r) such that 1 <= l <= r <= x and f(l, r) is sorted in non-descending order
    count = 0
    
    # Iterate over all possible values of l and r
    for l in range(1, x+1):
        for r in range(l, x+1):
            # Check if the resulting array is sorted in non-descending order
            if all(a[i] >= a[i+1] for i in range(len(a)-1)):
                count += 1
    
    return count

# Read input from standard input (stdin)
n = int(input())
a = [int(x) for x in input().split()]
x = int(input())

# Print the result
print(solve(a, x))