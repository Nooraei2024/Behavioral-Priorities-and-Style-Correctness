import sys

def get_comments(article):
    # Split the input string into a list of comments
    comments = article.split('\n')
    
    # Create an empty dictionary to store the comments
    comment_dict = {}
    
    # Iterate through each comment and add it to the dictionary
    for comment in comments:
        if comment != '':
            parent, child = comment.split(' ')
            if parent not in comment_dict:
                comment_dict[parent] = []
            comment_dict[parent].append(child)
    
    # Return the dictionary of comments
    return comment_dict

def save_comments(comment_dict):
    # Iterate through each key-value pair in the dictionary
    for parent, children in comment_dict.items():
        # If the parent has no children, just print it as is
        if len(children) == 0:
            print(parent)
        
        # Otherwise, print the parent and all its children recursively
        else:
            print(parent + '(' + ','.join(children) + ')')
    
# Read input from standard input (stdin)
article = sys.stdin.readline().strip()

# Get the dictionary of comments
comment_dict = get_comments(article)

# Save the comments to the hard drive
save_comments(comment_dict)