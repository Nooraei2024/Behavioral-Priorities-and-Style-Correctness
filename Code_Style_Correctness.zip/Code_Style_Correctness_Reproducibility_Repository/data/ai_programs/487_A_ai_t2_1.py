import sys

# Read input from stdin
input_string = sys.stdin.readline().strip()

# Split input string into a list of integers representing HP, ATK, and DEF for Yang and the monster
yang_hp, yang_atk, yang_def, monster_hp, monster_atk, monster_def = [int(x) for x in input_string.split()]

# Initialize variables to keep track of HP and damage dealt
yang_damage = 0
monster_damage = 0

# Simulate the battle until one of the parties is defeated or both are at 0 HP
while yang_hp > 0 and monster_hp > 0:
    # Calculate damage dealt by Yang to the monster
    monster_damage = max(0, yang_atk - monster_def)
    # Update the monster's HP
    monster_hp -= monster_damage
    
    # Calculate damage dealt by the monster to Yang
    yang_damage = max(0, monster_atk - yang_def)
    # Update Yang's HP
    yang_hp -= yang_damage

# Check if Yang or the monster is defeated
if yang_hp <= 0:
    print("The monster wins!")
else:
    print("Master Yang wins!")