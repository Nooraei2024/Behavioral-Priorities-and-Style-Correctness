import sys

# Read input from standard input (stdin)
n, m = map(int, input().split())
factory = []
for _ in range(n):
    factory.append([int(x) for x in input().split()])

# Look at each number in binary form
for row in factory:
    for num in row:
        print(bin(num))