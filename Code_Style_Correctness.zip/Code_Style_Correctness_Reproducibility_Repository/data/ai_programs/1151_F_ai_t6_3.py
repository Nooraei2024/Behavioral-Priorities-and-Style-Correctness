import sys

# Read input from stdin
n = int(input())
a = list(map(int, input().split()))
k = int(input())

# Calculate the probability
probability = 0
for i in range(n):
    for j in range(i+1, n):
        if a[i] != a[j]:
            probability += 1

probability /= k
print(f"{probability:.2f}")