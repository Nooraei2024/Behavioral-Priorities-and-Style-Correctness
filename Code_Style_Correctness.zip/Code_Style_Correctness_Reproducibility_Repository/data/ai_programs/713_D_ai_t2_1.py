import sys

n, m = map(int, input().split())
puzzle = []
for _ in range(n):
    puzzle.append(list(map(int, input().split())))

# Check if the puzzle is solvable
if any(sum(row) == 0 for row in puzzle):
    print("Impossible")
    sys.exit(0)

# Find the first empty space
empty_space = None
for i in range(n):
    for j in range(m):
        if puzzle[i][j] == 0:
            empty_space = (i, j)
            break
    if empty_space is not None:
        break

# Fill the first empty space with a picture
puzzle[empty_space[0]][empty_space[1]] = 1

# Print the final puzzle
for row in puzzle:
    print(" ".join(str(x) for x in row))