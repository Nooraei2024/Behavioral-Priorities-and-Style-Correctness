import sys

# Read input from stdin
n, m = map(int, sys.stdin.readline().split())
A = []
for _ in range(n):
    A.append(list(map(int, sys.stdin.readline().split())))

# Calculate the spectrum of the matrix A
X = [0] * m
Y = [0] * n
for i in range(n):
    for j in range(m):
        X[j] += A[i][j]
        Y[i] += A[i][j]

# Print the spectrum
print(*X, sep=' ')
print(*Y, sep=' ')