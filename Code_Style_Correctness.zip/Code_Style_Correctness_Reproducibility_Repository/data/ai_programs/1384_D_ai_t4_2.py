import sys

n = int(input())
a = list(map(int, input().split()))

score = 0
turn = "Koa"

while a:
    if turn == "Koa":
        x = a.pop()
        score ^= x
    else:
        x = a.popleft()
        score ^= x
    turn = "Best Friend" if turn == "Koa" else "Koa"

print(score)