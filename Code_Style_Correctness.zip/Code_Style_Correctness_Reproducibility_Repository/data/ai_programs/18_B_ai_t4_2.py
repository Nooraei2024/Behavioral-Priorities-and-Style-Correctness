import sys

n, d = map(int, input().split())
m = 10**9 + 7

def jump(x):
    return (x + d) % m

def find_falling_point(platforms):
    falling_points = []
    for i in range(len(platforms)):
        if platforms[i] == 0:
            falling_points.append(jump(i))
    return falling_points

platforms = list(map(int, input().split()))
falling_points = find_falling_point(platforms)
print(*falling_points, sep='\n')