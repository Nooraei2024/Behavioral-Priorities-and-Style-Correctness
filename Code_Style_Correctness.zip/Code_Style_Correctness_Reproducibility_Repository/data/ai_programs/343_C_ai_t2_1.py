import sys

# Read input from stdin
n = int(sys.stdin.readline())
hi = list(map(int, sys.stdin.readline().split()))

# Initialize output array
output = []

# Loop through each reading head and calculate the time it takes to read the track
for i in range(n):
    # Calculate the time it takes for the current reading head to read the track
    time = abs(hi[i] - 1) + 1
    
    # Add the calculated time to the output array
    output.append(time)

# Print the output array
print(*output, sep='\n')