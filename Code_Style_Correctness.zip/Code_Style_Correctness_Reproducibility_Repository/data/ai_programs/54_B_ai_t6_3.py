import sys

def solve(s):
    pieces = s.split()
    result = []
    for piece in pieces:
        if len(piece) == 0:
            continue
        result.append(int(piece))
    return result

if __name__ == "__main__":
    input_string = sys.stdin.readline()
    output = solve(input_string)
    print(*output, sep='\n')