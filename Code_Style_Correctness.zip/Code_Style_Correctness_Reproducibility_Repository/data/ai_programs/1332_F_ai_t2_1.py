# Read input from standard input (stdin)
n = int(input())
e = []
for _ in range(n):
    e.append(list(map(int, input().split())))

# Create a graph object
from collections import defaultdict
graph = defaultdict(list)
for i in range(n):
    for j in range(i+1, n):
        if (i, j) in e:
            graph[i].append(j)
            graph[j].append(i)

# Find the independent set
independent_set = []
for i in range(n):
    if len(graph[i]) == 0:
        independent_set.append(i)

# Print the result
print(*independent_set, sep='\n')