import sys

n, k = map(int, input().split())
tables = list(input())

# Initialize a set to keep track of occupied tables
occupied_tables = set()

# Iterate over the tables and check for distance constraints
for i in range(n):
    if tables[i] == "1":
        # Add the current table to the set of occupied tables
        occupied_tables.add(i)
        
        # Check for distance constraints with the previous tables
        for j in range(i-k, i+k+1):
            # If the table is within the distance constraint, add it to the set
            if 0 <= j < n and tables[j] == "1":
                occupied_tables.add(j)

# Print the maximum number of occupied tables
print(len(occupied_tables))