import sys

def solve(paper):
    # Check if there is already a 2x2 square in the initial picture
    for i in range(4):
        for j in range(4):
            if paper[i][j] == paper[i+1][j] and paper[i][j] == paper[i][j+1] and paper[i][j] == paper[i+1][j+1]:
                return "YES"
    
    # Check if there is a 2x2 square that can be formed by changing one cell to the other color
    for i in range(4):
        for j in range(4):
            if paper[i][j] == 'B' and paper[i+1][j] == 'W' and paper[i][j+1] == 'W' and paper[i+1][j+1] == 'B':
                return "YES"
    
    # If no 2x2 square can be formed, the person should say so
    return "NO"

# Read input from standard input (stdin)
input_string = sys.stdin.readline()

# Parse the input string into a list of lists
paper = [list(input_string[i:i+4]) for i in range(0, len(input_string), 4)]

# Call the solve function and print the result to standard output (stdout)
print(solve(paper))