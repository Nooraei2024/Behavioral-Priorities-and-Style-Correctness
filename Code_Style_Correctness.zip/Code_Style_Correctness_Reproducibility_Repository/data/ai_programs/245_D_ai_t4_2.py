import sys

# Read input from stdin
n = int(input())
a = list(map(int, input().split()))
b = []
for i in range(n):
    b.append([])
    for j in range(n):
        b[i].append(int(input()))

# Calculate the bitwise AND of each row and column
row_and = [0] * n
col_and = [0] * n
for i in range(n):
    for j in range(n):
        row_and[i] &= b[i][j]
        col_and[j] &= b[i][j]

# Print the result
print(*row_and, sep=' ')
print(*col_and, sep=' ')