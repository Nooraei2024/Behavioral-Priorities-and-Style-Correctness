import sys

def solve(n, queries):
    multiset = set()
    for query in queries:
        if query[0] == '+':
            multiset.add(query[1:])
        else:
            multiset.discard(query[1:])
    return len(multiset)

if __name__ == '__main__':
    n = int(input())
    queries = []
    for _ in range(n):
        queries.append(input())
    print(solve(n, queries))