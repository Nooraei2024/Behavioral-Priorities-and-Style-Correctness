import sys

# Read input from stdin
n = int(sys.stdin.readline())
edges = []
for _ in range(n):
    edges.append(list(map(int, sys.stdin.readline().split())))

# Find the root of the tree
root = 0
for i in range(1, n+1):
    if i not in edges:
        root = i
        break

# Print the tree as a list of lists
print([[i] + [j for j in edges if j[0] == i] for i in range(1, n+1)])