import sys

# Read input from stdin
n = int(input())
a = list(map(int, input().split()))

# Initialize scores as 0
koa_score = 0
best_friend_score = 0

# Loop through the array and perform moves
for i in range(n):
    # Choose an element to remove
    x = a[i]
    # Remove the element from the array
    del a[i]
    # Xor the chosen element with the current score of the player
    koa_score ^= x
    best_friend_score ^= x

# Output the final scores
print(koa_score)
print(best_friend_score)