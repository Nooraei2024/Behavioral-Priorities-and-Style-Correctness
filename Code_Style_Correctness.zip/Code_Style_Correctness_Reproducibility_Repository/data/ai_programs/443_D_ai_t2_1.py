import sys

# Read input from stdin
n = int(input())
friends = list(map(int, input().split()))

# Calculate the probability of each friend coming up with a problem
probabilities = [friend / sum(friends) for friend in friends]

# Find the index of the friend with the highest probability of coming up with a problem
index = probabilities.index(max(probabilities))

# Output the index of the friend to ask
print(index + 1)