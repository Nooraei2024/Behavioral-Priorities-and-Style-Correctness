import sys

n = int(input())
confidence = list(map(int, input().split()))

# Calculate the sum of all confidence values
total_confidence = sum(confidence)

# Calculate the average confidence value
average_confidence = total_confidence / n

# Initialize a dictionary to store the child's name and their corresponding confidence value
child_dict = {}
for i in range(n):
    child_dict[i+1] = confidence[i]

# Sort the dictionary by the value of each child's confidence
sorted_dict = sorted(child_dict.items(), key=lambda x: x[1], reverse=True)

# Print the name of the child with the highest confidence value
print(sorted_dict[0][0])