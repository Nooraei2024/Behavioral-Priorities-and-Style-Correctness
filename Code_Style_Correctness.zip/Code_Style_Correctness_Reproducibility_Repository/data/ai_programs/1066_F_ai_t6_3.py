import sys

# Read input from stdin
n = int(input())
points = []
for i in range(n):
    x_i, y_i = map(int, input().split())
    points.append((x_i, y_i))

# Find the shortest path to all key points
shortest_path = 10**9
for point in points:
    distance = abs(point[0]) + abs(point[1])
    if distance < shortest_path:
        shortest_path = distance

print(shortest_path)