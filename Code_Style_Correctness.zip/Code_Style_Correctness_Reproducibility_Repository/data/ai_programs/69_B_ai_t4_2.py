import sys

# Read input from stdin
n, m = map(int, sys.stdin.readline().split())
sections = []
for _ in range(n):
    sections.append(list(map(int, sys.stdin.readline().split())))

# Initialize the bets dictionary
bets = {}

# Read each participant's bets
for i in range(m):
    line = sys.stdin.readline().strip()
    if line:
        parts = line.split()
        for j in range(len(parts)):
            bets[(i+1, int(parts[j]))] = int(parts[j+1])

# Calculate the total sum of bets for each section
total_sum = {}
for i in range(n):
    total_sum[i+1] = 0
    for j in range(m):
        if (j+1, i+1) in bets:
            total_sum[i+1] += bets[(j+1, i+1)]

# Calculate the maximum sum of bets for each participant
max_sum = 0
for i in range(m):
    if total_sum[sections[i][0]] > max_sum:
        max_sum = total_sum[sections[i][0]]

# Print the answer
print(max_sum)