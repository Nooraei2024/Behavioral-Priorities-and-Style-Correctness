import sys

# Read input from stdin
n = int(input())
robots = []
for _ in range(n):
    robots.append(int(input()))

# Initialize a dictionary to store the number of robots and their capacity
capacity = {}
for robot in robots:
    if robot not in capacity:
        capacity[robot] = 0
    capacity[robot] += 1

# Sort the robots by their capacity in descending order
sorted_robots = sorted(capacity.items(), key=lambda x: x[1], reverse=True)

# Initialize a list to store the final order of the robots
final_order = []

# Iterate through the sorted robots and add them to the final order
for robot, _ in sorted_robots:
    if capacity[robot] > 0:
        final_order.append(robot)
        capacity[robot] -= 1

# Print the final order of the robots
print(*final_order, sep='\n')