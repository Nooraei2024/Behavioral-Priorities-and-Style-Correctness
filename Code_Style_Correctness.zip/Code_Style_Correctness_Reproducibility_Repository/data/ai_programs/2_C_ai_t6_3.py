import sys

# Read input from standard input (stdin)
n = int(sys.stdin.readline())
stadiums = []
for i in range(n):
    stadiums.append([int(x) for x in sys.stdin.readline().split()])

# Calculate the maximum distance between two points
def max_distance(p1, p2):
    return max(abs(p1[0] - p2[0]), abs(p1[1] - p2[1]))

# Find the best point of observation
best_point = (0, 0)
for i in range(n):
    for j in range(i+1, n):
        distance = max_distance(stadiums[i], stadiums[j])
        if distance > best_point[1]:
            best_point = (i, j, distance)

# Output the best point of observation
print(best_point[0] + 1)
print(best_point[1] + 1)