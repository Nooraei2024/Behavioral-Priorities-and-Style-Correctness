import sys

def snow_walking_robot(s):
    x, y = 0, 0
    for instruction in s:
        if instruction == 'L':
            x -= 1
        elif instruction == 'R':
            x += 1
        elif instruction == 'U':
            y -= 1
        elif instruction == 'D':
            y += 1
    return (x, y)

if __name__ == "__main__":
    s = input()
    result = snow_walking_robot(s)
    print(result)