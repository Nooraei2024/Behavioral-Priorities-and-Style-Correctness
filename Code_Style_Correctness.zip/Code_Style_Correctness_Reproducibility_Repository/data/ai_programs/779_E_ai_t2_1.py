import sys

# Read input from stdin
m = int(sys.stdin.readline())
n = int(sys.stdin.readline())

# Initialize variables
variables = {}
for i in range(n):
    variables[i] = 0

# Compute values of n variables
for i in range(n):
    line = sys.stdin.readline().strip()
    if line == "":
        break
    tokens = line.split(" ")
    operand1 = int(tokens[0])
    operand2 = int(tokens[1])
    operator = tokens[2]
    if operator == "AND":
        variables[i] = operand1 & operand2
    elif operator == "OR":
        variables[i] = operand1 | operand2
    else:
        variables[i] = operand1 ^ operand2

# Print output to stdout
for i in range(n):
    print(variables[i])