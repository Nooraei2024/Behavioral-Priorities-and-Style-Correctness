import sys

def solve(points):
    x1, y1 = points[0]
    x2, y2 = points[1]
    x3, y3 = points[2]

    # Sort the points by their x-coordinates
    sorted_points = sorted(points, key=lambda p: p[0])

    # Initialize the minimum number of segments to 3
    min_segments = 3

    # Check if the first two points are on the same line
    if x1 == x2 or y1 == y2:
        # If they are, then we only need one segment
        min_segments = 1

    # Check if the third point is between the first two points
    if x3 >= min(x1, x2) and x3 <= max(x1, x2):
        # If it is, then we only need two segments
        min_segments = 2

    return min_segments

# Read input from standard input (stdin)
points = []
for _ in range(3):
    points.append([int(x) for x in sys.stdin.readline().split()])

# Call the solve function with the given points
print(solve(points))