import sys

# Read input from stdin
n = int(input())
a_b = []
for i in range(n):
    a_b.append([int(x) for x in input().split()])

# Calculate the total time taken by the train to reach its destination
total_time = 0
for i in range(n):
    total_time += abs(a_b[i][1] - a_b[i][0])

# Print the result
print(total_time)