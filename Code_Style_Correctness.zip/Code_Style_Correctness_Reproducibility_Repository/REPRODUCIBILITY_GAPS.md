# Items to reconcile before asserting complete end-to-end reproduction

1. **Selection protocol mismatch.** The original `archived_framework/feature_selection/final_selected_features_human.py` computes mutual information against **`maintainability_index`** (`TARGET = "maintainability_index"` and `mutual_info_regression`). In contrast, the paper describes selection by mutual information with **code origin**. These are not the same procedure. The supplied framework also originates from the related code-smell research. The deposited 26-feature datasets are the observed outputs, but the archived framework's feature-selection source **must not be claimed as proof of the manuscript's exact origin-informed selection algorithm** until the historical scripts are reconciled. The task-neutral 32-feature reanalysis avoids this selection issue and is reproduced by `scripts/task_neutral_models.py`.

2. **Figure 7 feature counts.** Figure 7 displays **15 raw static features**, including `maintainability_index` and `pylint_warning_count`. These two fields are **not part of the archived 26-feature selected table**. Consequently, editorial response language saying that Figure 7 was generated from "the 26 selected features" needs correction. The deposited `scripts/create_figure7.py` uses the 15 displayed features from the raw extended tables, standardizes on the pooled 2,687 observations, and renders a new auditable version with `matplotlib`. Cite this exact software version only if replacing the manuscript's figure with the regenerated output.

3. **Original source tests / checkers.** The complete Code-Contests-Plus per-problem test archive was not included with the supplied reproducibility materials. `archived_execution/CCPlus_Colab_834_Execution.ipynb` documents the prior execution approach but cannot independently regenerate all 67,059 recorded program-test evaluations from the contents of this deposit alone. Checker logic, exact input-output matching conventions, timeout, and source test hashes should be archived for an end-to-end audit.

4. **Model digest.** The historical Ollama tag `codellama` is documented, but a stable historical model digest, quantization, runtime version and checkpoint proof are not archived here. Do not assert a particular quantization as a verified historical property on the basis of a present-day `ollama list` alone.

5. **Rights to human source programs.** Human submissions from a contest benchmark are omitted from the publishable ZIP pending redistribution permission. Cryptographic hashes and the feature matrices are supplied, so recovered human sources can be checked for identity.

6. **Recorded expert marker.** `HUMAN_EXPERT_CONFIRMED` is retained as original workbook text; independent manual adjudication evidence should be supplied separately if claimed.

7. **Journal DOI.** The ZIP is ready for author review and upload, but no public deposition, DOI creation or source-code verification outside this environment has occurred.
