import zipfile,io,os,re,json
import numpy as np,pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
from sklearn.model_selection import StratifiedKFold,cross_val_predict
from sklearn.impute import SimpleImputer
from sklearn.pipeline import make_pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score,roc_curve,confusion_matrix
from scipy.stats import gaussian_kde
import statsmodels.api as sm
z=zipfile.ZipFile('/mnt/data/Framework Architecture (1)(5).zip')
def rd(n):return pd.read_csv(io.BytesIO(z.read(next(x for x in z.namelist() if x.endswith(n)))))
h=rd('Human Codes/outputs/final_features_extended.csv');a=rd('AI Codes/outputs/final_ai_features_extended.csv');b=pd.concat([h,a],ignore_index=True); b['source']=np.r_[np.zeros(len(h),dtype=int),np.ones(len(a),dtype=int)]; b['is_correct']=np.r_[h.file.str.contains('_correct_').astype(int),np.full(len(a),-1)];
num=[c for c in h.columns if c not in ('file','RADON_AVAILABLE') and c in a and pd.api.types.is_numeric_dtype(h[c]) and h[c].nunique()>1];X=b[num].replace([np.inf,-np.inf],np.nan)
zscores=(X.fillna(X.median())-X.mean())/X.std(ddof=0)
b['SI']=zscores[['identifier_avg_length','descriptive_id_ratio','maintainability_index']].mean(axis=1)
b['SCI']=zscores[['try_except_per_LOC','third_party_imports','avg_cc_per_function']].mean(axis=1)
figdir='/mnt/data/revision_work/figure_replacements';os.makedirs(figdir,exist_ok=True)

fig,ax=plt.subplots(figsize=(9,10),dpi=145);ax.set(xlim=(0,10),ylim=(0,12));ax.axis('off')
items=[('SOURCE CORPORA','Human: 1,853 labeled submissions (441 problems)\nAI: 834 CodeLLaMA solutions (372 matched problems)'),('STATIC FEATURE EXTRACTION','Radon / Pylint / JSCPD: 34 candidate metrics\n33 non-constant numeric features used in reanalysis'),('TASK-NEUTRAL MODEL EVALUATION','Within each CV fold: median imputation\nNo origin-targeted feature selection'),('TWO CLASSIFICATION TASKS','AI vs human (all 2,687 samples)\nCorrect vs incorrect (human 1,853 only)'),('EXPLORATORY COMPOSITES','Presentational Signal Index (Signal Index)\nStructural Substance Index (Substance Index)'),('ROBUSTNESS & LIMITATIONS','5-fold stratified and problem-grouped CV\nSCI sensitivity; AI correctness remains unverified')]
ys=[10.5,8.6,6.7,4.8,2.9,1.0]
for k,((title,sub),y) in enumerate(zip(items,ys)):
 ax.add_patch(FancyBboxPatch((.7,y-.68),8.6,1.3,boxstyle='round,pad=.06,rounding_size=.16',fc=['#eff6fd','#edf6f6'][k%2],ec='#63839d',lw=1.4))
 ax.text(5,y+.26,title,ha='center',va='center',fontsize=12,fontweight='bold',color='#173b58'); ax.text(5,y-.22,sub,ha='center',va='center',fontsize=10,color='#243542')
 if k<5:ax.add_patch(FancyArrowPatch((5,y-.73),(5,ys[k+1]+.73),arrowstyle='-|>',mutation_scale=15,color='#4d6f89',lw=1.5))
fig.savefig(figdir+'/image2.png',bbox_inches='tight',pad_inches=.12);plt.close(fig)

fig,ax=plt.subplots(figsize=(10,6),dpi=150)
vals=[b.loc[b.source==0,'SI'].values,b.loc[b.source==1,'SI'].values,b.loc[b.source==0,'SCI'].values,b.loc[b.source==1,'SCI'].values]
parts=ax.violinplot(vals,positions=[1,2,4,5],showmeans=True,showmedians=True)
for pc in parts['bodies']:pc.set_alpha(.55)
ax.set_xticks([1,2,4,5],['Human','AI','Human','AI']);ax.axhline(0,c='gray',lw=.8);ax.set_ylabel('Composite value (pooled z-score)');ax.set_title('Exploratory presentational and structural indices by origin');ax.text(1.5,ax.get_ylim()[1]*.95,'Presentational Signal Index',ha='center');ax.text(4.5,ax.get_ylim()[1]*.95,'Structural Substance Index',ha='center');fig.tight_layout();fig.savefig(figdir+'/image9.png');plt.close(fig)

fig,ax=plt.subplots(figsize=(9,7),dpi=150)
hb=ax.hexbin(b.SI,b.SCI,gridsize=60,mincnt=1,cmap='inferno');fig.colorbar(hb,ax=ax,label='Sample count');ax.set(xlabel='Presentational Signal Index (Signal Index)',ylabel='Structural Substance Index (Substance Index)',title='Joint distribution of the two descriptive composite indices');fig.tight_layout();fig.savefig(figdir+'/image14.png');plt.close(fig)

fig,axs=plt.subplots(3,1,figsize=(8,10),sharex=True,dpi=150)
for ax,(lbl,dd) in zip(axs,[('AI',b[b.source==1]),('Human (incorrect)',b[(b.source==0)&(b.is_correct==0)]),('Human (correct)',b[(b.source==0)&(b.is_correct==1)])]):
 v=dd.SI.values;kde=gaussian_kde(v);r=np.linspace(-2.7,4.2,400);ax.fill_between(r,kde(r),alpha=.4);ax.plot(r,kde(r),lw=1.6);ax.set_ylabel(lbl);ax.set_yticks([]);ax.spines[['right','left','top']].set_visible(False)
axs[-1].set_xlabel('Presentational Signal Index (Signal Index), z-score');axs[0].set_title('Presentational index distribution by group');fig.tight_layout();fig.savefig(figdir+'/image12.png');plt.close(fig)

fig=plt.figure(figsize=(8,8),dpi=150);gs=fig.add_gridspec(4,4,hspace=.09,wspace=.09);a_main=fig.add_subplot(gs[1:,:3]);a_top=fig.add_subplot(gs[0,:3],sharex=a_main);a_side=fig.add_subplot(gs[1:,3],sharey=a_main)
for lbl,sel in [('Human correct',(b.source==0)&(b.is_correct==1)),('Human incorrect',(b.source==0)&(b.is_correct==0)),('AI',b.source==1)]:
 dd=b[sel];a_main.scatter(dd.SI,dd.SCI,s=6,alpha=.28,label=lbl);a_top.hist(dd.SI,bins=40,density=True,alpha=.3);a_side.hist(dd.SCI,bins=40,orientation='horizontal',density=True,alpha=.3)
a_main.set_xlabel('Presentational Signal Index (Signal Index)');a_main.set_ylabel('Structural Substance Index (Substance Index)');a_main.legend(fontsize=8);a_top.tick_params(labelbottom=False);a_side.tick_params(labelleft=False);fig.savefig(figdir+'/image16.png',bbox_inches='tight');plt.close(fig)

# Fold-local neutral models displayed in updated diagnostic figures
cv=StratifiedKFold(5,shuffle=True,random_state=20261011)
metrics={}
for task,ind,y in [('origin',np.arange(len(b)),b.source.values),('human correctness',np.arange(len(h)),h.file.str.contains('_correct_').astype(int).values)]:
 pipe=make_pipeline(SimpleImputer(strategy='median'),RandomForestClassifier(n_estimators=160,max_features='sqrt',min_samples_leaf=2,class_weight='balanced',random_state=42,n_jobs=2))
 pr=cross_val_predict(pipe,X.iloc[ind],y,cv=cv,method='predict_proba')[:,1]
 metrics[task]=(y,pr,roc_auc_score(y,pr))

fig,ax=plt.subplots(figsize=(8,6),dpi=150)
for task in metrics:
 y,pr,auc=metrics[task];fpr,tpr,_=roc_curve(y,pr);ax.plot(fpr,tpr,lw=2,label=f'{task.title()} (AUC={auc:.3f})')
ax.plot([0,1],[0,1],'--',c='gray',alpha=.6);ax.set(xlabel='False positive rate',ylabel='True positive rate',title='Out-of-fold ROC: task-neutral feature set');ax.legend(loc='lower right');fig.tight_layout();fig.savefig(figdir+'/image3.png');plt.close(fig)
for task,img in [('origin','image4.png'),('human correctness','image5.png')]:
 y,p,auc=metrics[task]; cm=confusion_matrix(y,p>=.5)
 fig,ax=plt.subplots(figsize=(6,6),dpi=150);im=ax.imshow(cm,cmap='Blues');ax.set_xticks([0,1],['Human','AI'] if task=='origin' else ['Incorrect','Correct']);ax.set_yticks([0,1],['Human','AI'] if task=='origin' else ['Incorrect','Correct']);ax.set(xlabel='Predicted',ylabel='Actual',title=f'{task.title()} classifier (fold-held-out)');
 for (i,j),v in np.ndenumerate(cm):ax.text(j,i,str(v),ha='center',va='center',fontsize=14,fontweight='bold',color='white' if v>cm.max()/2 else 'black')
 fig.tight_layout();fig.savefig(figdir+'/'+img);plt.close(fig)

out=json.load(open('/mnt/data/revision_work/analysis_results.json'))
fig,ax=plt.subplots(figsize=(7,5),dpi=150)
labels=['Origin','Human correctness'];vals=[out['model'][t]['auc_oof'] for t in ['origin','human_correctness']];err=[(v-out['model'][t]['ci95_bootstrap'][0],out['model'][t]['ci95_bootstrap'][1]-v) for t,v in zip(['origin','human_correctness'],vals)]
ax.bar(labels,vals,alpha=.75);ax.errorbar(range(2),vals,yerr=np.array(err).T,fmt='none',ecolor='black',capsize=5);ax.axhline(.5,linestyle='--',color='gray',label='Chance');ax.set_ylim(.4,1.04);ax.set_ylabel('Pooled out-of-fold AUC');ax.set_title('Task-neutral 5-fold classification, 95% bootstrap CI');ax.legend();fig.tight_layout();fig.savefig(figdir+'/image6.png');plt.close(fig)

# Heteroscedasticity-robust interaction model
Xr=pd.DataFrame({'SI':b.SI,'AI':b.source,'SI_x_AI':b.SI*b.source});Xr=sm.add_constant(Xr)
res=sm.OLS(b.SCI,Xr).fit(cov_type='HC3');stat={'r2':float(res.rsquared),'n':len(b),'coefficients':{k:{'coef':float(res.params[k]),'se':float(res.bse[k]),'t':float(res.tvalues[k]),'p':float(res.pvalues[k]),'ci95':[float(x) for x in res.conf_int().loc[k]]} for k in res.params.index}}
json.dump(stat,open('/mnt/data/revision_work/regression_results.json','w'),indent=2);print('OLS',stat);print('Figures',os.listdir(figdir))
