import zipfile,io,pandas as pd,numpy as np,json
from sklearn.model_selection import StratifiedGroupKFold,cross_val_predict
from sklearn.impute import SimpleImputer
from sklearn.pipeline import make_pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score
z=zipfile.ZipFile('/mnt/data/Framework Architecture (1)(5).zip')
def rd(n):return pd.read_csv(io.BytesIO(z.read(next(x for x in z.namelist() if x.endswith(n)))))
h=rd('Human Codes/outputs/final_features_extended.csv');a=rd('AI Codes/outputs/final_ai_features_extended.csv');b=pd.concat([h,a],ignore_index=True)
cols=[c for c in h.columns if c not in ('file','RADON_AVAILABLE') and c in a.columns and pd.api.types.is_numeric_dtype(h[c]) and h[c].nunique()>1];X=b[cols].replace([np.inf,-np.inf],np.nan)
for name,ind,y in [('origin',np.arange(len(b)),np.array([0]*len(h)+[1]*len(a))),('human_correctness',np.arange(len(h)),h.file.str.contains('_correct_').astype(int).values)]:
 groups=b.file.iloc[ind].str.extract(r'^(.*?)_(?:correct|incorrect|ai_t\d+)')[0]
 print(name,'unique_problem_groups',groups.nunique(),flush=True)
 cv=StratifiedGroupKFold(5,shuffle=True,random_state=31)
 pipe=make_pipeline(SimpleImputer(strategy='median'),RandomForestClassifier(n_estimators=140,min_samples_leaf=2,class_weight='balanced',random_state=42,n_jobs=2))
 prob=cross_val_predict(pipe,X.iloc[ind],y,cv=cv,groups=groups,method='predict_proba')[:,1]
 auc=roc_auc_score(y,prob);print('auc',auc,flush=True)
 d=json.load(open('/mnt/data/revision_work/analysis_results.json'));d['model'][name]['grouped_problem_auc_oof']=round(float(auc),4);d['model'][name]['unique_problem_groups']=int(groups.nunique());json.dump(d,open('/mnt/data/revision_work/analysis_results.json','w'),indent=2)
