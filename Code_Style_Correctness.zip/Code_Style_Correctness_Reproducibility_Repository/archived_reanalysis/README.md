# Archived revision analyses

The scripts in this folder were supplied from a prior revision analysis (11 October 2026). They contain environment-specific absolute paths pointing to an older filename of the `Framework Architecture` archive. They are preserved **as historical code**, not as a portable reproduction command.

The historical text accompanying these scripts predated the later 834-program execution outcome worksheet and described AI correctness as not yet evaluated; **that earlier status was superseded** by the records in `data/evaluation/Supplementary_Data_1_original.xlsx`. Use the current `scripts/` for reproducible calculations and the provenance discussion in `RIGHTS_AND_PROVENANCE.md`.
