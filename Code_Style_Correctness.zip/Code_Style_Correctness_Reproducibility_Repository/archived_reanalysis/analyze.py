import zipfile, io, numpy as np, pandas as pd, json
from sklearn.pipeline import make_pipeline
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold, GroupKFold, cross_val_predict
from sklearn.metrics import roc_auc_score
from scipy.stats import mannwhitneyu, spearmanr, pearsonr
from sklearn.preprocessing import StandardScaler
from sklearn.utils import resample
z=zipfile.ZipFile('/mnt/data/Framework Architecture (1)(5).zip')
def read(suffix):
 n=next(n for n in z.namelist() if n.endswith(suffix));return pd.read_csv(io.BytesIO(z.read(n)))
h=read('Human Codes/outputs/final_features_extended.csv');a=read('AI Codes/outputs/final_ai_features_extended.csv')
print('shape',h.shape,a.shape,flush=True)
num=[x for x in h.columns if x!='file' and x!='RADON_AVAILABLE' and x in a.columns and pd.api.types.is_numeric_dtype(h[x])]
print('n features',len(num),num,flush=True)
h['correct']=h['file'].str.contains('_correct_').astype(int);a['correct']=np.nan
both=pd.concat([h,a],ignore_index=True); both['ai']=[0]*len(h)+[1]*len(a)
X=both[num].apply(pd.to_numeric,errors='coerce').replace([np.inf,-np.inf],np.nan)
# drop fully missing or constant
num=[c for c in num if X[c].notna().sum()>100 and X[c].nunique()>1];X=X[num]
zs=(X.fillna(X.median())-X.mean())/X.std(ddof=0)
S=['identifier_avg_length','descriptive_id_ratio','maintainability_index'];C=['try_except_per_LOC','third_party_imports','avg_cc_per_function']
print('INDEX available',S,C,flush=True)
both['SI']=zs[S].mean(axis=1);both['SCI']=zs[C].mean(axis=1)
both['SCI_no_complexity']=zs[C[:-1]].mean(axis=1)
both['SCI_complexity_reversed']=zs[C[:-1]+['avg_cc_per_function']].mul([1,1,-1]).mean(axis=1)
from sklearn.metrics import roc_auc_score
out={'human_n':len(h),'ai_n':len(a),'correct_human':int(h.correct.sum()),'features':len(num),'index':{},'model':{}}
for key in ['SI','SCI','SCI_no_complexity','SCI_complexity_reversed']:
 hu=both.loc[both.ai==0,key];ai=both.loc[both.ai==1,key]
 out['index'][key]={'human_mean':float(hu.mean()),'ai_mean':float(ai.mean()),'ai_minus_human':float(ai.mean()-hu.mean()),'origin_auc':float(roc_auc_score(both.ai,both[key])),'human_correctness_auc':float(roc_auc_score(h.correct,hu)),'human_correctness_spearman':float(spearmanr(h.correct,hu).statistic)}
print('indices',out['index'],flush=True)
cv=StratifiedKFold(5,shuffle=True,random_state=20261011)
for name, Xi,y in [('origin',X,both.ai),('human_correctness',X.iloc[:len(h)],h.correct)]:
 model=make_pipeline(SimpleImputer(strategy='median'),RandomForestClassifier(n_estimators=160, max_features='sqrt',min_samples_leaf=2,class_weight='balanced',random_state=42,n_jobs=2))
 preds=cross_val_predict(model,Xi,y,cv=cv,method='predict_proba',n_jobs=1)[:,1]
 auc=roc_auc_score(y,preds)
 rng=np.random.default_rng(42); aucs=[]
 for _ in range(500):
  idx=rng.choice(len(y),len(y),replace=True)
  if len(set(np.asarray(y)[idx]))<2:continue
  aucs.append(roc_auc_score(np.asarray(y)[idx],preds[idx]))
 out['model'][name]={'auc_oof':float(auc),'ci95_bootstrap':[float(v) for v in np.quantile(aucs,[.025,.975])],'n':len(y),'description':'5-fold stratified OOF; all available nonconstant original static features; no supervised feature selection; median imputation within fold; 160-tree balanced RF'}
 print(name,out['model'][name],flush=True)
# problem-level grouped diagnostic (group codes filename first 2 fields; not same problems overlap in all cases)
# bootstrap not computed grouped
for name, Xi,y,fn in [('origin',X,both.ai,both.file),('human_correctness',X.iloc[:len(h)],h.correct,h.file)]:
 groups=fn.astype(str).str.extract(r'^(\d+_[A-Za-z0-9]+)')[0].fillna(fn.astype(str))
 print(name,'group count',groups.nunique(),flush=True)
 from sklearn.model_selection import StratifiedGroupKFold
 cvg=StratifiedGroupKFold(n_splits=5,shuffle=True,random_state=31)
 model=make_pipeline(SimpleImputer(strategy='median'),RandomForestClassifier(n_estimators=100,max_features='sqrt',min_samples_leaf=2,class_weight='balanced',random_state=42,n_jobs=2))
 preds=cross_val_predict(model,Xi,y,cv=cvg,groups=groups,method='predict_proba',n_jobs=1)[:,1]
 out['model'][name]['grouped_problem_auc_oof']=float(roc_auc_score(y,preds))
 print('GROUPED',name,out['model'][name]['grouped_problem_auc_oof'],flush=True)
# save
with open('/mnt/data/revision_work/analysis_results.json','w') as f:json.dump(out,f,indent=2)
both[['file','ai','correct','SI','SCI','SCI_no_complexity','SCI_complexity_reversed']].to_csv('/mnt/data/revision_work/index_sensitivity.csv',index=False)
