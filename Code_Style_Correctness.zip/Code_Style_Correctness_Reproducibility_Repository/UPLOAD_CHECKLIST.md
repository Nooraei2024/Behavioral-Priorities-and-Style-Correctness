# Before public release — author checklist

- [ ] Confirm the right to redistribute the 834 CodeLLaMA-generated source programs and derived feature data.
- [ ] Confirm that no human contest submissions were copied into the public release without permission (this package intentionally omits source human submissions).
- [ ] Verify the original execution worksheet's scientific provenance; `HUMAN_EXPERT_CONFIRMED` is a recorded string, not independently documented auditing.
- [ ] Verify the exact CodeLLaMA checkpoint/quantization using the historical generation host or metadata, if available.
- [ ] Confirm the external Code-Contests-Plus test archive/checker source can be accessed by readers and specify any test availability limitations.
- [ ] Reconcile manuscript wording on original mutual-information feature-selection target with the actual historical script (`REPRODUCIBILITY_GAPS.md`).
- [ ] Correct Editor response claiming 26 selected features directly produced Figure 7; the plotted heatmap has 15 displayed raw features, including fields outside the 26-feature table.
- [ ] Run `python scripts/verify_dataset.py` and `python -m pytest -q` and inspect reports.
- [ ] Run the reanalysis scripts, record exact Python, scikit-learn and plotting-library versions.
- [ ] If claiming reproducibility of Figure 7, regenerate and replace the manuscript figure using the deposited plotting script, and cite **the software actually used**, version, and URL in its legend.
- [ ] Create a new Zenodo record, upload this ZIP, publish, and obtain a genuine DOI (currently not assigned).
- [ ] Replace DOI placeholders in the manuscript Code Availability statement and point-by-point Editor response.
- [ ] Explain relationship to the separately archived *Framework Architecture* / code-smell work without citing its DOI as if it identified this specific manuscript code deposit.
