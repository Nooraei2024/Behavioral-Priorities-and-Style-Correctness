# Validation report for packaged materials

Verification executed in the build environment (Python 3.13.5, scikit-learn 1.8.0; full environment in `validation_environment.json`).

All checks below were run against the actual supplied CSV and workbook files, not simulated inputs.

| Verification | Observed | Manuscript/Supplementary |
|---|---:|---:|
| Human programs | 1,853 | 1,853 |
| Judge-accepted human programs | 823 | 823 |
| AI programs / problem IDs | 834 / 372 | 834 / 372 |
| AI fully passing programs | 89 | 89 |
| Evaluated program-test pairs | 67,059 | 67,059 |
| Passing program-test pairs | 15,373 | 15,373 |
| Mean per-program pass rate | 23.04% | 23.04% |
| Test-weighted pass rate | 22.92% | 22.92% |
| SI AI correctness ROC-AUC | 0.453503 | 0.454 |
| SCI AI correctness ROC-AUC | 0.539062 | 0.539 |
| Task-neutral origin OOF AUC | 0.982370 | 0.982 |
| Task-neutral human correctness OOF AUC | 0.568819 | 0.569 |
| Grouped origin OOF AUC | 0.978213 | 0.978 |
| Grouped human correctness OOF AUC | 0.533892 | 0.534 |
| Grouped AI correctness OOF AUC | 0.466443 | 0.466 |

Unit tests: `3 passed` (in this environment). Code files exist and match archived row IDs. Figure 7 reconstruction generated successfully using matplotlib 3.10.8.

**Scope:** reproducing these statistical analyses does not reexecute the external Code-Contests-Plus test suites, verify the model checkpoint, or resolve feature-selection provenance mismatch. See `REPRODUCIBILITY_GAPS.md`.
