# Security warning for reproducibility users

**Do not run the archived AI-generated Python programs directly on your computer.** They are untrusted source code. Use an isolated offline container or virtual machine, enforce time/memory/filesystem limits, deny network access, and never mount personal files or credentials.

The archived Colab notebook contains a pickle-reading step. Python `pickle.load()` can execute arbitrary code on load. Only open benchmark pickle files from a verified, trusted source in a disposable environment. The notebook's process memory/time limits are not a hardened sandbox. No study program is automatically executed by the repository verification or analysis scripts.
