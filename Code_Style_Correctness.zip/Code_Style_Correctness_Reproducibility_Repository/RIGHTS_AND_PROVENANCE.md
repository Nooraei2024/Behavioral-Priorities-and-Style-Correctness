# Provenance, licensing and interpretation

## Origins and rights
- The 834 AI-generated programs and author-originated feature data were supplied in the study materials. The source generation tag is `codellama` (Ollama); the archived tag is **not an immutable model checkpoint**. The original code-generation script records temperature settings 0.2, 0.4 and 0.6 and `num_predict=350`.
- Archived scripts under `archived_framework/` derive from the supplied *Framework Architecture* archive. That archive includes an MIT software license attributed to Elham Horri Najaf Abadi, retained here. Its original framework includes components used in a **related** code-smell study; this deposit includes only pertinent stage-one scripts and does not claim that the entire companion framework constitutes the exact pipeline for this paper.
- Human-written source programs from contest platforms were **not redistributed in this public-upload candidate** because the original authors' submission rights and benchmark redistribution terms have not been independently verified. The 1,853 supplied numeric feature rows and filename-derived acceptance labels support the reported feature-level reanalyses. Source code may be reconstructed from the original benchmark subject to its licensing terms.
- Check the permissibility of republishing AI model outputs, derivative benchmark data, and all components before making the Zenodo record public. The root MIT license covers author-controlled software, not third-party rights.

## Meaning of the correctness labels
- The original human cohort contains **823 judge-accepted** and **1,030 judge-rejected** programs. These are not expert human ratings of quality.
- The AI outcome worksheet has **834 rows**, with **89 programs recorded as passing every evaluated test** and **745 not fully passing**, based on the workbook's `test_count` and `tests_passed` fields. These are **research-test outcomes**, not official hidden-judge acceptance certificates.
- The original worksheet includes values `HUMAN_EXPERT_CONFIRMED` in two provenance fields. The presence of this string in a file does **not** by itself provide an independent per-program human validation protocol.
- The first-test audit and the independent 53-program diagnostic are **separate runs with different scopes/settings**. Do not compare their first-test matches directly to the 89 fully-passing programs as if the tests and setups were identical.
- Synthetic scenario files from other working materials were purposefully **excluded**. All results in this deposit are drawn from supplied observational/recorded tables; verify experimental lineage against the primary execution logs before claiming independently audited ground truth.

## Reproduction scope
- `scripts/verify_dataset.py` checks the supplied workbook aggregates, joins, and hashes; `scripts/analyze_indices.py` recomputes SI/SCI AUCs from existing index scores.
- `scripts/task_neutral_models.py` independently reimplements reported task-neutral and held-out validation procedures using the supplied raw feature tables. It is not claimed to be the exact original model-execution log.
- `archived_execution/CCPlus_Colab_834_Execution.ipynb` preserves the previously supplied execution notebook as a **historical artifact**. Actual rerun requires the separate problem-matched Code-Contests-Plus test archive and a hardened execution sandbox, which are not part of this deposit.
- `archived_reanalysis/` preserves author-supplied revision-era scripts in their original form, including environment-specific `/mnt/data` paths. These are provenance artifacts; use the clean `scripts/` folder for portable reanalyses.
- DOI not assigned yet. A DOI is provided by the repository service after public deposit; do not cite a placeholder as a published DOI.
