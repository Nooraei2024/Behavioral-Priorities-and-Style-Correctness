# Data dictionary

## `data/evaluation/Supplementary_Data_1_original.xlsx`
The original supplied worksheet, preserved as received. **Its first header contains an unusual literal suffix:** `program_id+67:67K11:1:53`.

The normalized CSV has *only* the first header changed to `program_id`; all original numerical cells and provenance strings are preserved.

| Field | Interpretation |
|---|---|
| `program_id` | Unique generated program filename (join key against `data/ai_programs/` and feature tables) |
| `problem_id` | Contest task identifier for grouped validation and linking test suites |
| `test_count` | Number of recorded evaluated test cases |
| `tests_passed` | Recorded count of matched test outputs |
| `test_pass_rate` | `tests_passed / test_count` for each program |
| `runtime_error`, `token_mismatch`, `timeout` | Recorded diagnostic flags; they do not necessarily partition all failure causes |
| `correctness` | Binary strict pass status: 1 iff `tests_passed == test_count` |
| `source_correctness`, `source_test_pass_rate` | Source record string `HUMAN_EXPERT_CONFIRMED`; this text marker alone does not prove independent adjudication |

## `data/features/`
- `human_extended_features.csv`: 1,853 raw extracted records; filename `*_correct_*` and `*_incorrect_*` corresponds to original platform acceptance/rejection.
- `ai_extended_features.csv`: 834 rows for generated code.
- `human_selected_26.csv`, `ai_selected_26.csv`: 26-feature representations from the archived feature-selection files; these are *not* the task-neutral 32-feature matrices.
- `composite_index_scores.csv`: 2,687 source-linked rows with `file`, `ai`, `correct`, `SI`, `SCI`, `SCI_no_complexity`, `SCI_complexity_reversed` used in the manuscript revision.

## Separate diagnostic files
`first_test_local_audit.csv` and `independent_recheck_53.csv` record distinct experimental checks; their selection, checker availability, and timeout conditions differ from the consolidated workbook and they should not be treated as identical test subsets.
